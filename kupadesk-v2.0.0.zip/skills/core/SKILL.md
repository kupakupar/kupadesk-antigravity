---
name: core
description: 打开 KupaDesk 云核心与系统提示词控制面板，随时开关或切换当前对话的系统提示词。当用户输入 /core 或要求开启/关闭/切换云核心与系统提示词时激活。
---

# `/core` — KupaDesk 快捷入口

当用户执行 `/core` 或希望打开/切换当前对话的系统提示词与 KupaDesk 云核心时：

1. 直接在回复中提供以下原生侧边栏胶囊链接，方便用户一键展开或收起右侧控制面板：

   [KupaDesk · 开关 / 选择核心](sidecar://kupadesk/prompt_panel/)

2. 简短提示用户也可通过以下方式打开或管理：
   - 对话右上角 `+` 菜单 → **KupaDesk**（空白新对话尚未发送第一句话前也可提前预选，发首句时会自动认领绑定到该对话）；
   - 新对话顶部自动出现的 **KupaDesk** 提示胶囊；
   - 插件管理页：[KupaDesk](customization://prompt-injector)。

3. 保持回复精炼，不要尝试修改用户未要求改动的文件或暴露任何外部说明。

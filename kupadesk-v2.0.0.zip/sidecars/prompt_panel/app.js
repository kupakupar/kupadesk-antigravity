(() => {
  const POLL_MS = 2000;
  const AUTOSAVE_MS = 500;
  const VALID_VIEWS = ['main', 'client', 'settings', 'diag'];
  const $ = (id) => document.getElementById(id);

  const params = new URLSearchParams(location.search);
  const currentConvId = () => window.sidecar?.conversationId || params.get('conversationId') || '';

  const CHANNEL_META = {
    'system-instruction': {
      sub: '当前对话设置（默认同步纯净正文至顶层 systemInstruction）',
      desc: '开启后自动写入 rules/AGENTS.md 进入顶层 systemInstruction，下轮发消息生效；关闭或退出即刻删除文件（单文件上限 24,000 B）。',
    },
    hook: {
      sub: '当前对话设置（兼容模式：通过 PreInvocation 注入对话流 systemMessage）',
      desc: '不写明文规则文件到磁盘，通过 Hook 在对话轨迹前注入原生 systemMessage；支持多对话并发严格隔离。',
    },
  };

  const MODE_META = {
    'every-turn': {
      label: '每轮置顶',
      desc: '每轮用户发消息前注入一次最新 systemMessage，保持近距最高权重；同轮多步工具调用不重复刷屏。',
    },
    'on-change': {
      label: '变更注入',
      desc: '仅在开关打开或选中核心/指令发生变更时注入一次，最省 Token。',
    },
    'every-invocation': {
      label: '每次调用',
      desc: '每次模型推理前均注入一次，适合超长工具链下需要最强硬约束的场景。',
    },
  };

  const REASON_LABEL = {
    session_start: '新对话启动',
    staging_claimed: '认领待命配置',
    session_start_already_injected: '首步已注防重复',
    enabled: '开关启用',
    content_changed: '指令变更',
    every_invocation: '每次推理策略',
    new_turn: '新一轮对话',
    disabled_by_user: '用户关闭开关',
    content_cleared: '有效内容清空',
    cloud_unavailable: '云核心未就绪',
    conversation_updated: '配置变更',
    staging_updated: '待命更新',
    focus_switch: '对话跟随',
    preset_updated: '预设变更',
    defaults_updated: '默认设置更新',
    cloud_updated: '云端更新',
    cloud_event: '云端状态变更',
    sidecar_shutdown: '退出清理',
    pre_invocation_sync: '推理前校验',
    switched_to_hook: '切换至 Hook',
    first_turn_rule_cold_start: '首轮冷启动兜底',
    long_context_anchor: '长对话防遗忘',
    manual_takeover: '手动接管',
  };

  const ACTION_LABEL = {
    injected: '已注入',
    deactivated: '已撤销',
    skipped: '已跳过',
    synced: '已同步',
    cleared: '已移除',
    fallback: '首轮兜底',
    anchored: '防遗忘锚点',
  };

  const LOCK_SVG = '<svg class="icon" width="11" height="11" viewBox="0 0 16 16" aria-hidden="true"><rect x="3.5" y="7" width="9" height="6.5" rx="1.2"/><path d="M5.5 7V5a2.5 2.5 0 0 1 5 0v2"/></svg>';
  const CHECK_SVG = '<svg class="icon" width="10" height="10" viewBox="0 0 16 16" aria-hidden="true"><path d="M3.5 8.5 6.5 11.5 12.5 4.5" stroke-width="2"/></svg>';
  const STAR_SVG = '<svg class="icon" width="12" height="12" viewBox="0 0 16 16" aria-hidden="true"><path d="m8 2.2 1.75 3.55 3.9.56-2.82 2.75.66 3.89L8 11.12 4.51 12.95l.66-3.89L2.35 6.31l3.9-.56z"/></svg>';
  const CLOSE_X_SVG = '<svg class="icon" width="10" height="10" viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 4.5 11.5 11.5M11.5 4.5 4.5 11.5" stroke-width="1.8"/></svg>';

  const ui = {
    data: null,
    etag: '',
    view: 'main', // main | client | settings | diag
    lastHandledViewAt: 0,
    dirty: false,
    saving: false,
    saveTimer: null,
    toastTimer: null,
    cloudFormExpanded: false,
    confirmDeletePresetId: '',
    confirmClearLogs: false,
    confirmDeactivate: false,
    confirmDesktopInstall: false,
    confirmDesktopUninstall: false,
    confirmCnInstallAll: false,
    updateBusy: false,
    originDirty: false,
    presetsDetailsInit: false,
    customDetailsInit: false,
    cloudDropdownOpen: false,
    cloudDropdownShowAll: false,
    mainCloudQuery: '',
    filterQuery: '',
    filterTab: 'all', // all | kept | default
  };

  // ---------- 主题亮度自动适配（同步宿主 CSS 变量） ----------
  function syncScheme() {
    const probe = document.createElement('span');
    probe.style.cssText = 'position:absolute;visibility:hidden;color:var(--background, #f7f7f8)';
    document.documentElement.appendChild(probe);
    const c = getComputedStyle(probe).color;
    probe.remove();
    const nums = (c.match(/[\d.]+/g) || []).map(Number);
    if (nums.length < 3) return;
    const scale = c.startsWith('color(') ? 1 : 255;
    const [r, g, b] = nums.slice(0, 3).map((v) => v / scale);
    const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
    const theme = lum < 0.5 ? 'dark' : 'light';
    if (document.documentElement.dataset.theme !== theme) {
      document.documentElement.dataset.theme = theme;
    }
  }
  syncScheme();
  new MutationObserver(syncScheme).observe(document.documentElement, {
    attributes: true,
    attributeFilter: ['style'],
  });

  const esc = (s) =>
    String(s ?? '').replace(/[&<>"']/g, (c) => ({
      '&': '&amp;',
      '<': '&lt;',
      '>': '&gt;',
      '"': '&quot;',
      "'": '&#39;',
    }[c]));

  function toast(msg) {
    const el = $('toast');
    el.textContent = msg;
    el.classList.remove('hidden');
    clearTimeout(ui.toastTimer);
    ui.toastTimer = setTimeout(() => el.classList.add('hidden'), 2200);
  }

  function fmtRelTime(iso) {
    if (!iso) return '尚未注入';
    const ms = Date.parse(iso);
    if (!Number.isFinite(ms)) return '';
    const diffSec = Math.max(0, Math.floor((Date.now() - ms) / 1000));
    if (diffSec < 15) return '刚刚';
    if (diffSec < 60) return `${diffSec} 秒前`;
    if (diffSec < 3600) return `${Math.floor(diffSec / 60)} 分钟前`;
    if (diffSec < 86400) return `${Math.floor(diffSec / 3600)} 小时前`;
    return new Date(ms).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
  }

  function fmtDateTime(iso) {
    if (!iso) return '-';
    const ms = Date.parse(iso);
    return Number.isFinite(ms) ? new Date(ms).toLocaleString('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }) : iso;
  }

  function shortId(id) {
    if (!id) return '';
    return id.length > 16 ? `${id.slice(0, 8)}…${id.slice(-4)}` : id;
  }

  async function apiGet(path) {
    const f = window.sidecar?.fetch ? window.sidecar.fetch.bind(window.sidecar) : fetch;
    const res = await f(path, { method: 'GET' });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return res.json();
  }

  async function apiPost(path, body) {
    const f = window.sidecar?.fetch ? window.sidecar.fetch.bind(window.sidecar) : fetch;
    const res = await f(path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(body),
    });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.error || `HTTP ${res.status}`);
    return data;
  }

  function setSaveState(text, isDirty = false) {
    const el = $('save-state');
    el.textContent = text;
    el.classList.toggle('dirty', isDirty);
  }

  function updateEditorStats(text) {
    const trimmed = String(text ?? '').trim();
    const chars = String(text ?? '').length;
    const estTokens = trimmed ? Math.max(1, Math.ceil(trimmed.length / 3)) : 0;
    $('editor-stats').textContent = `${chars} 字符 · 约 ${estTokens} tokens`;
    if (!$('custom-prompt-details').open) {
      $('custom-summary-meta').textContent = trimmed ? `${chars} 字符` : '可选';
    }
  }

  function normalizeViewName(v) {
    return VALID_VIEWS.includes(v) ? v : 'main';
  }

  function switchView(nextView) {
    const target = normalizeViewName(nextView);
    ui.view = target;
    VALID_VIEWS.forEach((v) => {
      const el = $(`view-${v}`);
      const on = v === target;
      el.classList.toggle('active', on);
      el.classList.toggle('hidden', !on);
    });
    document.querySelectorAll('#nav-tabs [data-view]').forEach((btn) => {
      const on = btn.dataset.view === target;
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-selected', String(on));
    });
    window.scrollTo({ top: 0 });
  }

  function applyMeter(fillEl, bytes, limit) {
    const maxBytes = Math.max(1, Number(limit) || 24000);
    const val = Math.max(0, Number(bytes) || 0);
    const pct = Math.min(100, Math.round((val / maxBytes) * 100));
    fillEl.style.width = `${pct}%`;
    fillEl.className = 'meter-fill';
    if (val > maxBytes) fillEl.classList.add('err');
    else if (pct >= 80) fillEl.classList.add('warn');
    else if (val > 0) fillEl.classList.add('ok');
    return pct;
  }

  // ---------- 渲染：共享顶栏 ----------
  function renderShellHeader() {
    const d = ui.data;
    const cfg = d.conversation;
    const preview = d.preview;
    const cloud = d.cloud;

    const dot = $('status-dot');
    const pill = $('status-pill');
    const sw = $('master-enabled');
    dot.className = 'status-dot';
    pill.className = 'status-pill';

    sw.disabled = false;
    sw.checked = Boolean(cfg.enabled);

    if (preview?.status === 'active') {
      dot.classList.add('active');
      pill.classList.add('active');
      pill.textContent = d.isStaging ? '待命生效' : '生效中';
    } else if (preview?.status === 'empty' || preview?.status === 'cloud_pending') {
      dot.classList.add('warning');
      pill.classList.add('warning');
      pill.textContent = preview.status === 'cloud_pending' ? '云端同步中' : '待选核心';
    } else if (preview?.status === 'pending_deactivation') {
      dot.classList.add('warning');
      pill.classList.add('warning');
      pill.textContent = '下轮撤销';
    } else {
      pill.textContent = '已关闭';
    }

    const activeChannel = cfg.channel || 'system-instruction';
    const modeLabel = MODE_META[cfg.mode]?.label || cfg.mode;
    if (d.isStaging) {
      $('conv-meta').textContent =
        activeChannel === 'system-instruction'
          ? '空白新对话待命 · systemInstruction · 发出首句自动认领'
          : `空白新对话待命 · ${modeLabel} · 发出首句自动认领`;
      $('conv-meta').title = '空白新对话待命';
    } else {
      const titleText = d.conversationTitle ? d.conversationTitle : `对话 ${shortId(d.conversationId)}`;
      if (activeChannel === 'system-instruction') {
        const syncStateText = preview?.status === 'active' ? `已绑定（${preview.byteLength} B）` : '未开启';
        $('conv-meta').textContent = `${titleText} · systemInstruction · ${syncStateText}`;
      } else {
        const count = cfg.runtime?.injectCount || 0;
        const lastText = cfg.runtime?.lastInjectedAt ? `最近 ${fmtRelTime(cfg.runtime.lastInjectedAt)}` : '尚未注入';
        $('conv-meta').textContent = `${titleText} · ${modeLabel} · 已注入 ${count} 次 · ${lastText}`;
      }
      $('conv-meta').title = `${titleText} (${d.conversationId})`;
    }

    // 导航角标点
    const clientDot = $('tab-dot-client');
    const cnNeedAction = Boolean(d.cnToolkit?.updateCovered);
    const hasUpdate = Boolean(d.update?.available);
    clientDot.className = 'tab-dot';
    if (cnNeedAction) {
      clientDot.classList.add('warn');
    } else if (!hasUpdate) {
      clientDot.classList.add('hidden');
    }

    const settingsDot = $('tab-dot-settings');
    settingsDot.className = 'tab-dot';
    if (cloud.error) {
      settingsDot.classList.add('err');
    } else if (cloud.activated) {
      settingsDot.classList.add('hidden');
    }

    const diagDot = $('tab-dot-diag');
    diagDot.className = 'tab-dot';
    if (preview?.exceedsRuleLimit) {
      diagDot.classList.add('err');
    } else if (preview?.status === 'active') {
      diagDot.classList.add('ok');
    } else {
      diagDot.classList.add('hidden');
    }
  }

  // ---------- 渲染：Tab 1 对话 ----------
  function getVisibleCloudPrompts(cloud, globalState, { extraIncludeIds = [], ignoreFilter = false } = {}) {
    const all = Array.isArray(cloud?.prompts) ? cloud.prompts : [];
    const filterOn = Boolean(globalState?.cloud?.filterEnabled);
    if (!filterOn || ignoreFilter) {
      return all.map((p) => ({ ...p, outsideFilter: false }));
    }
    const visibleSet = new Set(globalState?.cloud?.visibleCloudIds || []);
    const extraSet = new Set(extraIncludeIds || []);
    return all
      .filter((p) => visibleSet.has(p.id) || extraSet.has(p.id))
      .map((p) => ({ ...p, outsideFilter: !visibleSet.has(p.id) }));
  }

  function matchCloudQuery(item, query) {
    const q = String(query || '').trim().toLowerCase();
    if (!q) return true;
    return String(item.title || '').toLowerCase().includes(q) || String(item.id || '').toLowerCase().includes(q);
  }

  function renderSelectedTagsHtml(ids, promptMap, defaultSet, removeAttr, { showOrder = true } = {}) {
    if (!ids.length) return '';
    return ids
      .map((id, idx) => {
        const meta = promptMap.get(id);
        const title = meta?.title || `已选核心 (${shortId(id)})`;
        const isDef = defaultSet.has(id);
        return `
          <span class="selected-tag" title="${esc(title)}">
            ${showOrder ? `<span class="core-order">${idx + 1}</span>` : ''}
            <span class="selected-tag-text">${esc(title)}</span>
            ${isDef && showOrder ? '<span class="default-badge">默认</span>' : ''}
            <button type="button" class="tag-remove" ${removeAttr}="${esc(id)}" title="移除 ${esc(title)}" aria-label="移除 ${esc(title)}">${CLOSE_X_SVG}</button>
          </span>`;
      })
      .join('');
  }

  function renderMainCloudPicker(cfg, cloud, globalState) {
    const allPrompts = cloud.prompts || [];
    const promptMap = new Map(allPrompts.map((p) => [p.id, p]));
    const selectedCloud = cfg.selectedCloudIds || [];
    const defaultIds = globalState?.defaults?.defaultCloudIds || [];
    const defaultSet = new Set(defaultIds);
    const filterOn = Boolean(globalState?.cloud?.filterEnabled);
    const visibleIds = globalState?.cloud?.visibleCloudIds || [];

    const triggerBtn = $('cloud-dropdown-trigger');
    const triggerText = $('cloud-trigger-text');
    const triggerMeta = $('cloud-trigger-meta');
    triggerBtn.setAttribute('aria-expanded', String(ui.cloudDropdownOpen));

    if (!selectedCloud.length) {
      triggerText.textContent = '选择云核心…';
      triggerText.classList.add('placeholder');
    } else if (selectedCloud.length === 1) {
      triggerText.textContent = promptMap.get(selectedCloud[0])?.title || shortId(selectedCloud[0]);
      triggerText.classList.remove('placeholder');
    } else {
      const names = selectedCloud.slice(0, 2).map((id) => promptMap.get(id)?.title || shortId(id)).join('、');
      triggerText.textContent = `已选 ${selectedCloud.length} 个（${names}${selectedCloud.length > 2 ? '…' : ''}）`;
      triggerText.classList.remove('placeholder');
    }

    triggerMeta.textContent = filterOn
      ? `常用 ${visibleIds.length}/${allPrompts.length}`
      : allPrompts.length
      ? `共 ${allPrompts.length}`
      : '';

    const tagsEl = $('cloud-selected-tags');
    if (selectedCloud.length) {
      tagsEl.innerHTML = renderSelectedTagsHtml(selectedCloud, promptMap, defaultSet, 'data-remove-cloud', { showOrder: true });
      tagsEl.classList.remove('hidden');
    } else {
      tagsEl.innerHTML = '';
      tagsEl.classList.add('hidden');
    }

    const panelEl = $('cloud-dropdown-panel');
    panelEl.classList.toggle('hidden', !ui.cloudDropdownOpen);
    if (!ui.cloudDropdownOpen) return;

    const searchInput = $('cloud-search-input');
    if (searchInput.value !== ui.mainCloudQuery && document.activeElement !== searchInput) {
      searchInput.value = ui.mainCloudQuery;
    }
    $('cloud-search-clear').classList.toggle('hidden', !ui.mainCloudQuery);

    const visiblePool = getVisibleCloudPrompts(cloud, globalState, {
      extraIncludeIds: selectedCloud,
      ignoreFilter: ui.cloudDropdownShowAll,
    });
    const matched = visiblePool.filter((p) => matchCloudQuery(p, ui.mainCloudQuery));

    const showAllBtn = $('cloud-dropdown-show-all');
    showAllBtn.classList.toggle('hidden', !filterOn);
    showAllBtn.textContent = ui.cloudDropdownShowAll ? '仅看常用' : '显示全部';

    const hintEl = $('cloud-dropdown-hint');
    if (filterOn && !ui.cloudDropdownShowAll) {
      hintEl.textContent = ui.mainCloudQuery
        ? `筛选内匹配 ${matched.length} / ${visiblePool.length}`
        : `仅显示常用 ${visibleIds.length} / ${allPrompts.length}`;
    } else {
      hintEl.textContent = ui.mainCloudQuery
        ? `匹配 ${matched.length} / ${allPrompts.length}`
        : `全部云核心 ${allPrompts.length}`;
    }

    $('cloud-clear-selected-btn').disabled = selectedCloud.length === 0;

    const listEl = $('cloud-dropdown-list');
    if (!allPrompts.length) {
      listEl.innerHTML = `<div class="combo-empty">${cloud.lease?.ok ? '当前卡密名下暂无可用的云核心' : '正在连接云端同步云核心列表…'}</div>`;
      return;
    }
    if (filterOn && !ui.cloudDropdownShowAll && visiblePool.length === 0) {
      listEl.innerHTML = `
        <div class="combo-empty">
          <span>当前筛选尚未保留任何云核心</span>
          <button type="button" class="ghost-btn sm" id="goto-filter-from-empty">去筛选常用核心</button>
        </div>`;
      return;
    }
    if (!matched.length) {
      listEl.innerHTML = '<div class="combo-empty">未找到匹配的云核心</div>';
      return;
    }

    const isRuleChannel = (cfg.channel || 'system-instruction') === 'system-instruction';
    listEl.innerHTML = matched
      .map((item) => {
        const idx = selectedCloud.indexOf(item.id);
        const on = idx >= 0;
        const isDef = defaultSet.has(item.id);
        const statusText = item.problem
          ? `<span class="core-problem">${esc(item.problem)}</span>`
          : item.outsideFilter
          ? '未在常用筛选'
          : item.cached
          ? '已缓存于内存'
          : '按需拉取';
        return `
          <div class="combo-item${on ? ' on' : ''}" role="option" tabindex="0" aria-selected="${on}" data-toggle-cloud="${esc(item.id)}">
            <span class="combo-check" aria-hidden="true">${on ? idx + 1 : ''}</span>
            <div class="combo-item-main">
              <div class="combo-item-title-row">
                <span class="combo-item-title">${esc(item.title)}</span>
                ${isDef ? '<span class="default-badge">默认</span>' : ''}
              </div>
              <div class="combo-item-meta">
                <span>v${item.version}</span>
                <span class="mem-tag">${LOCK_SVG}${isRuleChannel ? '规则热同步' : '仅内存'}</span>
                <span>${statusText}</span>
              </div>
            </div>
            <button type="button" class="star-btn${isDef ? ' on' : ''}" data-toggle-default-cloud="${esc(item.id)}" title="${isDef ? '取消新对话默认' : '设为新对话默认'}" aria-label="${isDef ? '取消新对话默认' : '设为新对话默认'}">
              ${STAR_SVG}
            </button>
          </div>`;
      })
      .join('');
  }

  function renderMainView() {
    const d = ui.data;
    const cfg = d.conversation;
    const cloud = d.cloud;

    $('staging-banner').classList.toggle('hidden', !d.isStaging);

    const cn = d.cnToolkit || {};
    const warnEl = $('main-cn-warn');
    if (cn.updateCovered) {
      $('main-cn-warn-text').textContent = '检测到 Antigravity 客户端已升级并覆盖部分补丁，可一键全套恢复。';
      warnEl.classList.remove('hidden');
    } else {
      warnEl.classList.add('hidden');
    }

    // 云核心卡片
    const leaseBadge = $('cloud-lease-badge');
    leaseBadge.className = 'inline-badge';
    if (!cloud.activated) {
      leaseBadge.textContent = '未激活';
      $('cloud-unactivated-box').classList.remove('hidden');
      $('cloud-picker-box').classList.add('hidden');
      $('open-cloud-filter-btn').classList.add('hidden');
      $('cloud-refresh-btn').classList.add('hidden');
    } else {
      $('cloud-unactivated-box').classList.add('hidden');
      $('open-cloud-filter-btn').classList.remove('hidden');
      $('cloud-refresh-btn').classList.remove('hidden');
      $('cloud-picker-box').classList.remove('hidden');
      if (cloud.lease?.ok) {
        leaseBadge.classList.add('ok');
        leaseBadge.textContent = '租约有效';
      } else if (cloud.error) {
        leaseBadge.classList.add('err');
        leaseBadge.textContent = '授权异常';
      } else {
        leaseBadge.classList.add('warn');
        leaseBadge.textContent = '续期中';
      }
      renderMainCloudPicker(cfg, cloud, d.global);
    }

    const cloudErrEl = $('cloud-error-inline');
    if (cloud.error?.message) {
      cloudErrEl.textContent = cloud.error.message;
      cloudErrEl.classList.remove('hidden');
    } else {
      cloudErrEl.classList.add('hidden');
    }

    // 本机预设
    if (!ui.presetsDetailsInit) {
      ui.presetsDetailsInit = true;
      $('local-presets-details').open = !cloud.activated || (cfg.selectedPresetIds?.length || 0) > 0;
    }
    const presets = d.global?.presets || [];
    const selectedPresets = cfg.selectedPresetIds || [];
    $('local-presets-meta').textContent = selectedPresets.length ? `已选 ${selectedPresets.length}` : `${presets.length} 个可用`;
    const chipsBox = $('preset-chips');
    if (!presets.length) {
      chipsBox.innerHTML = '<span class="empty-inline">暂无本机预设</span>';
    } else {
      chipsBox.innerHTML = presets
        .map((p) => {
          const orderIdx = selectedPresets.indexOf(p.id);
          const on = orderIdx >= 0;
          return `<button type="button" class="chip${on ? ' on' : ''}" data-toggle-preset="${esc(p.id)}" aria-pressed="${on}" title="${esc(p.description || p.name)}">${on ? `<span class="chip-order">${orderIdx + 1}</span>` : ''}<span>${esc(p.name)}</span></button>`;
        })
        .join('');
    }

    // 对话补充指令
    $('custom-enabled').checked = cfg.customEnabled !== false;
    const textarea = $('custom-prompt');
    if (!ui.dirty) {
      if (textarea.value !== (cfg.customPrompt || '')) {
        textarea.value = cfg.customPrompt || '';
      }
      updateEditorStats(textarea.value);
      setSaveState(ui.saving ? '保存中…' : '已保存', false);
    }
    if (!ui.customDetailsInit) {
      ui.customDetailsInit = true;
      $('custom-prompt-details').open = Boolean((cfg.customPrompt || '').trim());
    }
  }

  // ---------- 渲染：Tab 2 增强 ----------
  function renderClientView() {
    const d = ui.data;
    const g = d.global;
    const ds = d.desktop;
    const cn = d.cnToolkit || {};
    const dsBadge = $('desktop-mount-badge');
    const dsSub = $('desktop-mount-sub');
    const dsHint = $('desktop-mount-hint');
    const cnOk = Boolean(cn.hasCn);
    const revOk = Boolean(cn.hasFileReveal);
    const kdOk = Boolean(ds ? ds.installed : cn.hasKupadeskDesktop);
    const ruleOk = Boolean(cn.hasCnLanguageRule);
    const allOk = cnOk && revOk && kdOk;
    const cliVer = ds?.clientVersion || cn.clientVersion || 'unknown';

    const tiles = [
      { name: '中文汉化与监控', on: cnOk, warn: Boolean(cn.updateCovered && !cnOk), onText: '已就绪', offText: '未安装' },
      { name: '右键打开位置', on: revOk, warn: Boolean(cn.updateCovered && !revOk), onText: '已就绪', offText: '未安装' },
      { name: '输入框红框入口', on: kdOk, warn: Boolean(cn.updateCovered && !kdOk), onText: '已挂载', offText: '未挂载' },
      { name: '简体中文思考规则', on: ruleOk, warn: false, onText: '已开启', offText: '未开启' },
    ];
    $('cn-status-grid').innerHTML = tiles
      .map((t) => {
        const cls = t.warn ? 'warn' : t.on ? 'ok' : '';
        const stateText = t.warn ? '待恢复' : t.on ? t.onText : t.offText;
        return `
          <div class="status-tile ${cls}">
            <span class="tile-dot" aria-hidden="true"></span>
            <div class="tile-body">
              <span class="tile-name">${t.name}</span>
              <span class="tile-state">${stateText}</span>
            </div>
          </div>`;
      })
      .join('');

    dsBadge.className = 'inline-badge';
    if (!ds && !cn.clientVersion) {
      dsBadge.textContent = '检测中';
      dsSub.textContent = '正在检测本地 Antigravity 客户端状态…';
      dsHint.textContent = '';
    } else if (ds?.detectError || cn.detectError) {
      dsBadge.classList.add('err');
      dsBadge.textContent = '异常';
      dsSub.textContent = `客户端 v${cliVer}`;
      dsHint.textContent = ds?.detectError || cn.detectError;
    } else if (cn.updateCovered) {
      dsBadge.classList.add('warn');
      dsBadge.textContent = '待恢复';
      dsSub.textContent = `客户端 v${cliVer} · 检测到升级覆盖了增强补丁`;
      dsHint.textContent = '点击「一键全套安装 / 升级恢复」即可同时恢复中文汉化、右键菜单与红框入口（约 3 秒后自动重启生效）。';
    } else if (allOk) {
      dsBadge.classList.add('ok');
      dsBadge.textContent = '全套生效';
      dsSub.textContent = `客户端 v${cliVer} · 汉化 / 右键 / 红框均已就绪`;
      dsHint.textContent = '所有客户端增强补丁正常运行中（不改动官方原版备份）。';
    } else {
      dsBadge.classList.add('warn');
      dsBadge.textContent = '部分未装';
      dsSub.textContent = `客户端 v${cliVer} · 汉化${cnOk ? '√' : '×'} 右键${revOk ? '√' : '×'} 红框${kdOk ? '√' : '×'}`;
      dsHint.textContent = '推荐使用「一键全套安装 / 升级恢复」启用全部客户端增强，确认后自动重启生效。';
    }

    $('cn-auto-title').checked = cn.state?.autoChineseTitle !== false;
    $('cn-lang-rule').checked = ruleOk;

    const canWrite = Boolean(ds && !ds.detectError && ds.writable);
    $('cn-install-all-btn').classList.toggle('hidden', ui.confirmCnInstallAll);
    $('cn-install-all-btn').disabled = !canWrite;
    $('cn-confirm-all-btn').classList.toggle('hidden', !ui.confirmCnInstallAll);
    $('cn-cancel-all-btn').classList.toggle('hidden', !ui.confirmCnInstallAll);

    $('desktop-install-btn').classList.toggle('hidden', ui.confirmDesktopInstall);
    $('desktop-install-btn').disabled = !canWrite;
    $('desktop-install-btn').textContent = kdOk ? '仅重挂红框' : '仅挂载红框';
    $('desktop-confirm-install-btn').classList.toggle('hidden', !ui.confirmDesktopInstall);
    $('desktop-cancel-install-btn').classList.toggle('hidden', !ui.confirmDesktopInstall);

    const canUninstall = Boolean(kdOk && canWrite);
    $('desktop-uninstall-btn').classList.toggle('hidden', !canUninstall || ui.confirmDesktopUninstall);
    $('desktop-confirm-uninstall-btn').classList.toggle('hidden', !canUninstall || !ui.confirmDesktopUninstall);
    $('desktop-cancel-uninstall-btn').classList.toggle('hidden', !canUninstall || !ui.confirmDesktopUninstall);

    // 插件云更新卡片
    const u = d.update || {};
    const uBadge = $('update-badge');
    const uSub = $('update-sub');
    const uHint = $('update-hint');
    const uClBox = $('update-changelog-box');
    const uClText = $('update-changelog-text');
    const uErrBox = $('update-error-box');
    const uInstBtn = $('update-install-btn');
    const uCheckBtn = $('update-check-btn');

    uBadge.className = 'inline-badge';
    if (u.updating || ui.updateBusy) {
      uBadge.classList.add('warn');
      uBadge.textContent = '更新中…';
    } else if (u.checking) {
      uBadge.textContent = '检查中…';
    } else if (u.available && u.latest) {
      uBadge.classList.add('ok');
      uBadge.textContent = `新版 v${u.latest.version}`;
    } else if (u.status === 'up_to_date') {
      uBadge.classList.add('ok');
      uBadge.textContent = '已是最新';
    } else if (u.status === 'not_published') {
      uBadge.textContent = '未发布';
    } else if (u.status === 'error') {
      uBadge.classList.add('err');
      uBadge.textContent = '检查异常';
    } else {
      uBadge.textContent = `v${u.currentVersion || '2.0.0'}`;
    }

    uSub.textContent = `当前版本 v${u.currentVersion || '2.0.0'}${u.lastCheckedAt ? ` · 上次检查 ${fmtRelTime(u.lastCheckedAt)}` : ''}`;
    const recentUpd =
      u.lastUpdated?.at &&
      Number.isFinite(Date.parse(u.lastUpdated.at)) &&
      Date.now() - Date.parse(u.lastUpdated.at) < 120_000;
    uHint.textContent = recentUpd
      ? `已完成更新至 v${u.lastUpdated.toVersion}，请按 Ctrl + R 刷新客户端界面${u.lastUpdated.requiresAsarReinstall ? '；如含前端补丁变更，建议执行上方一键全套恢复' : ''}。`
      : `清单地址：${u.manifestUrl || ''}`;

    if (u.available && u.latest) {
      const kb = Math.max(1, Math.round((u.latest.size || 0) / 1024));
      uClText.innerHTML = `<strong>发现新版本 v${esc(u.latest.version)}</strong>（${kb} KB）${u.latest.changelog ? `：${esc(u.latest.changelog)}` : ''}${u.latest.requiresAsarReinstall ? ' · 含客户端前端补丁' : ''}`;
      uClBox.classList.remove('hidden');
      uInstBtn.classList.remove('hidden');
      uInstBtn.disabled = Boolean(u.updating || ui.updateBusy);
      uInstBtn.textContent = u.updating || ui.updateBusy ? '正在更新…' : `立即更新至 v${u.latest.version}`;
    } else {
      uClBox.classList.add('hidden');
      uInstBtn.classList.add('hidden');
    }

    if (u.error?.message && u.status !== 'not_published') {
      uErrBox.textContent = u.error.message;
      uErrBox.classList.remove('hidden');
    } else {
      uErrBox.classList.add('hidden');
    }
    uCheckBtn.disabled = Boolean(u.checking || u.updating || ui.updateBusy);
    uCheckBtn.textContent = u.checking ? '检查中…' : '检查更新';
    $('def-auto-update').checked = g.defaults?.autoCheckUpdates !== false;
  }

  // ---------- 渲染：Tab 3 设置 ----------
  function renderCloudFilterSection(cloud, g) {
    const section = $('card-cloud-filter');
    if (!cloud.activated) {
      section.classList.add('hidden');
      return;
    }
    section.classList.remove('hidden');

    const allPrompts = cloud.prompts || [];
    const filterOn = Boolean(g.cloud?.filterEnabled);
    const visibleIds = g.cloud?.visibleCloudIds || [];
    const visibleSet = new Set(visibleIds);
    const defaultIds = g.defaults?.defaultCloudIds || [];
    const defaultSet = new Set(defaultIds);

    const badge = $('cloud-filter-badge');
    badge.className = 'inline-badge';
    if (filterOn) {
      badge.classList.add('ok');
      badge.textContent = `仅显示 ${visibleIds.length} / ${allPrompts.length}`;
    } else {
      badge.textContent = `显示全部 ${allPrompts.length}`;
    }

    $('cloud-filter-enabled').checked = filterOn;
    $('cloud-filter-reset').disabled = !filterOn && visibleIds.length === 0;

    const searchEl = $('cloud-filter-search');
    if (searchEl.value !== ui.filterQuery && document.activeElement !== searchEl) {
      searchEl.value = ui.filterQuery;
    }
    $('cloud-filter-search-clear').classList.toggle('hidden', !ui.filterQuery);

    document.querySelectorAll('[data-filter-tab]').forEach((btn) => {
      const on = btn.dataset.filterTab === ui.filterTab;
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-pressed', String(on));
    });

    const filtered = allPrompts.filter((p) => {
      if (ui.filterTab === 'kept' && !visibleSet.has(p.id)) return false;
      if (ui.filterTab === 'default' && !defaultSet.has(p.id)) return false;
      return matchCloudQuery(p, ui.filterQuery);
    });

    $('cloud-filter-select-all').disabled = filtered.length === 0;

    const listEl = $('cloud-filter-list');
    if (!allPrompts.length) {
      listEl.innerHTML = `<div class="combo-empty">${cloud.lease?.ok ? '当前卡密名下暂无云核心' : '正在同步云核心目录…'}</div>`;
      return;
    }
    if (!filtered.length) {
      const emptyMsg =
        ui.filterTab === 'kept'
          ? '暂未勾选任何保留的核心'
          : ui.filterTab === 'default'
          ? '尚未设置任何新对话默认核心'
          : '未找到匹配的云核心';
      listEl.innerHTML = `<div class="combo-empty">${emptyMsg}</div>`;
      return;
    }

    listEl.innerHTML = filtered
      .map((p) => {
        const kept = visibleSet.has(p.id);
        const isDef = defaultSet.has(p.id);
        return `
          <div class="filter-row">
            <label class="filter-check">
              <input type="checkbox" data-toggle-visible-cloud="${esc(p.id)}" ${kept ? 'checked' : ''}>
              <span class="filter-row-info">
                <span class="filter-row-title">${esc(p.title)}</span>
                <span class="filter-row-meta">v${p.version} · ${p.cached ? '已缓存于内存' : '按需拉取'}</span>
              </span>
            </label>
            <button type="button" class="default-btn${isDef ? ' on' : ''}" data-filter-toggle-default="${esc(p.id)}" aria-pressed="${isDef}">
              ${isDef ? '已默认' : '设为默认'}
            </button>
          </div>`;
      })
      .join('');
  }

  function renderSettingsView() {
    const d = ui.data;
    const g = d.global;
    const cfg = d.conversation;
    const cloud = d.cloud;

    // 1. KupaDesk 云端授权（已激活默认折叠为简洁摘要卡）
    const pill = $('settings-cloud-pill');
    pill.className = 'inline-badge';
    if (!cloud.activated) {
      pill.textContent = '未激活';
      $('cloud-status-grid').classList.add('hidden');
      $('cloud-auth-actions').classList.add('hidden');
      $('cloud-edit-panel').classList.remove('hidden');
      $('cancel-cloud-edit-btn').classList.add('hidden');
      $('card-input-label').textContent = '激活卡密（激活后仅保留尾号与加密设备私钥）';
      $('activate-card-btn').textContent = '激活卡密';
    } else {
      $('cloud-status-grid').classList.remove('hidden');
      $('cloud-auth-actions').classList.remove('hidden');
      $('cloud-edit-panel').classList.toggle('hidden', !ui.cloudFormExpanded);
      $('cancel-cloud-edit-btn').classList.toggle('hidden', !ui.cloudFormExpanded);
      $('toggle-cloud-edit-btn').textContent = ui.cloudFormExpanded ? '收起表单' : '更换卡密 / 地址';
      $('deactivate-cloud-btn').classList.toggle('hidden', ui.confirmDeactivate);
      $('confirm-deactivate-btn').classList.toggle('hidden', !ui.confirmDeactivate);
      $('card-input-label').textContent = '输入新卡密以替换当前授权';
      $('activate-card-btn').textContent = '更换并激活';

      if (cloud.lease?.ok) {
        pill.classList.add('ok');
        pill.textContent = '已激活 · 租约有效';
      } else if (cloud.error) {
        pill.classList.add('err');
        pill.textContent = '授权异常';
      } else {
        pill.classList.add('warn');
        pill.textContent = '续期中';
      }
      $('cloud-card-suffix').textContent = cloud.cardSuffix ? `****${cloud.cardSuffix}` : '-';
      $('cloud-lease-detail').textContent = cloud.lease?.ok
        ? `有效（30s 自动续期 · 已同步 ${cloud.prompts?.length || 0} 份）`
        : cloud.error?.message || '等待续期';
      $('cloud-expires-at').textContent = fmtDateTime(cloud.expiresAt);
      $('cloud-protection').textContent = cloud.protection === 'dpapi' ? 'Windows DPAPI 加密保护' : cloud.protection;
    }

    const originVal = cloud.origin || 'https://kupakupa.vip';
    $('cloud-origin-summary').textContent = originVal;
    if (!ui.originDirty) {
      $('cloud-origin-input').value = originVal;
    }
    const errBox = $('cloud-settings-error');
    if (cloud.error?.message) {
      errBox.textContent = cloud.error.message;
      errBox.classList.remove('hidden');
    } else {
      errBox.classList.add('hidden');
    }

    // 2. 新对话默认与核心筛选（合二为一）
    const def = g.defaults;
    $('def-auto-claim').checked = def.autoClaimStaging !== false;
    $('def-enabled-new').checked = Boolean(def.enabledForNew);

    const defCloudIds = def.defaultCloudIds || [];
    const promptMap = new Map((cloud.prompts || []).map((p) => [p.id, p]));
    const defTagsEl = $('def-cloud-tags');
    const defEmptyEl = $('def-cloud-empty');
    const defClearBtn = $('def-cloud-clear-btn');

    if (!cloud.activated) {
      defEmptyEl.textContent = '激活卡密后可设置新对话默认云核心';
      defEmptyEl.classList.remove('hidden');
      defTagsEl.classList.add('hidden');
      defClearBtn.classList.add('hidden');
    } else if (!defCloudIds.length) {
      defEmptyEl.textContent = '暂未设置默认云核心（在下方列表中点击「设为默认」即可添加）';
      defEmptyEl.classList.remove('hidden');
      defTagsEl.classList.add('hidden');
      defClearBtn.classList.add('hidden');
    } else {
      defEmptyEl.classList.add('hidden');
      defTagsEl.innerHTML = renderSelectedTagsHtml(defCloudIds, promptMap, new Set(defCloudIds), 'data-remove-def-cloud', { showOrder: false });
      defTagsEl.classList.remove('hidden');
      defClearBtn.classList.remove('hidden');
    }

    const defPresetBox = $('def-preset-chips');
    if (!g.presets.length) {
      defPresetBox.innerHTML = '<span class="empty-inline">暂无本机预设</span>';
    } else {
      defPresetBox.innerHTML = g.presets
        .map((p) => {
          const on = def.defaultPresetIds.includes(p.id);
          return `<button type="button" class="chip${on ? ' on' : ''}" data-toggle-def-preset="${esc(p.id)}" aria-pressed="${on}">${on ? CHECK_SVG : ''}<span>${esc(p.name)}</span></button>`;
        })
        .join('');
    }

    renderCloudFilterSection(cloud, g);

    // 3. 本机预设列表
    $('presets-count-badge').textContent = `${g.presets.length} 个`;
    const listBox = $('presets-list');
    if (!g.presets.length) {
      listBox.innerHTML = '<div class="empty-box">暂无本机预设，点击右上角「+ 新建预设」添加。</div>';
    } else {
      listBox.innerHTML = g.presets
        .map((p) => {
          const confirming = ui.confirmDeletePresetId === p.id;
          return `
            <article class="preset-item" data-preset-id="${esc(p.id)}">
              <div class="row-between">
                <span class="preset-name">${esc(p.name)}</span>
                <span class="editor-stats">${p.content.length} 字符</span>
              </div>
              ${p.description ? `<p class="preset-desc">${esc(p.description)}</p>` : ''}
              <pre class="preset-snippet">${esc(p.content.trim() || '（空内容）')}</pre>
              <div class="btn-row">
                <button type="button" class="ghost-btn sm" data-edit-preset="${esc(p.id)}">编辑</button>
                <button type="button" class="ghost-btn sm" data-dup-preset="${esc(p.id)}">复制</button>
                <span class="spacer"></span>
                ${
                  confirming
                    ? `<button type="button" class="danger-btn sm" data-confirm-del-preset="${esc(p.id)}">确认删除</button><button type="button" class="ghost-btn sm" data-cancel-del-preset>取消</button>`
                    : `<button type="button" class="ghost-btn sm" data-del-preset="${esc(p.id)}">删除</button>`
                }
              </div>
            </article>`;
        })
        .join('');
    }

    // 4. 高级注入策略（默认折叠）
    const activeChannel = cfg.channel || 'system-instruction';
    $('channel-mode-badge').textContent = activeChannel === 'system-instruction' ? 'systemInstruction' : 'Hook 兼容';
    document.querySelectorAll('[data-channel]').forEach((btn) => {
      const on = btn.dataset.channel === activeChannel;
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-pressed', String(on));
    });
    $('channel-card-sub').textContent = CHANNEL_META[activeChannel]?.sub || '';
    $('channel-desc').textContent = CHANNEL_META[activeChannel]?.desc || '';
    $('rule-options-box').classList.toggle('hidden', activeChannel !== 'system-instruction');
    $('hook-options-box').classList.toggle('hidden', activeChannel !== 'hook');

    $('def-protect-focus').checked = def.protectRunningFocus !== false;

    document.querySelectorAll('[data-mode]').forEach((btn) => {
      const on = btn.dataset.mode === cfg.mode;
      btn.classList.toggle('on', on);
      btn.setAttribute('aria-pressed', String(on));
    });
    $('mode-desc').textContent = MODE_META[cfg.mode]?.desc || '';
    $('opt-wrap').checked = cfg.wrapAsHighestPriority !== false;
    $('opt-deact').checked = cfg.sendDeactivationNotice !== false;
  }

  // ---------- 渲染：Tab 4 诊断 ----------
  function renderDiagView() {
    const d = ui.data;
    const preview = d.preview;
    const cfg = d.conversation;
    const activeChannel = cfg.channel || 'system-instruction';

    $('preview-reason').textContent = preview?.statusReason || '';

    const capBox = $('diag-capacity-box');
    if (activeChannel === 'system-instruction') {
      capBox.classList.remove('hidden');
      const limit = Number(preview?.ruleByteLimit) || 24000;
      const bytes = Number(preview?.byteLength) || 0;
      const pct = applyMeter($('diag-cap-fill'), bytes, limit);
      $('diag-cap-text').textContent = `${bytes.toLocaleString()} / ${limit.toLocaleString()} B (${pct}%)`;
    } else {
      capBox.classList.add('hidden');
    }

    if (preview?.finalMessage) {
      if (activeChannel === 'system-instruction') {
        const truncWarn = preview.exceedsRuleLimit ? ' · ⚠ 超出 24KB 上限将被截断' : '';
        const protectHint = preview.containsCloud ? '（云核心正文已脱敏）' : '';
        $('preview-meta').textContent = `${preview.charCount} 字符 · 约 ${preview.estimatedTokens} tokens${truncWarn}${protectHint}`;
      } else {
        $('preview-meta').textContent = `${preview.charCount} 字符 · 约 ${preview.estimatedTokens} tokens${preview.containsCloud ? '（云核心正文已脱敏保护）' : ''}`;
      }
      $('preview-code').textContent = preview.finalMessage;
      $('copy-preview-btn').disabled = false;
    } else {
      $('preview-meta').textContent = '无待同步/注入内容';
      $('preview-code').textContent =
        activeChannel === 'system-instruction'
          ? '（当前未开启或未选中有效核心，rules/AGENTS.md 已移除，顶层 systemInstruction 零残留）'
          : '（当前关闭或未选中有效核心，Hook 将返回 {} 零开销放行）';
      $('copy-preview-btn').disabled = true;
    }

    const clearBtn = $('clear-logs-btn');
    const logsBox = $('logs-list');
    const logsBadge = $('logs-count-badge');
    if (d.isStaging) {
      logsBadge.textContent = '待命';
      clearBtn.classList.add('hidden');
      logsBox.innerHTML = '<div class="empty-box">当前处于空白新对话待命模式，发第一句话绑定对话后，这里将记录每次同步与 Hook 执行详情。</div>';
      return;
    }

    const history = [...(cfg.runtime?.history || [])].reverse();
    logsBadge.textContent = `${history.length} 条`;
    clearBtn.classList.toggle('hidden', history.length === 0);
    clearBtn.textContent = ui.confirmClearLogs ? '确认清空？' : '清空日志';
    clearBtn.classList.toggle('danger-btn', ui.confirmClearLogs);
    clearBtn.classList.toggle('ghost-btn', !ui.confirmClearLogs);

    if (!history.length) {
      logsBox.innerHTML = '<div class="empty-box">当前对话尚未触发过规则同步或系统提示词注入。</div>';
      return;
    }

    const badgeStyleMap = {
      injected: 'injected',
      synced: 'injected',
      fallback: 'fallback',
      anchored: 'anchored',
      deactivated: 'deactivated',
      cleared: 'deactivated',
      skipped: 'skipped',
    };

    logsBox.innerHTML = history
      .map((item) => {
        const badgeCls = badgeStyleMap[item.action] || 'skipped';
        const actionText = ACTION_LABEL[item.action] || item.action;
        const reasonText = REASON_LABEL[item.reason] || item.reason || '';
        const sizeLabel = item.bytes ? `${item.bytes} B` : item.chars ? `${item.chars} 字符` : '';
        return `
          <details class="log-item">
            <summary class="log-summary">
              <div class="log-head">
                <span class="log-badge ${badgeCls}">${esc(actionText)}</span>
                <span class="log-event">${esc(item.event)}</span>
                ${reasonText ? `<span class="log-reason">· ${esc(reasonText)}</span>` : ''}
                ${item.isProtected ? `<span class="mem-tag">${LOCK_SVG}受保护</span>` : ''}
                <span class="spacer"></span>
                ${sizeLabel ? `<span class="log-chars">${sizeLabel}</span>` : ''}
                <span class="log-time" title="${esc(fmtDateTime(item.time))}">${esc(fmtRelTime(item.time))}</span>
              </div>
              <div class="log-preview">${esc(item.messagePreview || '无内容')}</div>
            </summary>
            <div class="log-body">
              <pre class="log-full">${esc(item.messageFull || item.messagePreview || '')}</pre>
            </div>
          </details>`;
      })
      .join('');
  }

  function renderAll() {
    if (!ui.data) return;
    $('loading').classList.add('hidden');
    $('app').classList.remove('hidden');
    renderShellHeader();
    renderMainView();
    renderClientView();
    renderSettingsView();
    renderDiagView();
  }

  // ---------- 同步与写入 ----------
  function applyRequestedPanelView(req) {
    if (!req || typeof req !== 'object') return;
    const at = Number(req.at) || 0;
    if (!at || at <= ui.lastHandledViewAt) return;
    if (Date.now() - at > 15_000) {
      ui.lastHandledViewAt = at;
      return;
    }
    ui.lastHandledViewAt = at;
    const targetView = VALID_VIEWS.includes(req.view) ? req.view : 'settings';
    switchView(targetView);
    if (req.focusTarget === 'activate' && targetView === 'settings') {
      ui.cloudFormExpanded = true;
      renderSettingsView();
      setTimeout(() => $('cloud-card-input')?.focus(), 50);
    }
  }

  async function loadState({ force = false } = {}) {
    try {
      const convId = currentConvId();
      const qs = new URLSearchParams();
      if (convId) qs.set('conversationId', convId);
      if (!force && ui.etag) qs.set('etag', ui.etag);
      const res = await apiGet(`/api/state?${qs.toString()}`);
      if (res.unchanged) return;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      applyRequestedPanelView(res.requestedPanelView);
    } catch (err) {
      if (!ui.data) {
        $('loading').querySelector('.loading-caption').textContent = `加载失败：${err.message}`;
      }
    }
  }

  async function saveActiveConfig(patch, toastMsg = '') {
    clearTimeout(ui.saveTimer);
    ui.saving = true;
    setSaveState('保存中…', ui.dirty);
    try {
      const convId = currentConvId();
      const isStaging = ui.data ? ui.data.isStaging : !convId;
      const payload = { ...patch };
      if (!isStaging && convId) payload.conversationId = convId;
      if (ui.dirty && payload.customPrompt === undefined) {
        payload.customPrompt = $('custom-prompt').value;
      }
      const endpoint = isStaging ? '/api/staging' : '/api/conversation';
      const res = await apiPost(endpoint, payload);
      ui.dirty = false;
      ui.saving = false;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      if (toastMsg) toast(toastMsg);
    } catch (err) {
      ui.saving = false;
      setSaveState(`保存失败：${err.message}`, true);
      toast(`保存失败：${err.message}`);
    }
  }

  async function patchDefaults(patch, toastMsg = '') {
    try {
      const res = await apiPost('/api/defaults', { conversationId: currentConvId(), ...patch });
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      if (toastMsg) toast(toastMsg);
    } catch (err) {
      toast(`更新失败：${err.message}`);
    }
  }

  async function updateCloudPrefs(patch, toastMsg = '') {
    try {
      const res = await apiPost('/api/cloud/preferences', { conversationId: currentConvId(), ...patch });
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      if (toastMsg) toast(toastMsg);
    } catch (err) {
      toast(`更新失败：${err.message}`);
    }
  }

  async function toggleDefaultCloudId(cloudId) {
    if (!ui.data?.global) return;
    const g = ui.data.global;
    const prevDefs = g.defaults?.defaultCloudIds || [];
    const adding = !prevDefs.includes(cloudId);
    const nextDefs = toggleIdInArray(prevDefs, cloudId);
    const patch = { defaultCloudIds: nextDefs };
    let msg = adding ? '已设为新对话默认' : '已取消新对话默认';

    const visibleIds = g.cloud?.visibleCloudIds || [];
    if (adding && g.cloud?.filterEnabled && !visibleIds.includes(cloudId)) {
      patch.visibleCloudIds = [...visibleIds, cloudId];
      msg = '已设为新对话默认，并加入常用筛选';
    }
    await updateCloudPrefs(patch, msg);
  }

  function goToCloudFilterSection() {
    ui.cloudDropdownOpen = false;
    switchView('settings');
    if (ui.data) renderAll();
    setTimeout(() => {
      $('card-cloud-filter').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 30);
  }

  function scheduleCustomPromptSave() {
    ui.dirty = true;
    setSaveState('未保存…', true);
    updateEditorStats($('custom-prompt').value);
    clearTimeout(ui.saveTimer);
    ui.saveTimer = setTimeout(() => {
      saveActiveConfig({ customPrompt: $('custom-prompt').value });
    }, AUTOSAVE_MS);
  }

  function toggleIdInArray(list, id) {
    const next = [...(list || [])];
    const idx = next.indexOf(id);
    if (idx >= 0) next.splice(idx, 1);
    else next.push(id);
    return next;
  }

  // ---------- 一级 Tab 导航与快捷跳转 ----------
  $('nav-tabs').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-view]');
    if (!btn) return;
    switchView(btn.dataset.view);
  });

  $('main-goto-client-btn').addEventListener('click', () => switchView('client'));
  $('open-cloud-filter-btn').addEventListener('click', goToCloudFilterSection);
  $('manage-presets-btn').addEventListener('click', (e) => {
    e.preventDefault();
    e.stopPropagation();
    switchView('settings');
    setTimeout(() => {
      $('card-presets-manage').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }, 30);
  });
  $('goto-activate-btn').addEventListener('click', () => {
    switchView('settings');
    ui.cloudFormExpanded = true;
    if (ui.data) renderSettingsView();
    setTimeout(() => $('cloud-card-input')?.focus(), 40);
  });

  // ---------- Tab 1 对话控制事件 ----------
  $('master-enabled').addEventListener('change', (e) => {
    const next = e.target.checked;
    saveActiveConfig({ enabled: next }, next ? '已开启系统提示词注入' : '已关闭系统提示词注入');
  });

  $('cloud-dropdown-trigger').addEventListener('click', () => {
    ui.cloudDropdownOpen = !ui.cloudDropdownOpen;
    if (ui.data) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
    if (ui.cloudDropdownOpen) {
      setTimeout(() => $('cloud-search-input').focus(), 20);
    }
  });

  $('cloud-search-input').addEventListener('input', (e) => {
    ui.mainCloudQuery = e.target.value;
    if (ui.data) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
  });
  $('cloud-search-clear').addEventListener('click', () => {
    ui.mainCloudQuery = '';
    $('cloud-search-input').value = '';
    if (ui.data) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
    $('cloud-search-input').focus();
  });
  $('cloud-dropdown-show-all').addEventListener('click', () => {
    ui.cloudDropdownShowAll = !ui.cloudDropdownShowAll;
    if (ui.data) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
  });
  $('cloud-dropdown-goto-filter').addEventListener('click', goToCloudFilterSection);
  $('cloud-dropdown-close-btn').addEventListener('click', () => {
    ui.cloudDropdownOpen = false;
    if (ui.data) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
  });
  $('cloud-clear-selected-btn').addEventListener('click', () => {
    if (!ui.data?.conversation?.selectedCloudIds?.length) return;
    saveActiveConfig({ selectedCloudIds: [] }, '已清空当前对话云核心');
  });

  $('cloud-selected-tags').addEventListener('click', (e) => {
    const rm = e.target.closest('[data-remove-cloud]');
    if (!rm || !ui.data?.conversation) return;
    const id = rm.dataset.removeCloud;
    const next = (ui.data.conversation.selectedCloudIds || []).filter((x) => x !== id);
    saveActiveConfig({ selectedCloudIds: next });
  });

  function handleMainCloudListSelect(target) {
    if (!ui.data?.conversation) return;
    if (target.closest('#goto-filter-from-empty')) {
      goToCloudFilterSection();
      return;
    }
    const starBtn = target.closest('[data-toggle-default-cloud]');
    if (starBtn) {
      toggleDefaultCloudId(starBtn.dataset.toggleDefaultCloud);
      return;
    }
    const item = target.closest('[data-toggle-cloud]');
    if (!item) return;
    const id = item.dataset.toggleCloud;
    const next = toggleIdInArray(ui.data.conversation.selectedCloudIds, id);
    saveActiveConfig({ selectedCloudIds: next });
  }
  $('cloud-dropdown-list').addEventListener('click', (e) => handleMainCloudListSelect(e.target));
  $('cloud-dropdown-list').addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      if (e.target.closest('[data-toggle-default-cloud]')) return;
      if (e.target.closest('[data-toggle-cloud]')) {
        e.preventDefault();
        handleMainCloudListSelect(e.target);
      }
    }
  });

  document.addEventListener('click', (e) => {
    const path = e.composedPath();
    if (ui.cloudDropdownOpen && !path.includes($('cloud-picker-box'))) {
      ui.cloudDropdownOpen = false;
      if (ui.data?.conversation) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
    }
  });
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && ui.cloudDropdownOpen) {
      ui.cloudDropdownOpen = false;
      if (ui.data?.conversation) renderMainCloudPicker(ui.data.conversation, ui.data.cloud, ui.data.global);
    }
  });

  $('preset-chips').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-toggle-preset]');
    if (!btn || !ui.data?.conversation) return;
    const id = btn.dataset.togglePreset;
    const next = toggleIdInArray(ui.data.conversation.selectedPresetIds, id);
    saveActiveConfig({ selectedPresetIds: next });
  });

  $('custom-enabled').addEventListener('change', (e) => {
    saveActiveConfig({ customEnabled: e.target.checked });
  });
  $('custom-prompt').addEventListener('input', scheduleCustomPromptSave);
  $('custom-prompt').addEventListener('keydown', (e) => {
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's') {
      e.preventDefault();
      saveActiveConfig({ customPrompt: $('custom-prompt').value }, '已保存补充指令');
    }
  });
  $('save-custom-btn').addEventListener('click', () => {
    saveActiveConfig({ customPrompt: $('custom-prompt').value }, '已保存补充指令');
  });
  $('clear-custom-btn').addEventListener('click', () => {
    if (!$('custom-prompt').value) return;
    $('custom-prompt').value = '';
    updateEditorStats('');
    saveActiveConfig({ customPrompt: '' }, '已清空补充指令');
  });
  $('save-as-preset-btn').addEventListener('click', () => {
    const text = $('custom-prompt').value.trim();
    if (!text) return toast('请先输入内容再存为预设');
    switchView('settings');
    openPresetForm({ title: '将补充指令存为预设', description: '从对话补充指令保存', content: text });
    setTimeout(() => $('card-presets-manage').scrollIntoView({ behavior: 'smooth', block: 'start' }), 30);
  });

  async function refreshCloud(msg = '云核心目录已刷新') {
    try {
      const res = await apiPost('/api/cloud/refresh', { conversationId: currentConvId() });
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      toast(msg);
    } catch (err) {
      toast(`刷新失败：${err.message}`);
    }
  }
  $('cloud-refresh-btn').addEventListener('click', () => refreshCloud());
  $('settings-refresh-cloud-btn').addEventListener('click', () => refreshCloud());

  // ---------- Tab 2 增强：客户端增强与云更新 ----------
  $('update-check-btn').addEventListener('click', async () => {
    try {
      const res = await apiPost('/api/update/check', { conversationId: currentConvId() });
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      const up = res.update;
      if (up?.available && up?.latest) toast(`发现新版本 v${up.latest.version}`);
      else if (up?.status === 'up_to_date') toast('当前已是最新版本');
      else if (up?.status === 'not_published') toast('云端暂未发布更新清单');
      else if (up?.error?.message) toast(up.error.message);
    } catch (err) {
      toast(`检查更新失败：${err.message}`);
    }
  });
  $('update-install-btn').addEventListener('click', async () => {
    ui.updateBusy = true;
    renderClientView();
    try {
      const res = await apiPost('/api/update/install', { conversationId: currentConvId() });
      ui.updateBusy = false;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      const ir = res.installResult;
      if (ir?.updated) {
        toast(`已更新至 v${ir.toVersion}，后台正在热重启服务，请稍候按 Ctrl+R 刷新客户端`);
        setTimeout(() => loadState({ force: true }), 2600);
      } else {
        toast('当前已是最新版本');
      }
    } catch (err) {
      ui.updateBusy = false;
      renderClientView();
      toast(`更新失败：${err.message}`);
    }
  });
  $('def-auto-update').addEventListener('change', (e) => patchDefaults({ autoCheckUpdates: e.target.checked }));

  async function saveCnSetting(patch, msg) {
    try {
      const res = await apiPost('/api/cn/settings', { conversationId: currentConvId(), ...patch });
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      if (msg) toast(msg);
    } catch (err) {
      toast(`保存失败：${err.message}`);
      loadState({ force: true });
    }
  }
  $('cn-auto-title').addEventListener('change', (e) =>
    saveCnSetting({ autoChineseTitle: e.target.checked }, e.target.checked ? '已开启新对话自动中文标题' : '已关闭新对话自动中文标题')
  );
  $('cn-lang-rule').addEventListener('change', (e) =>
    saveCnSetting({ cnLanguageRule: e.target.checked }, e.target.checked ? '已开启全局简体中文思考规则' : '已关闭全局简体中文思考规则')
  );

  $('cn-install-all-btn').addEventListener('click', () => {
    ui.confirmCnInstallAll = true;
    ui.confirmDesktopInstall = false;
    ui.confirmDesktopUninstall = false;
    renderClientView();
  });
  $('cn-cancel-all-btn').addEventListener('click', () => {
    ui.confirmCnInstallAll = false;
    renderClientView();
  });
  $('cn-confirm-all-btn').addEventListener('click', async () => {
    try {
      const res = await apiPost('/api/cn/action', { action: 'install-all' });
      ui.confirmCnInstallAll = false;
      renderClientView();
      toast(res?.message || '已调度全套安装并重启');
    } catch (err) {
      toast(`调度失败：${err.message}`);
    }
  });

  $('desktop-install-btn').addEventListener('click', () => {
    ui.confirmDesktopInstall = true;
    ui.confirmDesktopUninstall = false;
    ui.confirmCnInstallAll = false;
    renderClientView();
  });
  $('desktop-cancel-install-btn').addEventListener('click', () => {
    ui.confirmDesktopInstall = false;
    renderClientView();
  });
  $('desktop-confirm-install-btn').addEventListener('click', async () => {
    try {
      const res = await apiPost('/api/desktop/action', { action: 'install' });
      ui.confirmDesktopInstall = false;
      renderClientView();
      toast(res?.message || '已调度挂载并重启客户端');
    } catch (err) {
      toast(`挂载失败：${err.message}`);
    }
  });

  $('desktop-uninstall-btn').addEventListener('click', () => {
    ui.confirmDesktopUninstall = true;
    ui.confirmDesktopInstall = false;
    renderClientView();
  });
  $('desktop-cancel-uninstall-btn').addEventListener('click', () => {
    ui.confirmDesktopUninstall = false;
    renderClientView();
  });
  $('desktop-confirm-uninstall-btn').addEventListener('click', async () => {
    try {
      const res = await apiPost('/api/desktop/action', { action: 'uninstall' });
      ui.confirmDesktopUninstall = false;
      renderClientView();
      toast(res?.message || '已调度移除并重启客户端');
    } catch (err) {
      toast(`移除失败：${err.message}`);
    }
  });

  // ---------- Tab 3 设置：授权、默认/筛选、预设库、高级策略 ----------
  $('toggle-cloud-edit-btn').addEventListener('click', () => {
    ui.cloudFormExpanded = !ui.cloudFormExpanded;
    renderSettingsView();
    if (ui.cloudFormExpanded) {
      setTimeout(() => $('cloud-card-input')?.focus(), 30);
    }
  });
  $('cancel-cloud-edit-btn').addEventListener('click', () => {
    ui.cloudFormExpanded = false;
    renderSettingsView();
  });

  $('cloud-origin-input').addEventListener('input', () => { ui.originDirty = true; });
  $('save-origin-btn').addEventListener('click', async () => {
    const origin = $('cloud-origin-input').value.trim();
    try {
      const res = await apiPost('/api/cloud/origin', { conversationId: currentConvId(), origin });
      ui.originDirty = false;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      toast('云端地址已更新');
    } catch (err) {
      toast(err.message);
    }
  });

  $('toggle-card-vis').addEventListener('click', () => {
    const inp = $('cloud-card-input');
    inp.type = inp.type === 'password' ? 'text' : 'password';
  });

  $('cloud-activate-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const card = $('cloud-card-input').value.trim();
    const origin = $('cloud-origin-input').value.trim();
    if (!card) return toast('请输入 KupaDesk 卡密');
    const btn = $('activate-card-btn');
    btn.disabled = true;
    try {
      const res = await apiPost('/api/cloud/activate', {
        conversationId: currentConvId(),
        card,
        origin,
      });
      $('cloud-card-input').value = '';
      $('cloud-card-input').type = 'password';
      ui.originDirty = false;
      ui.cloudFormExpanded = false;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      toast('卡密已激活，云核心已同步');
    } catch (err) {
      toast(err.message);
    } finally {
      btn.disabled = false;
    }
  });

  $('deactivate-cloud-btn').addEventListener('click', () => {
    ui.confirmDeactivate = true;
    renderSettingsView();
    setTimeout(() => {
      if (ui.confirmDeactivate) {
        ui.confirmDeactivate = false;
        renderSettingsView();
      }
    }, 3500);
  });
  $('confirm-deactivate-btn').addEventListener('click', async () => {
    try {
      const res = await apiPost('/api/cloud/deactivate', { conversationId: currentConvId() });
      ui.confirmDeactivate = false;
      ui.cloudFormExpanded = true;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      toast('已清除本机云端授权');
    } catch (err) {
      toast(`清除失败：${err.message}`);
    }
  });

  // 默认核心移除与清空
  $('def-auto-claim').addEventListener('change', (e) => patchDefaults({ autoClaimStaging: e.target.checked }));
  $('def-enabled-new').addEventListener('change', (e) => patchDefaults({ enabledForNew: e.target.checked }));

  $('def-cloud-clear-btn').addEventListener('click', () => {
    if (!ui.data?.global?.defaults?.defaultCloudIds?.length) return;
    patchDefaults({ defaultCloudIds: [] }, '已清空默认云核心');
  });
  $('def-cloud-tags').addEventListener('click', (e) => {
    const rm = e.target.closest('[data-remove-def-cloud]');
    if (!rm || !ui.data?.global) return;
    const next = (ui.data.global.defaults.defaultCloudIds || []).filter((x) => x !== rm.dataset.removeDefCloud);
    patchDefaults({ defaultCloudIds: next });
  });

  $('def-preset-chips').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-toggle-def-preset]');
    if (!btn || !ui.data?.global) return;
    const next = toggleIdInArray(ui.data.global.defaults.defaultPresetIds, btn.dataset.toggleDefPreset);
    patchDefaults({ defaultPresetIds: next });
  });

  // 云核心筛选与默认设定事件
  $('cloud-filter-enabled').addEventListener('change', (e) => {
    const on = e.target.checked;
    updateCloudPrefs({ filterEnabled: on }, on ? '已开启云核心常用筛选' : '已切换为显示全部云核心');
  });
  $('cloud-filter-search').addEventListener('input', (e) => {
    ui.filterQuery = e.target.value;
    if (ui.data) renderCloudFilterSection(ui.data.cloud, ui.data.global);
  });
  $('cloud-filter-search-clear').addEventListener('click', () => {
    ui.filterQuery = '';
    $('cloud-filter-search').value = '';
    if (ui.data) renderCloudFilterSection(ui.data.cloud, ui.data.global);
    $('cloud-filter-search').focus();
  });
  $('cloud-filter-tabs').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-filter-tab]');
    if (!btn) return;
    ui.filterTab = btn.dataset.filterTab;
    if (ui.data) renderCloudFilterSection(ui.data.cloud, ui.data.global);
  });
  $('cloud-filter-select-all').addEventListener('click', () => {
    if (!ui.data?.cloud?.prompts) return;
    const allPrompts = ui.data.cloud.prompts;
    const visibleSet = new Set(ui.data.global?.cloud?.visibleCloudIds || []);
    const defaultSet = new Set(ui.data.global?.defaults?.defaultCloudIds || []);
    const matchingIds = allPrompts
      .filter((p) => {
        if (ui.filterTab === 'kept' && !visibleSet.has(p.id)) return false;
        if (ui.filterTab === 'default' && !defaultSet.has(p.id)) return false;
        return matchCloudQuery(p, ui.filterQuery);
      })
      .map((p) => p.id);
    if (!matchingIds.length) return;
    const merged = [...new Set([...visibleSet, ...matchingIds])];
    updateCloudPrefs({ filterEnabled: true, visibleCloudIds: merged }, `已保留 ${merged.length} 个云核心并启用筛选`);
  });
  $('cloud-filter-reset').addEventListener('click', () => {
    updateCloudPrefs({ filterEnabled: false }, '已恢复显示全部云核心');
  });
  $('cloud-filter-list').addEventListener('change', (e) => {
    const cb = e.target.closest('[data-toggle-visible-cloud]');
    if (!cb || !ui.data?.global) return;
    const id = cb.dataset.toggleVisibleCloud;
    const curVisible = ui.data.global.cloud?.visibleCloudIds || [];
    const nextVisible = cb.checked
      ? [...new Set([...curVisible, id])]
      : curVisible.filter((x) => x !== id);
    const patch = { visibleCloudIds: nextVisible };
    let msg = '';
    if (!ui.data.global.cloud?.filterEnabled && cb.checked) {
      patch.filterEnabled = true;
      msg = `已启用筛选，主面板仅显示已勾选的 ${nextVisible.length} 个核心`;
    }
    updateCloudPrefs(patch, msg);
  });
  $('cloud-filter-list').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-filter-toggle-default]');
    if (!btn) return;
    toggleDefaultCloudId(btn.dataset.filterToggleDefault);
  });

  // 注入层级与高级策略
  $('channel-segment').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-channel]');
    if (!btn || !ui.data?.conversation) return;
    const channel = btn.dataset.channel;
    const current = ui.data.conversation.channel || 'system-instruction';
    if (channel !== current) {
      const msg =
        channel === 'system-instruction'
          ? '已切换为顶层 systemInstruction（rules/AGENTS.md）'
          : '已切换为 Hook 轨迹兼容模式';
      saveActiveConfig({ channel }, msg);
    }
  });

  $('def-protect-focus').addEventListener('change', (e) => patchDefaults({ protectRunningFocus: e.target.checked }));

  $('mode-segment').addEventListener('click', (e) => {
    const btn = e.target.closest('[data-mode]');
    if (!btn || !ui.data?.conversation) return;
    const mode = btn.dataset.mode;
    if (mode !== ui.data.conversation.mode) {
      saveActiveConfig({ mode }, `已切换为「${MODE_META[mode]?.label || mode}」`);
    }
  });
  $('opt-wrap').addEventListener('change', (e) => saveActiveConfig({ wrapAsHighestPriority: e.target.checked }));
  $('opt-deact').addEventListener('change', (e) => saveActiveConfig({ sendDeactivationNotice: e.target.checked }));

  // 本机预设管理表单
  function openPresetForm({ id = '', name = '', description = '', content = '', title = '新建预设' } = {}) {
    $('preset-edit-id').value = id;
    $('preset-edit-name').value = name;
    $('preset-edit-desc').value = description;
    $('preset-edit-content').value = content;
    $('preset-form-title').textContent = title;
    $('preset-form').classList.remove('hidden');
    $('preset-edit-name').focus();
  }
  function closePresetForm() {
    $('preset-form').classList.add('hidden');
    $('preset-edit-id').value = '';
    $('preset-edit-name').value = '';
    $('preset-edit-desc').value = '';
    $('preset-edit-content').value = '';
  }

  $('new-preset-btn').addEventListener('click', () => openPresetForm());
  $('preset-form-close').addEventListener('click', closePresetForm);
  $('preset-form-cancel').addEventListener('click', closePresetForm);

  $('preset-form').addEventListener('submit', async (e) => {
    e.preventDefault();
    const name = $('preset-edit-name').value.trim();
    const description = $('preset-edit-desc').value.trim();
    const content = $('preset-edit-content').value;
    const id = $('preset-edit-id').value.trim();
    if (!name) return toast('请输入预设名称');
    try {
      const res = await apiPost('/api/presets/upsert', {
        conversationId: currentConvId(),
        id: id || undefined,
        name,
        description,
        content,
      });
      ui.etag = res.etag || '';
      ui.data = res;
      closePresetForm();
      renderAll();
      toast(id ? '预设已更新' : '预设已创建');
    } catch (err) {
      toast(`保存失败：${err.message}`);
    }
  });

  $('presets-list').addEventListener('click', async (e) => {
    const presets = ui.data?.global?.presets || [];
    const editBtn = e.target.closest('[data-edit-preset]');
    if (editBtn) {
      const p = presets.find((x) => x.id === editBtn.dataset.editPreset);
      if (p) openPresetForm({ ...p, title: `编辑预设：${p.name}` });
      return;
    }
    const dupBtn = e.target.closest('[data-dup-preset]');
    if (dupBtn) {
      const p = presets.find((x) => x.id === dupBtn.dataset.dupPreset);
      if (p) openPresetForm({ title: '复制预设', name: `${p.name} 副本`, description: p.description, content: p.content });
      return;
    }
    const delBtn = e.target.closest('[data-del-preset]');
    if (delBtn) {
      ui.confirmDeletePresetId = delBtn.dataset.delPreset;
      renderSettingsView();
      return;
    }
    if (e.target.closest('[data-cancel-del-preset]')) {
      ui.confirmDeletePresetId = '';
      renderSettingsView();
      return;
    }
    const confirmDel = e.target.closest('[data-confirm-del-preset]');
    if (confirmDel) {
      try {
        const res = await apiPost('/api/presets/delete', {
          conversationId: currentConvId(),
          id: confirmDel.dataset.confirmDelPreset,
        });
        ui.confirmDeletePresetId = '';
        ui.etag = res.etag || '';
        ui.data = res;
        renderAll();
        toast('已删除预设');
      } catch (err) {
        toast(`删除失败：${err.message}`);
      }
    }
  });

  // ---------- Tab 4 诊断事件 ----------
  $('copy-preview-btn').addEventListener('click', async () => {
    const text = ui.data?.preview?.finalMessage || '';
    if (!text) return;
    try {
      await navigator.clipboard.writeText(text);
      toast('已复制安全预览');
    } catch {
      toast('复制失败');
    }
  });

  $('clear-logs-btn').addEventListener('click', async () => {
    if (!ui.confirmClearLogs) {
      ui.confirmClearLogs = true;
      renderDiagView();
      setTimeout(() => {
        if (ui.confirmClearLogs) {
          ui.confirmClearLogs = false;
          renderDiagView();
        }
      }, 3000);
      return;
    }
    const convId = currentConvId();
    if (!convId) return;
    try {
      const res = await apiPost('/api/conversation/clear-history', { conversationId: convId });
      ui.confirmClearLogs = false;
      ui.etag = res.etag || '';
      ui.data = res;
      renderAll();
      toast('已清空当前对话日志');
    } catch (err) {
      toast(`清空失败：${err.message}`);
    }
  });

  // ---------- 启动与轮询 ----------
  const initialViewParam = params.get('view');
  if (VALID_VIEWS.includes(initialViewParam)) {
    switchView(initialViewParam);
  }
  loadState({ force: true });
  setInterval(() => {
    if (!document.hidden) loadState();
  }, POLL_MS);
  document.addEventListener('visibilitychange', () => {
    if (!document.hidden) loadState({ force: true });
  });
  window.addEventListener('focus', () => {
    loadState({ force: true });
  });
  window.addEventListener('message', (e) => {
    if (e.data && e.data.type === 'kupadesk:switch-view') {
      const v = VALID_VIEWS.includes(e.data.view) ? e.data.view : 'settings';
      switchView(v);
      if (e.data.focusTarget === 'activate' && v === 'settings') {
        ui.cloudFormExpanded = true;
        if (ui.data) renderSettingsView();
        setTimeout(() => $('cloud-card-input')?.focus(), 50);
      }
    }
  });
})();

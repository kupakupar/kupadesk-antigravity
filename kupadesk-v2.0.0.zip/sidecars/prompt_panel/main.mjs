/**
 * KupaDesk Sidecar Backend.
 * - Serves the native aux-pane Web UI.
 * - Hosts the in-memory KupaDesk Cloud Protocol 1 client (prompt bodies never touch disk or UI).
 * - Exposes a local loopback-only hook bridge server for hooks/inject.mjs.
 */
import { createHash, randomBytes } from 'node:crypto';
import { readFileSync } from 'node:fs';
import { createServer } from 'node:http';
import { createRequire } from 'node:module';
import { dirname, join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { SidecarApp, Response } from 'sidecar_sdk';
import {
  DEFAULT_RECEIPT,
  cloudOrigin,
  createCloudClient,
} from '../../lib/cloud-client.mjs';
import {
  buildSafePreview,
  clearConvHistory,
  clearRuleFile,
  deletePreset,
  evaluateHookEvent,
  getDataDir,
  getPluginRoot,
  isValidConvId,
  normalizeChannel,
  readConvState,
  readGlobalState,
  readRuleSyncState,
  removeBridgeInfo,
  resolveNeededCloudIds,
  syncRuleFile,
  updateCloudSettings,
  updateConvState,
  updateDefaults,
  updateStaging,
  upsertPreset,
  writeBridgeInfo,
} from '../../lib/store.mjs';
import { createPluginUpdater } from '../../lib/updater.mjs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const require = createRequire(import.meta.url);
const TITLE_TTL_MS = 15_000;
const RUNNING_TTL_MS = 4_000;
const RUNNING_STATUS_RE = /RUNNING|BUSY|IN_PROGRESS/i;
const DESKTOP_STATUS_TTL_MS = 8_000;
const trajectoryMetaCache = {
  titles: new Map(),
  running: new Set(),
  fetchedAt: 0,
  ok: false,
  pending: null,
};
const recentHookActivity = new Map(); // convIdLower -> timestampMs
let desktopInstaller = null;
try {
  desktopInstaller = require('../../desktop/install-desktop.cjs');
} catch {
  desktopInstaller = null;
}
let cnCore = null;
try {
  cnCore = require('../../lib/cn-core.cjs');
} catch {
  cnCore = null;
}
let desktopStatusCache = { at: 0, value: null };
let cnStatusCache = { at: 0, value: null };

function getCachedDesktopStatus({ force = false } = {}) {
  if (!desktopInstaller) {
    return { supported: false, detectError: '桌面挂载模块未就绪', installed: false };
  }
  const now = Date.now();
  if (!force && desktopStatusCache.value && now - desktopStatusCache.at < DESKTOP_STATUS_TTL_MS) {
    return desktopStatusCache.value;
  }
  try {
    const val = desktopInstaller.inspectDesktopStatus({ skipLog: true });
    desktopStatusCache = { at: now, value: val };
    return val;
  } catch (err) {
    return { supported: false, detectError: err?.message || '检测失败', installed: false };
  }
}

function getCachedCnStatus({ force = false } = {}) {
  if (!cnCore) {
    return { detectError: '中文增强模块未就绪', updateCovered: false };
  }
  const now = Date.now();
  if (!force && cnStatusCache.value && now - cnStatusCache.at < DESKTOP_STATUS_TTL_MS) {
    return cnStatusCache.value;
  }
  try {
    const val = cnCore.inspectEnvironment({ syncInitialState: true, skipLog: true });
    cnStatusCache = { at: now, value: val };
    return val;
  } catch (err) {
    return { detectError: err?.message || '检测失败', updateCovered: false };
  }
}

function refreshTrajectoryMeta() {
  if (trajectoryMetaCache.pending) return trajectoryMetaCache.pending;
  const addr = process.env.ANTIGRAVITY_LS_ADDRESS || 'localhost:5387';
  const csrf = process.env.ANTIGRAVITY_CSRF_TOKEN || '';
  const pending = (async () => {
    try {
      const res = await fetch(`http://${addr}/exa.language_server_pb.LanguageServerService/GetAllCascadeTrajectories`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...(csrf ? { 'x-codeium-csrf-token': csrf } : {}),
        },
        body: '{}',
        signal: AbortSignal.timeout(2000),
      });
      if (!res.ok) return;
      const data = await res.json();
      const summaries = data?.trajectorySummaries;
      if (summaries && typeof summaries === 'object') {
        const nextTitles = new Map(trajectoryMetaCache.titles);
        const nextRunning = new Set();
        for (const [id, item] of Object.entries(summaries)) {
          const key = String(id).toLowerCase();
          const title = String(item?.annotations?.title || item?.summary || '').trim();
          if (title) nextTitles.set(key, title);
          if (RUNNING_STATUS_RE.test(String(item?.status || ''))) {
            nextRunning.add(key);
          }
        }
        trajectoryMetaCache.titles = nextTitles;
        trajectoryMetaCache.running = nextRunning;
        trajectoryMetaCache.ok = true;
        trajectoryMetaCache.fetchedAt = Date.now();
      }
    } catch {
      // Ignore transient LS RPC error and keep previous cache.
    } finally {
      trajectoryMetaCache.pending = null;
    }
  })();
  trajectoryMetaCache.pending = pending;
  return pending;
}

async function ensureFreshRunningMeta() {
  const now = Date.now();
  if (trajectoryMetaCache.fetchedAt > 0 && now - trajectoryMetaCache.fetchedAt < RUNNING_TTL_MS) {
    return;
  }
  const req = refreshTrajectoryMeta();
  await Promise.race([req, new Promise((resolve) => setTimeout(resolve, 350))]);
}

function getCachedConvTitle(convId) {
  const key = String(convId || '').trim().toLowerCase();
  if (!key) return '';
  return trajectoryMetaCache.titles.get(key) || '';
}

function isConvRunning(convId) {
  const key = String(convId || '').trim().toLowerCase();
  if (!key) return false;
  if (trajectoryMetaCache.ok) {
    return trajectoryMetaCache.running.has(key);
  }
  return Date.now() - (recentHookActivity.get(key) || 0) < 15_000;
}

async function resolveConvTitle(convId) {
  const key = String(convId || '').trim().toLowerCase();
  if (!isValidConvId(key)) return '';
  const now = Date.now();
  const isFresh = trajectoryMetaCache.fetchedAt > 0 && now - trajectoryMetaCache.fetchedAt < TITLE_TTL_MS;
  const cached = trajectoryMetaCache.titles.get(key) || '';
  if (isFresh && cached) return cached;
  if (!isFresh || !cached) {
    const req = refreshTrajectoryMeta();
    if (!trajectoryMetaCache.fetchedAt || !cached) {
      await Promise.race([req, new Promise((resolve) => setTimeout(resolve, 600))]);
    }
  }
  return trajectoryMetaCache.titles.get(key) || '';
}

function computeEtag(payload) {
  return createHash('sha256').update(JSON.stringify(payload)).digest('hex').slice(0, 24);
}

function jsonError(status, message, code = 'bad_request') {
  return new Response(JSON.stringify({ error: message, code }), {
    status,
    contentType: 'application/json; charset=utf-8',
  });
}

function actionError(status, message, code = 'bad_request') {
  return Object.assign(new Error(message), { httpStatus: status, code });
}

const receiptOverride =
  process.env.PROMPT_INJECTOR_TEST_RECEIPT_PUBKEY && process.env.PROMPT_INJECTOR_TEST_RECEIPT_KID
    ? {
        kid: process.env.PROMPT_INJECTOR_TEST_RECEIPT_KID,
        publicKey: process.env.PROMPT_INJECTOR_TEST_RECEIPT_PUBKEY,
      }
    : DEFAULT_RECEIPT;

const initialGlobal = readGlobalState();
const cloudClient = createCloudClient({
  dataDir: getDataDir(),
  origin: initialGlobal.cloud.origin,
  receipt: receiptOverride,
}).start();

const pluginUpdater = createPluginUpdater({
  pluginRoot: getPluginRoot(),
  dataDir: getDataDir(),
  getOrigin: () => readGlobalState().cloud.origin,
  getAutoCheck: () => readGlobalState().defaults.autoCheckUpdates !== false,
  onBeforeRestart: () => {
    shutdown({ keepRules: true });
    process.exit(0);
  },
}).start();

let focusTarget = { source: 'staging', conversationId: '' };
let cloudSyncInFlight = false;
let requestedPanelView = { view: 'main', focusTarget: '', at: 0 };

function warmSelection(configObj) {
  if (!configObj?.enabled || !Array.isArray(configObj.selectedCloudIds) || !configObj.selectedCloudIds.length) {
    return;
  }
  const missing = configObj.selectedCloudIds.filter((id) => !cloudClient.lookupPrompt(id));
  if (missing.length) {
    void cloudClient.ensurePrompts(missing, { timeoutMs: 4000 }).catch(() => {});
  }
}

function evaluateFocusGuard(convId, globalState, ruleSync, { claimFocus = false } = {}) {
  const protectEnabled = globalState?.defaults?.protectRunningFocus !== false;
  const ownerId = ruleSync?.active && isValidConvId(ruleSync.conversationId) ? ruleSync.conversationId : '';
  if (!protectEnabled || !ownerId || ownerId.toLowerCase() === String(convId || '').toLowerCase()) {
    return {
      protected: false,
      reason: '',
      ownerConversationId: ownerId || null,
      ownerTitle: ownerId ? getCachedConvTitle(ownerId) : '',
      ownerRunning: false,
    };
  }
  const ownerRunning = isConvRunning(ownerId);
  if (ownerRunning) {
    return {
      protected: true,
      reason: 'other_conversation_running',
      ownerConversationId: ownerId,
      ownerTitle: getCachedConvTitle(ownerId),
      ownerRunning: true,
    };
  }
  if (!claimFocus) {
    return {
      protected: true,
      reason: 'browse_readonly',
      ownerConversationId: ownerId,
      ownerTitle: getCachedConvTitle(ownerId),
      ownerRunning: false,
    };
  }
  return {
    protected: false,
    reason: '',
    ownerConversationId: ownerId,
    ownerTitle: getCachedConvTitle(ownerId),
    ownerRunning: false,
  };
}

function syncRulesFor(
  rawConvId,
  reason = 'ui_sync',
  { recordHistory = true, force = true, protectedOwnerId = null } = {}
) {
  const convId = isValidConvId(rawConvId) ? rawConvId : '';
  const targetSource = convId ? 'conversation' : 'staging';
  const globalState = readGlobalState();
  const target = convId ? readConvState(convId, globalState) : globalState.staging;
  const res = syncRuleFile(target, globalState, {
    resolveCloudPrompt: (id) => cloudClient.lookupPrompt(id),
    source: targetSource,
    conversationId: convId || null,
    reason,
    recordHistory,
    force,
    protectedOwnerId,
  });
  if (!res.blocked) {
    focusTarget = { source: targetSource, conversationId: convId };
  }
  return res;
}

function needsRuleReconcile(convId, activeConfig, globalState, ruleSync) {
  const channel = normalizeChannel(activeConfig?.channel, globalState?.defaults?.channel);
  if (channel !== 'system-instruction') {
    return Boolean(ruleSync.active && (!convId || ruleSync.conversationId === convId));
  }
  if (!activeConfig?.enabled) {
    return Boolean(ruleSync.active);
  }
  const preview = buildSafePreview(activeConfig, globalState, {
    cloudState: cloudClient.getPublicState(),
    resolveCloudPrompt: (id) => cloudClient.lookupPrompt(id),
    ruleSync,
  });
  if (!preview.hasContent) {
    return Boolean(ruleSync.active);
  }
  const hasReadyBody = Boolean(
    (activeConfig.selectedCloudIds || []).some((id) => cloudClient.lookupPrompt(id)?.content) ||
      (activeConfig.selectedPresetIds || []).length ||
      (activeConfig.customEnabled !== false && String(activeConfig.customPrompt || '').trim())
  );
  if (!hasReadyBody) return false;
  if (!ruleSync.active) return true;
  if (convId && ruleSync.conversationId !== convId) return true;
  return false;
}

async function buildStateResponse(rawConvId, clientEtag = '', { claimFocus = false } = {}) {
  const convId = isValidConvId(rawConvId) ? rawConvId : '';
  let globalState = readGlobalState();
  let activeConfig = convId ? readConvState(convId, globalState) : globalState.staging;
  let ruleSync = readRuleSyncState();

  if (
    ruleSync.active &&
    ruleSync.conversationId &&
    ruleSync.conversationId.toLowerCase() !== convId.toLowerCase()
  ) {
    await ensureFreshRunningMeta();
  }

  let focusGuard = evaluateFocusGuard(convId, globalState, ruleSync, { claimFocus });
  const focusChanged = focusTarget.conversationId !== convId;
  if (!focusGuard.protected && (focusChanged || needsRuleReconcile(convId, activeConfig, globalState, ruleSync))) {
    ruleSync = syncRulesFor(convId, focusChanged ? 'focus_switch' : 'state_reconcile', {
      recordHistory: false,
      force: true,
    });
    globalState = readGlobalState();
    activeConfig = convId ? readConvState(convId, globalState) : globalState.staging;
    focusGuard = evaluateFocusGuard(convId, globalState, ruleSync, { claimFocus });
  }

  const cloudState = cloudClient.getPublicState();
  const isStaging = !convId;
  const preview = buildSafePreview(activeConfig, globalState, {
    cloudState,
    resolveCloudPrompt: (id) => cloudClient.lookupPrompt(id),
    ruleSync,
    focusGuard,
  });
  const conversationTitle = convId ? await resolveConvTitle(convId) : '';

  warmSelection(activeConfig);

  const core = {
    conversationId: convId || null,
    conversationTitle,
    isStaging,
    global: globalState,
    conversation: activeConfig,
    staging: globalState.staging,
    cloud: cloudState,
    ruleSync,
    focusGuard,
    preview,
    desktop: getCachedDesktopStatus(),
    cnToolkit: getCachedCnStatus(),
    update: pluginUpdater.getPublicState(),
    requestedPanelView,
  };
  const etag = computeEtag(core);
  if (clientEtag && clientEtag === etag) {
    return { conversationId: convId || null, isStaging, unchanged: true, etag };
  }
  return { ...core, etag };
}

cloudClient.subscribe(() => {
  if (cloudSyncInFlight) return;
  cloudSyncInFlight = true;
  void (async () => {
    try {
      const curRule = readRuleSyncState();
      const convId = curRule.active && curRule.conversationId ? curRule.conversationId : focusTarget.conversationId;
      const globalState = readGlobalState();
      const target = convId ? readConvState(convId, globalState) : globalState.staging;
      const channel = normalizeChannel(target?.channel, globalState?.defaults?.channel);
      if (
        channel === 'system-instruction' &&
        target?.enabled &&
        Array.isArray(target.selectedCloudIds) &&
        target.selectedCloudIds.length &&
        cloudClient.getPublicState().lease?.ok
      ) {
        const missing = target.selectedCloudIds.filter((id) => !cloudClient.lookupPrompt(id));
        if (missing.length) {
          await cloudClient.ensurePrompts(missing, { timeoutMs: 3500 }).catch(() => {});
        }
      }
      syncRulesFor(convId, 'cloud_event', { recordHistory: false, force: true });
    } catch {
      // Ignore background cloud sync error.
    } finally {
      cloudSyncInFlight = false;
    }
  })();
});

// Clean up any stale rules/AGENTS.md left over from an ungraceful shutdown.
syncRulesFor('', 'sidecar_start', { recordHistory: false, force: true });

function resolveBackgroundProtectedTarget(convId) {
  const globalState = readGlobalState();
  const curRule = readRuleSyncState();
  const guard = evaluateFocusGuard(convId, globalState, curRule, { claimFocus: true });
  if (guard.protected && guard.ownerRunning && curRule.conversationId) {
    return curRule.conversationId;
  }
  return convId;
}

async function handlePanelAction(action, data = {}) {
  const convId = String(data?.conversationId || '').trim();
  switch (action) {
    case 'state': {
      const etag = typeof data?.etag === 'string' ? data.etag : '';
      const claimFocus = data?.claimFocus === true || data?.claimFocus === '1' || data?.claimFocus === 'true';
      return await buildStateResponse(convId, etag, { claimFocus });
    }
    case 'panel.openView': {
      const nextView = ['main', 'settings', 'diag'].includes(data?.view) ? data.view : 'settings';
      requestedPanelView = {
        view: nextView,
        focusTarget: typeof data?.focusTarget === 'string' ? data.focusTarget : '',
        at: Date.now(),
      };
      return { ok: true, requestedPanelView };
    }
    case 'rule.syncNow': {
      const globalState = readGlobalState();
      const target = isValidConvId(convId) ? readConvState(convId, globalState) : globalState.staging;
      if (target?.enabled && target.selectedCloudIds?.length) {
        await cloudClient.ensurePrompts(target.selectedCloudIds, { timeoutMs: 2500 }).catch(() => {});
      }
      syncRulesFor(convId, 'manual_takeover', { recordHistory: true, force: true });
      return await buildStateResponse(convId, '', { claimFocus: true });
    }
    case 'conversation': {
      if (!isValidConvId(convId)) {
        throw actionError(400, '缺少或无效的 conversationId');
      }
      const updated = updateConvState(convId, data);
      if (updated.enabled && updated.selectedCloudIds.length) {
        await cloudClient.ensurePrompts(updated.selectedCloudIds, { timeoutMs: 2500 }).catch(() => {});
      }
      syncRulesFor(convId, 'conversation_updated', { recordHistory: true, force: true });
      return await buildStateResponse(convId, '', { claimFocus: true });
    }
    case 'staging': {
      const globalState = updateStaging(data);
      if (globalState.staging.enabled && globalState.staging.selectedCloudIds.length) {
        await cloudClient.ensurePrompts(globalState.staging.selectedCloudIds, { timeoutMs: 2500 }).catch(() => {});
      }
      syncRulesFor('', 'staging_updated', { recordHistory: false, force: true });
      return await buildStateResponse(convId, '', { claimFocus: true });
    }
    case 'conversation.clearHistory': {
      if (!isValidConvId(convId)) {
        throw actionError(400, '缺少或无效的 conversationId');
      }
      clearConvHistory(convId);
      return await buildStateResponse(convId);
    }
    case 'presets.upsert': {
      const { preset } = upsertPreset(data);
      const syncId = resolveBackgroundProtectedTarget(convId);
      syncRulesFor(syncId, 'preset_updated', { recordHistory: true, force: true });
      return { ...(await buildStateResponse(convId)), savedPreset: preset };
    }
    case 'presets.delete': {
      const id = String(data?.id ?? '').trim();
      if (!id) throw actionError(400, '缺少预设 id');
      deletePreset(id);
      const syncId = resolveBackgroundProtectedTarget(convId);
      syncRulesFor(syncId, 'preset_updated', { recordHistory: true, force: true });
      return await buildStateResponse(convId);
    }
    case 'defaults': {
      if (typeof data?.requestedView === 'string' && ['main', 'settings', 'diag'].includes(data.requestedView)) {
        requestedPanelView = {
          view: data.requestedView,
          focusTarget: typeof data?.requestedFocus === 'string' ? data.requestedFocus : '',
          at: Date.now(),
        };
      }
      updateDefaults(data);
      const curRule = readRuleSyncState();
      const guard = evaluateFocusGuard(convId, readGlobalState(), curRule, { claimFocus: true });
      if (!guard.protected) {
        syncRulesFor(convId, 'defaults_updated', { recordHistory: false, force: true });
      }
      return await buildStateResponse(convId);
    }
    case 'cloud.activate': {
      const originInput = typeof data?.origin === 'string' && data.origin.trim() ? data.origin.trim() : undefined;
      if (originInput !== undefined && !cloudOrigin(originInput)) {
        throw actionError(400, '云端地址无效：仅支持 https:// 或本机回环 http:// 地址', 'invalid_origin');
      }
      try {
        await cloudClient.activateCard(data?.card, originInput);
        if (originInput) {
          updateCloudSettings({ origin: cloudOrigin(originInput) });
        }
        const syncId = resolveBackgroundProtectedTarget(convId);
        const target = isValidConvId(syncId) ? readConvState(syncId) : readGlobalState().staging;
        if (target?.enabled && target.selectedCloudIds?.length) {
          await cloudClient.ensurePrompts(target.selectedCloudIds, { timeoutMs: 3000 }).catch(() => {});
        }
        syncRulesFor(syncId, 'cloud_updated', { recordHistory: true, force: true });
        return await buildStateResponse(convId);
      } catch (err) {
        throw actionError(err?.httpStatus || 400, err?.message || '激活未完成', err?.code || 'activate_failed');
      }
    }
    case 'cloud.refresh': {
      await cloudClient.refreshCatalog({ force: true });
      const globalState = readGlobalState();
      const syncId = resolveBackgroundProtectedTarget(convId);
      const target = isValidConvId(syncId) ? readConvState(syncId, globalState) : globalState.staging;
      if (target?.selectedCloudIds?.length) {
        await cloudClient.ensurePrompts(target.selectedCloudIds, { timeoutMs: 3500 }).catch(() => {});
      }
      syncRulesFor(syncId, 'cloud_updated', { recordHistory: true, force: true });
      return await buildStateResponse(convId);
    }
    case 'cloud.origin': {
      const valid = cloudOrigin(data?.origin);
      if (!valid) {
        throw actionError(400, '云端地址无效：仅支持 https:// 或本机回环 http:// 地址', 'invalid_origin');
      }
      cloudClient.setOrigin(valid);
      updateCloudSettings({ origin: valid });
      const syncId = resolveBackgroundProtectedTarget(convId);
      syncRulesFor(syncId, 'cloud_updated', { recordHistory: true, force: true });
      return await buildStateResponse(convId);
    }
    case 'cloud.preferences': {
      const cloudPatch = {};
      if (typeof data?.filterEnabled === 'boolean') {
        cloudPatch.filterEnabled = data.filterEnabled;
      }
      if (Array.isArray(data?.visibleCloudIds)) {
        cloudPatch.visibleCloudIds = data.visibleCloudIds;
      }
      if (Object.keys(cloudPatch).length) {
        updateCloudSettings(cloudPatch);
      }
      if (Array.isArray(data?.defaultCloudIds)) {
        updateDefaults({ defaultCloudIds: data.defaultCloudIds });
      }
      return await buildStateResponse(convId);
    }
    case 'cloud.deactivate': {
      cloudClient.deactivateLocal();
      const syncId = resolveBackgroundProtectedTarget(convId);
      syncRulesFor(syncId, 'cloud_updated', { recordHistory: true, force: true });
      return await buildStateResponse(convId);
    }
    case 'desktop.status': {
      return getCachedDesktopStatus({ force: true });
    }
    case 'desktop.install':
    case 'desktop.uninstall': {
      if (!desktopInstaller) {
        throw actionError(500, '桌面挂载模块未就绪', 'desktop_unavailable');
      }
      const op = action === 'desktop.install' ? 'install' : 'uninstall';
      try {
        const res = desktopInstaller.dispatchDesktopAction(op, data || {});
        desktopStatusCache = { at: 0, value: null };
        cnStatusCache = { at: 0, value: null };
        return res;
      } catch (err) {
        throw actionError(400, err?.message || '调度桌面操作失败', 'desktop_action_failed');
      }
    }
    case 'update.check': {
      const updateResult = await pluginUpdater.checkForUpdates({ force: true, silent: false });
      return { ...(await buildStateResponse(convId)), updateResult };
    }
    case 'update.install': {
      try {
        const installResult = await pluginUpdater.installUpdate();
        return { ...(await buildStateResponse(convId)), installResult };
      } catch (err) {
        throw actionError(400, err?.message || '安装更新失败', 'update_install_failed');
      }
    }
    case 'cn.status': {
      return getCachedCnStatus({ force: true });
    }
    case 'cn.settings': {
      if (!cnCore) {
        throw actionError(500, '中文增强模块未就绪', 'cn_unavailable');
      }
      try {
        const cnStatus = cnCore.updateSettings(data || {});
        cnStatusCache = { at: Date.now(), value: cnStatus };
        return { ...(await buildStateResponse(convId)), cnStatus };
      } catch (err) {
        throw actionError(400, err?.message || '更新中文增强设置失败', 'cn_settings_failed');
      }
    }
    case 'cn.action': {
      if (!cnCore) {
        throw actionError(500, '中文增强模块未就绪', 'cn_unavailable');
      }
      try {
        const res = cnCore.dispatchAction(data || {});
        cnStatusCache = { at: 0, value: null };
        desktopStatusCache = { at: 0, value: null };
        return res;
      } catch (err) {
        throw actionError(400, err?.message || '调度中文增强操作失败', 'cn_action_failed');
      }
    }
    default:
      throw actionError(400, `未知操作: ${action}`, 'unknown_action');
  }
}

// ---------------------------------------------------------------------------
// Loopback-only internal bridge server for hooks/inject.mjs & desktop host
// ---------------------------------------------------------------------------
const hookSecret = randomBytes(32).toString('hex');
const bridgeServer = createServer(async (req, res) => {
  if (req.method !== 'POST' || (req.url !== '/eval' && req.url !== '/bridge')) {
    res.writeHead(404);
    res.end();
    return;
  }
  if (req.headers['x-hook-secret'] !== hookSecret) {
    res.writeHead(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'unauthorized' }));
    return;
  }
  let body = '';
  req.on('data', (chunk) => {
    body += chunk;
    if (body.length > 512 * 1024) {
      res.writeHead(413);
      res.end();
      req.destroy();
    }
  });
  req.on('end', async () => {
    if (req.url === '/eval') {
      try {
        const payload = body ? JSON.parse(body) : {};
        const hookConvId = String(payload?.conversationId || '').trim();
        if (isValidConvId(hookConvId)) {
          focusTarget = { source: 'conversation', conversationId: hookConvId };
          recentHookActivity.set(hookConvId.toLowerCase(), Date.now());
        }
        const neededCloudIds = resolveNeededCloudIds(payload);
        if (neededCloudIds.length) {
          await cloudClient.ensurePrompts(neededCloudIds, { timeoutMs: 4500 });
        }
        const { output } = evaluateHookEvent(payload, {
          resolveCloudPrompt: (id) => cloudClient.lookupPrompt(id),
        });
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end(JSON.stringify(output ?? {}));
      } catch {
        res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
        res.end('{}');
      }
      return;
    }

    try {
      const payload = body ? JSON.parse(body) : {};
      const act = String(payload?.action || '').trim();
      const out = await handlePanelAction(act, payload?.data || {});
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(JSON.stringify({ ok: true, data: out }));
    } catch (err) {
      res.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
      res.end(
        JSON.stringify({
          ok: false,
          error: err?.message || '操作失败',
          code: err?.code || 'bridge_error',
        })
      );
    }
  });
});

bridgeServer.listen(0, '127.0.0.1', () => {
  const addr = bridgeServer.address();
  if (addr && typeof addr === 'object') {
    writeBridgeInfo({ port: addr.port, secret: hookSecret });
  }
});

let shutdownCompleted = false;
function shutdown({ keepRules = false } = {}) {
  if (shutdownCompleted) return;
  shutdownCompleted = true;
  removeBridgeInfo(process.pid);
  cloudClient.stop();
  pluginUpdater.stop();
  if (!keepRules) {
    try {
      clearRuleFile('sidecar_shutdown');
    } catch {
      // Ignore cleanup errors on exit.
    }
  }
  try {
    bridgeServer.close();
  } catch {
    // Ignore close errors.
  }
}

process.on('exit', () => shutdown({ keepRules: false }));
process.on('SIGINT', () => {
  shutdown({ keepRules: false });
  process.exit(0);
});
process.on('SIGTERM', () => {
  shutdown({ keepRules: false });
  process.exit(0);
});

// ---------------------------------------------------------------------------
// Sidecar Web UI & HTTP API
// ---------------------------------------------------------------------------
const app = new SidecarApp();

function registerApiAction(pathName, actionName, method = 'POST') {
  app.api(
    pathName,
    async (data) => {
      try {
        return await handlePanelAction(actionName, data);
      } catch (err) {
        return jsonError(err?.httpStatus || 400, err?.message || '操作失败', err?.code || 'bad_request');
      }
    },
    method
  );
}

app.page('/', () => new Response(readFileSync(join(__dirname, 'index.html'), 'utf-8'), {
  contentType: 'text/html; charset=utf-8',
}));

app.api('/styles.css', () => new Response(readFileSync(join(__dirname, 'styles.css'), 'utf-8'), {
  contentType: 'text/css; charset=utf-8',
}), 'GET');

app.api('/app.js', () => new Response(readFileSync(join(__dirname, 'app.js'), 'utf-8'), {
  contentType: 'application/javascript; charset=utf-8',
}), 'GET');

registerApiAction('/api/state', 'state', 'GET');
registerApiAction('/api/rule/sync', 'rule.syncNow', 'POST');
registerApiAction('/api/conversation', 'conversation', 'POST');
registerApiAction('/api/staging', 'staging', 'POST');
registerApiAction('/api/conversation/clear-history', 'conversation.clearHistory', 'POST');
registerApiAction('/api/presets/upsert', 'presets.upsert', 'POST');
registerApiAction('/api/presets/delete', 'presets.delete', 'POST');
registerApiAction('/api/defaults', 'defaults', 'POST');
registerApiAction('/api/cloud/activate', 'cloud.activate', 'POST');
registerApiAction('/api/cloud/refresh', 'cloud.refresh', 'POST');
registerApiAction('/api/cloud/origin', 'cloud.origin', 'POST');
registerApiAction('/api/cloud/preferences', 'cloud.preferences', 'POST');
registerApiAction('/api/cloud/deactivate', 'cloud.deactivate', 'POST');
registerApiAction('/api/desktop/status', 'desktop.status', 'GET');
registerApiAction('/api/update/check', 'update.check', 'POST');
registerApiAction('/api/update/install', 'update.install', 'POST');
registerApiAction('/api/cn/status', 'cn.status', 'GET');
registerApiAction('/api/cn/settings', 'cn.settings', 'POST');
registerApiAction('/api/cn/action', 'cn.action', 'POST');

app.api('/api/desktop/action', async (data) => {
  const op = String(data?.action || '').trim();
  const mapped = op === 'install' ? 'desktop.install' : op === 'uninstall' ? 'desktop.uninstall' : '';
  if (!mapped) {
    return jsonError(400, '不支持的桌面挂载操作', 'invalid_desktop_action');
  }
  try {
    return await handlePanelAction(mapped, data);
  } catch (err) {
    return jsonError(err?.httpStatus || 400, err?.message || '操作失败', err?.code || 'bad_request');
  }
}, 'POST');

app.run();

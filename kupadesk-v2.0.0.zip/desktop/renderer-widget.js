(() => {
  'use strict';

  try {
    if (window.__kupadeskDesktopMounted) return;
    if (!window.__kupadeskDesktopBridge || typeof window.__kupadeskDesktopBridge.invoke !== 'function') return;
    window.__kupadeskDesktopMounted = true;

    const BAR_HOST_ATTR = 'data-kupadesk-bar';
    const PORTAL_HOST_ID = 'kupadesk-desktop-portal';
    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const EXCLUDE_SUBPANE_SELECTOR = '[data-testid="side-question-tab-content"],[data-media-drop-scope="subpane"],aside';

    const CHANNEL_META = {
      'system-instruction': {
        desc: '开启后实时写入 rules/AGENTS.md 进入顶层 systemInstruction，关闭或退出即刻删除文件（上限 24,000 B）。',
      },
      hook: {
        desc: '兼容模式：不写明文规则文件，通过 PreInvocation 在对话流前注入原生 systemMessage。',
      },
    };
    const MODE_META = {
      'every-turn': { label: '每轮置顶', desc: '每轮用户发消息前注入一次最新 systemMessage。' },
      'on-change': { label: '变更注入', desc: '仅在启用或内容发生变化时注入，最省 Token。' },
      'every-invocation': { label: '每次调用', desc: '每次模型推理前均注入，提供最强约束。' },
    };
    const ACTION_LABEL = {
      injected: '已注入',
      deactivated: '已撤销',
      skipped: '已跳过',
      synced: '已同步',
      cleared: '已移除',
      fallback: '首轮兜底',
      anchored: '防遗忘锚点',
    };
    const REASON_LABEL = {
      session_start: '新对话启动',
      staging_claimed: '认领待命配置',
      session_start_already_injected: '首步防重复',
      enabled: '开关启用',
      content_changed: '指令变更',
      every_invocation: '每次推理',
      new_turn: '新一轮',
      disabled_by_user: '用户关闭',
      content_cleared: '内容清空',
      cloud_unavailable: '云端未就绪',
      conversation_updated: '配置变更',
      staging_updated: '待命更新',
      focus_switch: '对话跟随',
      preset_updated: '预设变更',
      defaults_updated: '默认更新',
      cloud_updated: '云端更新',
      cloud_event: '云端事件',
      pre_invocation_sync: '推理校验',
      switched_to_hook: '切换至 Hook',
      first_turn_rule_cold_start: '首轮冷启动兜底',
      long_context_anchor: '长对话防遗忘',
      manual_takeover: '手动接管',
    };

    const instances = new Map(); // box -> { barHost, barRoot, convId, fixedMode }
    let activeBox = null;
    let activeConvId = '';
    let popoverOpen = false;
    let currentView = 'main'; // main | settings | diag
    let stateData = null;
    let stateEtag = '';
    let desktopStatus = null;
    let desktopStatusFetchedAt = 0;
    let offlineState = false;
    let pluginDisabled = false;
    let customDirty = false;
    let customDraft = '';
    let saveTimer = null;
    let toastTimer = null;
    let mainCloudQuery = '';
    let cloudDropdownOpen = false;
    let cloudDropdownShowAll = false;
    let filterQuery = '';
    let filterTab = 'all';
    let confirmDeactivate = false;
    let confirmClearLogs = false;
    let confirmDeletePresetId = '';
    let confirmDesktopUninstall = false;
    let confirmCnInstallAll = false;
    let updateBusy = false;
    let presetFormState = null; // null | { id, name, description, content, title }
    let syncScheduled = false;
    let pollInFlight = false;
    let lastFetchAt = 0;
    let portalHost = null;
    let portalRoot = null;
    let currentTheme = 'dark';

    const esc = (s) =>
      String(s ?? '').replace(/[&<>"']/g, (c) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
      }[c]));

    function shortId(id) {
      if (!id) return '';
      return id.length > 14 ? `${id.slice(0, 6)}…${id.slice(-4)}` : id;
    }

    function fmtRelTime(iso) {
      if (!iso) return '尚未同步';
      const ms = Date.parse(iso);
      if (!Number.isFinite(ms)) return '';
      const diff = Math.max(0, Math.floor((Date.now() - ms) / 1000));
      if (diff < 15) return '刚刚';
      if (diff < 60) return `${diff} 秒前`;
      if (diff < 3600) return `${Math.floor(diff / 60)} 分钟前`;
      if (diff < 86400) return `${Math.floor(diff / 3600)} 小时前`;
      return new Date(ms).toLocaleString('zh-CN', { month: 'numeric', day: 'numeric', hour: '2-digit', minute: '2-digit' });
    }

    function fmtDateTime(iso) {
      if (!iso) return '-';
      const ms = Date.parse(iso);
      return Number.isFinite(ms) ? new Date(ms).toLocaleString('zh-CN', { dateStyle: 'medium', timeStyle: 'short' }) : iso;
    }

    function detectTheme() {
      try {
        const probe = document.createElement('span');
        probe.style.cssText = 'position:absolute;visibility:hidden;color:var(--background, #18181b)';
        (document.body || document.documentElement).appendChild(probe);
        const c = getComputedStyle(probe).color;
        probe.remove();
        const nums = (c.match(/[\d.]+/g) || []).map(Number);
        if (nums.length >= 3) {
          const scale = c.startsWith('color(') ? 1 : 255;
          const [r, g, b] = nums.slice(0, 3).map((v) => v / scale);
          const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
          currentTheme = lum < 0.5 ? 'dark' : 'light';
        }
      } catch (_e) {}
      if (portalHost) portalHost.dataset.theme = currentTheme;
      for (const inst of instances.values()) {
        inst.barHost.dataset.theme = currentTheme;
      }
    }

    async function bridgeCall(action, payload) {
      const res = await window.__kupadeskDesktopBridge.invoke(action, payload || {});
      if (!res || res.ok === false) {
        const err = new Error(res?.error || '请求失败');
        err.offline = Boolean(res?.offline);
        err.disabled = Boolean(res?.disabled);
        err.code = res?.code || '';
        throw err;
      }
      return res.data;
    }

    function isVisible(el) {
      if (!el || !el.isConnected) return false;
      const st = getComputedStyle(el);
      if (st.display === 'none' || st.visibility === 'hidden') return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }

    function resolveConversationId(box) {
      if (!box || !box.isConnected) return '';
      const readId = (el) => {
        if (!el) return '';
        const val = el.getAttribute('data-cascade-id');
        return UUID_RE.test(val || '') ? val.toLowerCase() : '';
      };
      for (let el = box, hops = 0; el && el !== document.body && hops < 28; el = el.parentElement, hops++) {
        if (el.matches('[data-testid="conversation-view"]')) {
          return readId(el);
        }
        const direct = readId(el);
        if (direct) return direct;
        if (el.matches(EXCLUDE_SUBPANE_SELECTOR)) return '';
      }
      const m = location.pathname.match(/\/c\/([0-9a-f-]{36})/i);
      return m && UUID_RE.test(m[1]) ? m[1].toLowerCase() : '';
    }

    function findPrimaryComposers() {
      const boxes = Array.from(document.querySelectorAll('[data-testid="agent-input-box"]')).filter((box) => {
        if (!isVisible(box)) return false;
        if (box.closest(EXCLUDE_SUBPANE_SELECTOR) && !box.closest('[data-testid="conversation-view"]')) {
          return false;
        }
        return true;
      });
      return boxes;
    }

    function isVerticalContainer(el) {
      if (!el) return false;
      const st = getComputedStyle(el);
      if (st.display === 'block' || st.display === 'grid') return true;
      if (st.display.includes('flex') && st.flexDirection === 'column') return true;
      return false;
    }

    // ---------- 样式定义 ----------
    const BAR_CSS = `
      :host {
        --kd-bg: var(--background, #18181b);
        --kd-card: var(--card, #222327);
        --kd-fg: var(--foreground, #f4f4f5);
        --kd-muted: var(--muted-foreground, #a1a1aa);
        --kd-border: var(--card-border, rgba(255, 255, 255, 0.12));
        --kd-primary: var(--primary, #3b82f6);
        --kd-success: #7aae66;
        --kd-warn: #cab43e;
        --kd-font: var(--font-family, "Google Sans Flex", system-ui, -apple-system, "Segoe UI", "Microsoft YaHei UI", sans-serif);
        display: flex;
        justify-content: flex-end;
        align-items: center;
        box-sizing: border-box;
        font-family: var(--kd-font);
      }
      :host([data-theme="light"]) {
        --kd-bg: var(--background, #f7f7f8);
        --kd-card: var(--card, #ffffff);
        --kd-fg: var(--foreground, #1d1f21);
        --kd-muted: var(--muted-foreground, #5d676f);
        --kd-border: var(--card-border, rgba(0, 0, 0, 0.11));
        --kd-success: #568943;
        --kd-warn: #b09123;
      }
      .pill {
        pointer-events: auto;
        display: inline-flex;
        align-items: center;
        height: 24px;
        border-radius: 999px;
        border: 1px solid var(--kd-border);
        background: color-mix(in srgb, var(--kd-card) 86%, transparent);
        backdrop-filter: blur(8px);
        color: var(--kd-fg);
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.16);
        overflow: hidden;
        font-size: 11.5px;
        line-height: 1;
        user-select: none;
        transition: border-color 0.14s ease, background-color 0.14s ease;
      }
      .pill:hover {
        border-color: color-mix(in srgb, var(--kd-fg) 24%, transparent);
      }
      .pill-trigger {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        height: 100%;
        padding: 0 8px 0 9px;
        border: 0;
        background: transparent;
        color: inherit;
        font: inherit;
        cursor: pointer;
        max-width: 240px;
      }
      .pill-trigger:hover {
        background: color-mix(in srgb, var(--kd-fg) 6%, transparent);
      }
      .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        flex: none;
        background: color-mix(in srgb, var(--kd-muted) 60%, transparent);
      }
      .dot.ok {
        background: var(--kd-success);
        box-shadow: 0 0 0 2px color-mix(in srgb, var(--kd-success) 24%, transparent);
      }
      .dot.warn {
        background: var(--kd-warn);
        box-shadow: 0 0 0 2px color-mix(in srgb, var(--kd-warn) 24%, transparent);
      }
      .label {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-weight: 500;
        color: var(--kd-fg);
      }
      .label.muted {
        color: var(--kd-muted);
      }
      .badge {
        display: inline-flex;
        align-items: center;
        padding: 1px 4px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 600;
        background: color-mix(in srgb, var(--kd-fg) 10%, transparent);
        color: var(--kd-muted);
        flex: none;
      }
      .badge.warn {
        color: var(--kd-warn);
        background: color-mix(in srgb, var(--kd-warn) 16%, transparent);
      }
      .badge.ok {
        color: var(--kd-primary);
        background: color-mix(in srgb, var(--kd-primary) 16%, transparent);
      }
      .chev {
        width: 11px;
        height: 11px;
        flex: none;
        color: var(--kd-muted);
        transition: transform 0.16s ease;
      }
      .pill.open .chev {
        transform: rotate(180deg);
      }
      .sep {
        width: 1px;
        height: 12px;
        background: var(--kd-border);
        flex: none;
      }
      .toggle-wrap {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        padding: 0 7px 0 6px;
        cursor: pointer;
      }
      .toggle-wrap:hover {
        background: color-mix(in srgb, var(--kd-fg) 6%, transparent);
      }
      .sw-btn {
        position: relative;
        display: inline-block;
        width: 26px;
        height: 14px;
        border: 0;
        padding: 0;
        border-radius: 999px;
        background: color-mix(in srgb, var(--kd-fg) 22%, transparent);
        cursor: pointer;
        transition: background-color 0.15s ease;
      }
      .sw-btn::after {
        content: "";
        position: absolute;
        left: 2px;
        top: 2px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #ffffff;
        transition: transform 0.15s ease;
      }
      .sw-btn.on {
        background: var(--kd-primary);
      }
      .sw-btn.on::after {
        transform: translateX(12px);
      }
      .sw-btn:disabled {
        opacity: 0.45;
        cursor: default;
      }
    `;

    const POPOVER_CSS = `
      :host {
        --kd-bg: var(--background, #18181b);
        --kd-card: var(--card, #222327);
        --kd-surface: color-mix(in srgb, var(--kd-card) 92%, var(--kd-bg));
        --kd-fg: var(--foreground, #f4f4f5);
        --kd-muted: var(--muted-foreground, #a1a1aa);
        --kd-border: var(--card-border, rgba(255, 255, 255, 0.12));
        --kd-fill: color-mix(in srgb, var(--kd-fg) 7%, transparent);
        --kd-hover: color-mix(in srgb, var(--kd-fg) 10%, transparent);
        --kd-primary: var(--primary, #3b82f6);
        --kd-primary-fg: var(--primary-foreground, #ffffff);
        --kd-success: #7aae66;
        --kd-warn: #cab43e;
        --kd-error: #e05d5d;
        --kd-font: var(--font-family, "Google Sans Flex", system-ui, -apple-system, "Segoe UI", "Microsoft YaHei UI", sans-serif);
        --kd-mono: var(--editor-font-family, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
        font-family: var(--kd-font);
      }
      :host([data-theme="light"]) {
        --kd-bg: var(--background, #f7f7f8);
        --kd-card: var(--card, #ffffff);
        --kd-surface: #ffffff;
        --kd-fg: var(--foreground, #1d1f21);
        --kd-muted: var(--muted-foreground, #5d676f);
        --kd-border: var(--card-border, rgba(0, 0, 0, 0.11));
        --kd-fill: rgba(0, 0, 0, 0.05);
        --kd-hover: rgba(0, 0, 0, 0.08);
        --kd-success: #568943;
        --kd-warn: #b09123;
        --kd-error: #cb3d3d;
      }
      * { box-sizing: border-box; }
      .hidden { display: none !important; }
      .pop {
        position: fixed;
        width: 356px;
        max-width: calc(100vw - 16px);
        max-height: min(540px, calc(100vh - 64px));
        display: flex;
        flex-direction: column;
        background: var(--kd-surface);
        color: var(--kd-fg);
        border: 1px solid var(--kd-border);
        border-radius: 10px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.34);
        overflow: hidden;
        font-size: 12.5px;
        line-height: 1.45;
      }
      .hdr {
        padding: 10px 12px 8px;
        border-bottom: 1px solid var(--kd-border);
        display: flex;
        flex-direction: column;
        gap: 4px;
        flex: none;
        background: color-mix(in srgb, var(--kd-card) 70%, transparent);
      }
      .hdr-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }
      .hdr-left {
        display: flex;
        align-items: center;
        gap: 7px;
        min-width: 0;
      }
      .hdr-tools {
        display: flex;
        align-items: center;
        gap: 4px;
        flex: none;
      }
      .title {
        margin: 0;
        font-size: 13px;
        font-weight: 600;
      }
      .meta {
        font-size: 11px;
        color: var(--kd-muted);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .meta-row {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 11px;
        color: var(--kd-muted);
        min-width: 0;
      }
      .meta-title {
        max-width: 195px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .meta-sep, .meta-size {
        flex: none;
        white-space: nowrap;
      }
      .dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: color-mix(in srgb, var(--kd-muted) 55%, transparent);
        flex: none;
      }
      .dot.ok { background: var(--kd-success); }
      .dot.warn { background: var(--kd-warn); }
      .pill-badge {
        display: inline-flex;
        align-items: center;
        height: 18px;
        padding: 0 6px;
        border-radius: 999px;
        font-size: 10.5px;
        font-weight: 500;
        background: var(--kd-fill);
        color: var(--kd-muted);
        white-space: nowrap;
      }
      .pill-badge.ok { color: var(--kd-success); background: color-mix(in srgb, var(--kd-success) 15%, transparent); }
      .pill-badge.warn { color: var(--kd-warn); background: color-mix(in srgb, var(--kd-warn) 16%, transparent); }
      .pill-badge.err { color: var(--kd-error); background: color-mix(in srgb, var(--kd-error) 16%, transparent); }
      .icon-btn, .ghost-btn, .primary-btn, .danger-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        border: 0;
        border-radius: 6px;
        font: inherit;
        font-size: 11.5px;
        font-weight: 500;
        cursor: pointer;
        white-space: nowrap;
        color: var(--kd-muted);
        background: transparent;
      }
      .icon-btn { width: 26px; height: 26px; position: relative; }
      .btn-dot-update {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--kd-primary);
      }
      .icon-btn:hover, .ghost-btn:hover { background: var(--kd-hover); color: var(--kd-fg); }
      .ghost-btn { height: 24px; padding: 0 8px; }
      .primary-btn { height: 26px; padding: 0 10px; background: var(--kd-primary); color: var(--kd-primary-fg); }
      .primary-btn:hover { filter: brightness(1.07); }
      .danger-btn { height: 24px; padding: 0 8px; background: color-mix(in srgb, var(--kd-error) 14%, transparent); color: var(--kd-error); }
      .danger-btn:hover { background: color-mix(in srgb, var(--kd-error) 22%, transparent); }
      button:disabled { opacity: 0.45; cursor: default; }
      .sw {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
        font-size: 11.5px;
        color: var(--kd-muted);
        user-select: none;
      }
      .sw input { position: absolute; opacity: 0; width: 0; height: 0; }
      .sw-track {
        width: 30px;
        height: 17px;
        border-radius: 999px;
        background: color-mix(in srgb, var(--kd-fg) 22%, transparent);
        position: relative;
        transition: background-color 0.14s ease;
      }
      .sw-track::after {
        content: "";
        position: absolute;
        left: 2.5px;
        top: 2.5px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #fff;
        transition: transform 0.14s ease;
      }
      .sw input:checked + .sw-track { background: var(--kd-primary); }
      .sw input:checked + .sw-track::after { transform: translateX(13px); }
      .body {
        flex: 1 1 auto;
        overflow-y: auto;
        padding: 10px 12px 12px;
        display: flex;
        flex-direction: column;
        gap: 9px;
      }
      .card {
        border: 1px solid var(--kd-border);
        border-radius: 8px;
        background: color-mix(in srgb, var(--kd-card) 82%, transparent);
        padding: 9px 10px;
        display: flex;
        flex-direction: column;
        gap: 7px;
      }
      .card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
      }
      .card-title { font-size: 12px; font-weight: 600; margin: 0; }
      .hint { font-size: 11px; color: var(--kd-muted); margin: 0; }
      .alert {
        padding: 6px 8px;
        border-radius: 6px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-error) 14%, transparent);
        color: var(--kd-error);
      }
      .staging-bar {
        padding: 7px 9px;
        border-radius: 7px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-primary) 12%, transparent);
        border: 1px solid color-mix(in srgb, var(--kd-primary) 26%, transparent);
      }
      .guard-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 7px 9px;
        border-radius: 7px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-warn) 12%, transparent);
        border: 1px solid color-mix(in srgb, var(--kd-warn) 32%, transparent);
        color: var(--kd-fg);
      }
      .guard-bar-text {
        min-width: 0;
        flex: 1 1 auto;
        line-height: 1.4;
      }
      .opt-sub {
        padding-left: 4px;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .tags { display: flex; flex-wrap: wrap; gap: 5px; }
      .tag {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 6px;
        border-radius: 6px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-primary) 14%, transparent);
        border: 1px solid color-mix(in srgb, var(--kd-primary) 26%, transparent);
      }
      .tag-x {
        border: 0;
        background: transparent;
        color: var(--kd-muted);
        cursor: pointer;
        padding: 0 2px;
        font-size: 12px;
        line-height: 1;
      }
      .tag-x:hover { color: var(--kd-fg); }
      .combo-btn {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        height: 30px;
        padding: 0 9px;
        border-radius: 6px;
        border: 1px solid var(--kd-border);
        background: var(--kd-fill);
        color: var(--kd-fg);
        font: inherit;
        font-size: 12px;
        cursor: pointer;
      }
      .combo-panel {
        border: 1px solid var(--kd-border);
        border-radius: 7px;
        padding: 6px;
        background: var(--kd-bg);
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .cloud-float-menu {
        position: fixed;
        z-index: 2147483002;
        border-radius: 9px;
        border: 1px solid var(--kd-border);
        background: var(--kd-surface);
        color: var(--kd-fg);
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.42);
        padding: 8px;
        display: flex;
        flex-direction: column;
        gap: 6px;
        overflow: hidden;
      }
      .combo-list {
        max-height: 196px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .combo-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        padding: 5px 7px;
        border-radius: 5px;
        cursor: pointer;
      }
      .combo-item:hover { background: var(--kd-hover); }
      .combo-item.on { background: color-mix(in srgb, var(--kd-primary) 15%, transparent); }
      .combo-item-left { display: flex; align-items: center; gap: 6px; min-width: 0; flex: 1; }
      .chk {
        width: 15px;
        height: 15px;
        border-radius: 4px;
        border: 1px solid var(--kd-border);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        flex: none;
      }
      .combo-item.on .chk {
        background: var(--kd-primary);
        border-color: var(--kd-primary);
        color: var(--kd-primary-fg);
      }
      .combo-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; }
      .star-btn {
        border: 0;
        background: transparent;
        color: var(--kd-muted);
        cursor: pointer;
        padding: 2px 4px;
        font-size: 13px;
      }
      .star-btn.on { color: var(--kd-warn); }
      .input, .textarea {
        width: 100%;
        border: 1px solid var(--kd-border);
        border-radius: 6px;
        background: var(--kd-bg);
        color: var(--kd-fg);
        font: inherit;
        font-size: 12px;
        padding: 5px 8px;
        outline: none;
      }
      .input:focus, .textarea:focus { border-color: var(--kd-primary); }
      .textarea { resize: vertical; min-height: 68px; font-family: var(--kd-mono); font-size: 11.5px; }
      .chips { display: flex; flex-wrap: wrap; gap: 5px; }
      .chip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        height: 24px;
        padding: 0 8px;
        border-radius: 999px;
        border: 1px solid var(--kd-border);
        background: var(--kd-fill);
        color: var(--kd-fg);
        font: inherit;
        font-size: 11.5px;
        cursor: pointer;
      }
      .chip.on {
        border-color: var(--kd-primary);
        background: color-mix(in srgb, var(--kd-primary) 18%, transparent);
      }
      .seg {
        display: flex;
        padding: 2px;
        border-radius: 7px;
        background: var(--kd-fill);
        gap: 2px;
      }
      .seg-btn {
        flex: 1;
        height: 24px;
        border: 0;
        border-radius: 5px;
        background: transparent;
        color: var(--kd-muted);
        font: inherit;
        font-size: 11.5px;
        font-weight: 500;
        cursor: pointer;
      }
      .seg-btn.on {
        background: var(--kd-card);
        color: var(--kd-fg);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
      }
      .diag-strip {
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 7px 9px;
        border: 1px solid var(--kd-border);
        border-radius: 7px;
        background: var(--kd-fill);
        color: var(--kd-fg);
        font: inherit;
        font-size: 11px;
        cursor: pointer;
        text-align: left;
      }
      .diag-strip:hover { background: var(--kd-hover); }
      .diag-strip-text { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--kd-muted); }
      .row { display: flex; align-items: center; gap: 6px; }
      .row-between { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .pre {
        margin: 0;
        padding: 8px;
        border-radius: 6px;
        background: var(--kd-bg);
        border: 1px solid var(--kd-border);
        font-family: var(--kd-mono);
        font-size: 11px;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 160px;
        overflow-y: auto;
      }
      .log-item {
        border: 1px solid var(--kd-border);
        border-radius: 6px;
        padding: 5px 8px;
        font-size: 11px;
      }
      .log-item summary { cursor: pointer; list-style: none; display: flex; align-items: center; gap: 5px; }
      .opt-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 3px 0;
        cursor: pointer;
      }
      .toast {
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%);
        padding: 5px 11px;
        border-radius: 999px;
        background: var(--kd-fg);
        color: var(--kd-bg);
        font-size: 11px;
        font-weight: 500;
        pointer-events: none;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
        z-index: 2147483001;
      }
      .mono { font-family: var(--kd-mono); }
      .filter-list { max-height: 150px; overflow-y: auto; display: flex; flex-direction: column; gap: 4px; }
      .preset-card { border: 1px solid var(--kd-border); border-radius: 6px; padding: 6px 8px; display: flex; flex-direction: column; gap: 4px; }
    `;

    function ensurePortal() {
      if (!portalHost || !portalHost.isConnected) {
        portalHost = document.createElement('div');
        portalHost.id = PORTAL_HOST_ID;
        portalHost.dataset.theme = currentTheme;
        portalHost.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483000;';
        (document.body || document.documentElement).appendChild(portalHost);
        portalRoot = portalHost.attachShadow({ mode: 'open' });
        const styleEl = document.createElement('style');
        styleEl.textContent = POPOVER_CSS;
        const wrapEl = document.createElement('div');
        wrapEl.id = 'kd-pop-root';
        wrapEl.style.cssText = 'pointer-events:auto;';
        const ddEl = document.createElement('div');
        ddEl.id = 'kd-dropdown-root';
        ddEl.style.cssText = 'pointer-events:auto;';
        const toastEl = document.createElement('div');
        toastEl.id = 'kd-toast';
        toastEl.className = 'toast hidden';
        portalRoot.appendChild(styleEl);
        portalRoot.appendChild(wrapEl);
        portalRoot.appendChild(ddEl);
        portalRoot.appendChild(toastEl);
        bindPortalEvents(portalRoot);
      }
      return portalRoot.getElementById('kd-pop-root');
    }

    function showToast(msg) {
      ensurePortal();
      if (!portalRoot) return;
      const t = portalRoot.getElementById('kd-toast');
      if (!t) return;
      t.textContent = msg;
      t.classList.remove('hidden');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => t.classList.add('hidden'), 2200);
    }

    function renderBar(inst) {
      const { barRoot, barHost } = inst;
      if (pluginDisabled) {
        barHost.style.display = 'none';
        return;
      }
      barHost.style.display = 'flex';
      barHost.dataset.theme = currentTheme;

      const d = stateData;
      const cfg = d?.conversation;
      const preview = d?.preview;
      const enabled = Boolean(cfg?.enabled);
      const isOpen = popoverOpen && activeBox === inst.box;

      let dotClass = 'dot';
      let labelText = 'KupaDesk';
      let labelMuted = !enabled;
      const badges = [];

      if (offlineState && !d) {
        labelText = 'KupaDesk 启动中…';
        labelMuted = true;
      } else if (cfg) {
        const cloudIds = cfg.selectedCloudIds || [];
        const presetIds = cfg.selectedPresetIds || [];
        const allPrompts = d?.cloud?.prompts || [];
        const presets = d?.global?.presets || [];
        const names = [];
        for (const id of cloudIds) {
          const hit = allPrompts.find((p) => p.id === id);
          names.push(hit?.title || shortId(id));
        }
        for (const id of presetIds) {
          const hit = presets.find((p) => p.id === id);
          if (hit) names.push(hit.name);
        }
        if (cfg.customEnabled !== false && String(cfg.customPrompt || '').trim()) {
          names.push('补充指令');
        }

        if (names.length > 0) {
          labelText = names[0];
          if (names.length > 1) badges.push({ text: `+${names.length - 1}`, cls: '' });
        }

        if (preview?.exceedsRuleLimit) {
          dotClass = 'dot warn';
          badges.push({ text: '>24K', cls: 'warn' });
        } else if (preview?.status === 'active') {
          dotClass = 'dot ok';
        } else if (preview?.status === 'empty' || preview?.status === 'cloud_pending' || preview?.status === 'pending_deactivation') {
          dotClass = 'dot warn';
        }

        if (d.isStaging) {
          badges.push({ text: '待命', cls: enabled ? 'ok' : '' });
        }
        if ((cfg.channel || 'system-instruction') === 'hook') {
          badges.push({ text: 'Hook', cls: '' });
        }
      }

      const badgesHtml = badges.map((b) => `<span class="badge ${b.cls}">${esc(b.text)}</span>`).join('');
      const wrap = barRoot.getElementById('kd-bar-wrap');
      if (!wrap) return;
      wrap.innerHTML = `
        <div class="pill${isOpen ? ' open' : ''}">
          <button type="button" class="pill-trigger" id="kd-pill-btn" title="展开 KupaDesk 云核心与系统指令面板">
            <span class="${dotClass}"></span>
            <span class="label${labelMuted ? ' muted' : ''}">${esc(labelText)}</span>
            ${badgesHtml}
            <svg class="chev" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M4 6l4 4 4-4"/>
            </svg>
          </button>
          <span class="sep" aria-hidden="true"></span>
          <label class="toggle-wrap" title="${enabled ? '关闭 KupaDesk 注入（立即删除规则）' : '开启 KupaDesk 注入'}">
            <button type="button" role="switch" aria-checked="${enabled}" class="sw-btn${enabled ? ' on' : ''}" id="kd-pill-sw" ${offlineState && !d ? 'disabled' : ''}></button>
          </label>
        </div>
      `;
    }

    function renderAllBars() {
      for (const inst of instances.values()) {
        renderBar(inst);
      }
    }

    function positionPopover() {
      if (!popoverOpen || !portalRoot) return;
      const pop = portalRoot.getElementById('kd-pop');
      const inst = activeBox ? instances.get(activeBox) : null;
      if (!pop || !inst) return;
      const pill = inst.barRoot.querySelector('.pill');
      const rect = (pill || inst.barHost).getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const popRect = pop.getBoundingClientRect();
      const popW = popRect.width || 356;
      const popH = popRect.height || 360;

      let left = rect.right - popW;
      left = Math.max(8, Math.min(left, vw - popW - 8));

      let top = rect.top - popH - 8;
      if (top < 8) {
        top = Math.min(vh - popH - 8, rect.bottom + 8);
        if (top < 8) top = 8;
      }
      pop.style.left = `${Math.round(left)}px`;
      pop.style.top = `${Math.round(top)}px`;
    }

    function isEditingInsidePopover() {
      if (!portalRoot) return false;
      const act = portalRoot.activeElement;
      const popRoot = portalRoot.getElementById('kd-pop-root');
      if (!act || !popRoot || !popRoot.contains(act)) return false;
      const tag = act.tagName;
      return tag === 'INPUT' || tag === 'TEXTAREA';
    }

    function renderPopover({ skipIfEditing = false } = {}) {
      const wrap = ensurePortal();
      if (!wrap) return;
      if (!popoverOpen) {
        cloudDropdownOpen = false;
        wrap.innerHTML = '';
        renderCloudDropdown();
        return;
      }
      if (skipIfEditing && isEditingInsidePopover() && portalRoot.getElementById('kd-pop')) {
        return;
      }

      const d = stateData;
      if (!d) {
        cloudDropdownOpen = false;
        wrap.innerHTML = `
          <div class="pop" id="kd-pop">
            <div class="hdr">
              <div class="hdr-row">
                <div class="hdr-left"><span class="dot"></span><h2 class="title">KupaDesk</h2></div>
                <button type="button" class="icon-btn" data-act="close-pop" title="关闭">✕</button>
              </div>
              <div class="meta">${offlineState ? '正在等待 KupaDesk 后台服务就绪…' : '正在加载配置…'}</div>
            </div>
          </div>`;
        positionPopover();
        renderCloudDropdown();
        return;
      }

      if (currentView !== 'main') {
        cloudDropdownOpen = false;
      }

      const cfg = d.conversation;
      const g = d.global;
      const cloud = d.cloud;
      const preview = d.preview;
      const activeChannel = cfg.channel || 'system-instruction';

      let statusCls = '';
      let statusLabel = '已关闭';
      if (preview?.status === 'active') {
        statusCls = 'ok';
        statusLabel = d.isStaging ? '待命生效' : '生效中';
      } else if (preview?.status === 'empty' || preview?.status === 'cloud_pending' || preview?.status === 'pending_deactivation') {
        statusCls = 'warn';
        statusLabel = preview.status === 'cloud_pending' ? '同步中' : preview.status === 'pending_deactivation' ? '下轮撤销' : '待选核心';
      }

      let bodyHtml = '';
      if (currentView === 'main') {
        bodyHtml = renderMainBody(d, cfg, g, cloud, preview, activeChannel);
      } else if (currentView === 'settings') {
        bodyHtml = renderSettingsBody(d, cfg, g, cloud, activeChannel);
      } else {
        bodyHtml = renderDiagBody(d, cfg, preview, activeChannel);
      }

      const fullTitle = d.isStaging
        ? '空白新对话待命'
        : d.conversationTitle
        ? d.conversationTitle
        : `对话 ${shortId(d.conversationId)}`;
      const rightMeta = d.isStaging
        ? activeChannel === 'system-instruction'
          ? '顶层 systemInstruction'
          : 'Hook 轨迹'
        : activeChannel === 'system-instruction'
        ? preview?.status === 'active'
          ? `${preview.byteLength} / ${preview.ruleByteLimit} B`
          : '未同步'
        : MODE_META[cfg.mode]?.label || cfg.mode;

      const DIAG_SVG = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 8.5h2.5l1.75-4.5 2.5 8 1.75-3.5H14"/></svg>';
      const GEAR_SVG = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="8" cy="8" r="2.25"/><path d="M8 2.25v1.3M8 12.45v1.3M2.25 8h1.3M12.45 8h1.3M3.93 3.93l.92.92M11.15 11.15l.92.92M12.07 3.93l-.92.92M4.85 11.15l-.92.92"/></svg>';

      wrap.innerHTML = `
        <div class="pop" id="kd-pop">
          <div class="hdr">
            <div class="hdr-row">
              <div class="hdr-left">
                ${currentView !== 'main' ? `<button type="button" class="ghost-btn" data-act="nav-main">← 返回</button>` : `<span class="dot ${statusCls}"></span><h2 class="title">KupaDesk</h2>`}
                <span class="pill-badge ${statusCls}">${esc(statusLabel)}</span>
              </div>
              <div class="hdr-tools">
                <button type="button" class="icon-btn" data-act="nav-diag" title="诊断与安全预览">${DIAG_SVG}</button>
                <button type="button" class="icon-btn" data-act="nav-settings" title="设置、云更新与客户端增强">${GEAR_SVG}${d.update?.available ? '<span class="btn-dot-update"></span>' : ''}</button>
                <label class="sw" title="当前对话注入总开关">
                  <input type="checkbox" id="pop-master-sw" ${cfg.enabled ? 'checked' : ''}>
                  <span class="sw-track"></span>
                </label>
              </div>
            </div>
            <div class="meta-row">
              <span class="meta-title" title="${esc(fullTitle)}">${esc(fullTitle)}</span>
              <span class="meta-sep">·</span>
              <span class="meta-size">${esc(rightMeta)}</span>
            </div>
          </div>
          <div class="body">${bodyHtml}</div>
        </div>`;

      if (currentView === 'settings') {
        const ta = portalRoot.getElementById('pop-custom-input');
        if (ta && !customDirty) {
          ta.value = cfg.customPrompt || '';
        } else if (ta && customDirty) {
          ta.value = customDraft;
        }
      }
      positionPopover();
      renderCloudDropdown();
      requestAnimationFrame(() => {
        if (popoverOpen) {
          positionPopover();
          if (cloudDropdownOpen) positionCloudDropdown();
        }
      });
    }

    function buildCloudDropdownView(d) {
      const cfg = d?.conversation || {};
      const g = d?.global || {};
      const cloud = d?.cloud || {};
      const allPrompts = cloud.prompts || [];
      const selectedCloud = cfg.selectedCloudIds || [];
      const defCloudSet = new Set(g.defaults?.defaultCloudIds || []);
      const filterOn = Boolean(g.cloud?.filterEnabled);
      const visibleSet = new Set(g.cloud?.visibleCloudIds || []);
      const pool =
        !filterOn || cloudDropdownShowAll
          ? allPrompts
          : allPrompts.filter((p) => visibleSet.has(p.id) || selectedCloud.includes(p.id));
      const q = mainCloudQuery.trim().toLowerCase();
      const matched = q
        ? pool.filter((p) => String(p.title || '').toLowerCase().includes(q) || String(p.id).toLowerCase().includes(q))
        : pool;

      const listHtml = matched.length
        ? matched
            .map((p) => {
              const idx = selectedCloud.indexOf(p.id);
              const on = idx >= 0;
              const isDef = defCloudSet.has(p.id);
              return `
                <div class="combo-item${on ? ' on' : ''}" data-act="toggle-cloud" data-id="${esc(p.id)}">
                  <div class="combo-item-left">
                    <span class="chk">${on ? idx + 1 : ''}</span>
                    <span class="combo-name">${esc(p.title)}</span>
                  </div>
                  <button type="button" class="star-btn${isDef ? ' on' : ''}" data-act="star-cloud" data-id="${esc(p.id)}" title="${isDef ? '取消新对话默认' : '设为新对话默认'}">★</button>
                </div>`;
            })
            .join('')
        : '<div class="hint" style="padding:8px;text-align:center;">未找到匹配项</div>';

      return {
        filterOn,
        allCount: allPrompts.length,
        matchedCount: matched.length,
        hasSelected: selectedCloud.length > 0,
        countText: `匹配 ${matched.length} / ${allPrompts.length}`,
        listHtml,
      };
    }

    function positionCloudDropdown() {
      if (!portalRoot) return;
      const menu = portalRoot.getElementById('kd-cloud-menu');
      const trigger = portalRoot.getElementById('kd-cloud-trigger');
      const listEl = portalRoot.getElementById('kd-cloud-menu-list');
      if (!menu || !trigger) return;

      const btnRect = trigger.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const menuW = Math.min(vw - 16, Math.max(260, Math.round(btnRect.width)));
      const left = Math.max(8, Math.min(Math.round(btnRect.left), vw - menuW - 8));
      menu.style.width = `${menuW}px`;
      menu.style.left = `${left}px`;

      if (listEl) listEl.style.maxHeight = '196px';
      const spaceBelow = vh - btnRect.bottom - 12;
      const spaceAbove = btnRect.top - 12;
      const openBelow = spaceBelow >= 210 || spaceBelow >= spaceAbove;
      const availH = Math.max(110, openBelow ? spaceBelow : spaceAbove);
      if (listEl) {
        const maxListH = Math.max(76, Math.min(196, availH - 76));
        listEl.style.maxHeight = `${maxListH}px`;
      }
      const menuH = menu.getBoundingClientRect().height || 180;
      let top = openBelow ? btnRect.bottom + 4 : btnRect.top - menuH - 4;
      top = Math.max(8, Math.min(top, vh - menuH - 8));
      menu.style.top = `${Math.round(top)}px`;
    }

    function updateCloudDropdownListOnly() {
      if (!portalRoot || !stateData) return;
      const view = buildCloudDropdownView(stateData);
      const countEl = portalRoot.getElementById('kd-cloud-menu-count');
      const listEl = portalRoot.getElementById('kd-cloud-menu-list');
      const clearBtn = portalRoot.getElementById('kd-cloud-menu-clear');
      const allBtn = portalRoot.getElementById('kd-cloud-menu-all');
      if (countEl) countEl.textContent = view.countText;
      if (listEl) listEl.innerHTML = view.listHtml;
      if (clearBtn) clearBtn.disabled = !view.hasSelected;
      if (allBtn) allBtn.textContent = cloudDropdownShowAll ? '仅常用' : '全部';
      positionCloudDropdown();
    }

    function syncTriggerCaret() {
      if (!portalRoot) return;
      const caret = portalRoot.getElementById('kd-cloud-trigger-caret');
      if (caret) caret.textContent = cloudDropdownOpen ? '收起 ▲' : '选择 ▾';
    }

    function renderCloudDropdown({ focusSearch = false } = {}) {
      ensurePortal();
      if (!portalRoot) return;
      const ddRoot = portalRoot.getElementById('kd-dropdown-root');
      if (!ddRoot) return;
      syncTriggerCaret();

      if (!(popoverOpen && currentView === 'main' && cloudDropdownOpen && stateData?.cloud?.activated)) {
        ddRoot.innerHTML = '';
        return;
      }

      const view = buildCloudDropdownView(stateData);
      const existingMenu = portalRoot.getElementById('kd-cloud-menu');
      if (existingMenu) {
        updateCloudDropdownListOnly();
        if (focusSearch) {
          const inp = portalRoot.getElementById('pop-cloud-search');
          if (inp) inp.focus();
        }
        return;
      }

      ddRoot.innerHTML = `
        <div class="cloud-float-menu" id="kd-cloud-menu">
          <input type="search" id="pop-cloud-search" class="input" placeholder="搜索云核心…" value="${esc(mainCloudQuery)}">
          <div class="row-between">
            <span class="hint" id="kd-cloud-menu-count">${esc(view.countText)}</span>
            <div class="row">
              ${view.filterOn ? `<button type="button" class="ghost-btn" id="kd-cloud-menu-all" data-act="toggle-cloud-all">${cloudDropdownShowAll ? '仅常用' : '全部'}</button>` : ''}
              <button type="button" class="ghost-btn" id="kd-cloud-menu-clear" data-act="clear-clouds" ${view.hasSelected ? '' : 'disabled'}>清空</button>
            </div>
          </div>
          <div class="combo-list" id="kd-cloud-menu-list">${view.listHtml}</div>
        </div>`;

      positionCloudDropdown();
      if (focusSearch) {
        const inp = portalRoot.getElementById('pop-cloud-search');
        if (inp) {
          inp.focus();
          inp.setSelectionRange(mainCloudQuery.length, mainCloudQuery.length);
        }
      }
    }

    function renderMainBody(d, cfg, g, cloud) {
      const stagingHtml = d.isStaging
        ? `<div class="staging-bar"><strong>新对话待命模式</strong>：发出第一句话时自动认领当前选中的核心与开关状态。</div>`
        : '';

      const allPrompts = cloud.prompts || [];
      const promptMap = new Map(allPrompts.map((p) => [p.id, p]));
      const selectedCloud = cfg.selectedCloudIds || [];

      let cloudSection = '';
      if (!cloud.activated) {
        cloudSection = `
          <div class="card">
            <div class="card-head">
              <h3 class="card-title">云核心</h3>
              <span class="pill-badge">未激活</span>
            </div>
            <p class="hint">激活 KupaDesk 卡密即可选用云核心，开启时自动同步至系统指令层。</p>
            <div><button type="button" class="primary-btn" data-act="goto-activate">去激活卡密</button></div>
          </div>`;
      } else {
        const leaseCls = cloud.lease?.ok ? 'ok' : cloud.error ? 'err' : 'warn';
        const leaseText = cloud.lease?.ok ? '租约有效' : cloud.error ? '授权异常' : '续期中';
        const tagsHtml = selectedCloud.length
          ? `<div class="tags">${selectedCloud
              .map((id, i) => {
                const title = promptMap.get(id)?.title || shortId(id);
                return `<span class="tag"><span>${i + 1}. ${esc(title)}</span><button type="button" class="tag-x" data-act="rm-cloud" data-id="${esc(id)}" title="移除">×</button></span>`;
              })
              .join('')}</div>`
          : '';

        const triggerLabel = !selectedCloud.length
          ? '选择云核心…'
          : selectedCloud.length === 1
          ? promptMap.get(selectedCloud[0])?.title || shortId(selectedCloud[0])
          : `已选 ${selectedCloud.length} 个核心`;

        cloudSection = `
          <div class="card">
            <div class="card-head">
              <div class="row"><h3 class="card-title">云核心</h3><span class="pill-badge ${leaseCls}">${leaseText}</span></div>
              <button type="button" class="ghost-btn" data-act="refresh-cloud">刷新</button>
            </div>
            ${cloud.error?.message ? `<div class="alert">${esc(cloud.error.message)}</div>` : ''}
            <button type="button" class="combo-btn" id="kd-cloud-trigger" data-act="toggle-cloud-dd">
              <span>${esc(triggerLabel)}</span>
              <span id="kd-cloud-trigger-caret" class="hint">${cloudDropdownOpen ? '收起 ▲' : '选择 ▾'}</span>
            </button>
            ${tagsHtml}
          </div>`;
      }

      let cnWarnHtml = '';
      if (d.cnToolkit?.updateCovered) {
        cnWarnHtml = `
          <div class="guard-bar">
            <span class="guard-bar-text">检测到客户端更新覆盖了中文增强或红框入口</span>
            <button type="button" class="primary-btn" style="flex:none;height:22px;padding:0 8px;font-size:11px;" data-act="nav-settings">去一键恢复</button>
          </div>`;
      }

      return `${stagingHtml}${cnWarnHtml}${cloudSection}`;
    }

    function renderSettingsBody(d, cfg, g, cloud, activeChannel) {
      const u = d.update || {};
      const recentUpdated =
        u.lastUpdated?.at &&
        Number.isFinite(Date.parse(u.lastUpdated.at)) &&
        Date.now() - Date.parse(u.lastUpdated.at) < 120_000;
      const uBadgeCls = u.available ? 'ok' : u.status === 'error' ? 'warn' : '';
      const uBadgeText =
        u.updating || updateBusy
          ? '更新中…'
          : u.checking
          ? '检查中…'
          : u.available && u.latest
          ? `发现 v${u.latest.version}`
          : u.status === 'up_to_date'
          ? '已是最新'
          : u.status === 'not_published'
          ? '云端未发布'
          : u.status === 'error'
          ? '检查异常'
          : `v${u.currentVersion || '2.0.0'}`;

      const updateCard = `
        <div class="card">
          <div class="card-head">
            <h3 class="card-title">插件云更新</h3>
            <span class="pill-badge ${uBadgeCls}">${esc(uBadgeText)}</span>
          </div>
          <div class="hint">当前 v${esc(u.currentVersion || '2.0.0')}${u.lastCheckedAt ? ` · 上次检查 ${esc(fmtRelTime(u.lastCheckedAt))}` : ''}</div>
          ${u.error?.message ? `<div class="${u.status === 'not_published' ? 'hint' : 'alert'}">${esc(u.error.message)}</div>` : ''}
          ${
            u.available && u.latest
              ? `
                <div class="staging-bar">
                  <div><strong>新版 v${esc(u.latest.version)}</strong>（${Math.max(1, Math.round((u.latest.size || 0) / 1024))} KB）</div>
                  ${u.latest.changelog ? `<div class="hint" style="margin-top:3px;color:var(--kd-fg);">${esc(u.latest.changelog)}</div>` : ''}
                  ${u.latest.requiresAsarReinstall ? `<div class="hint" style="margin-top:2px;">此版本含客户端前端补丁更新，更新后建议一键恢复客户端入口。</div>` : ''}
                </div>
              `
              : ''
          }
          ${
            recentUpdated
              ? `<div class="hint" style="color:var(--kd-success);">已完成更新至 v${esc(u.lastUpdated.toVersion)}，按 Ctrl + R 刷新窗口生效${u.lastUpdated.requiresAsarReinstall ? '；如界面有补丁变更请点下方「一键全套恢复」' : ''}。</div>`
              : ''
          }
          <div class="row">
            ${
              u.available && u.latest
                ? `<button type="button" class="primary-btn" data-act="update-install" ${u.updating || updateBusy ? 'disabled' : ''}>${u.updating || updateBusy ? '正在更新…' : '立即更新'}</button>`
                : ''
            }
            <button type="button" class="ghost-btn" data-act="update-check" ${u.checking || updateBusy ? 'disabled' : ''}>${u.checking ? '检查中…' : '检查更新'}</button>
          </div>
          <label class="opt-row"><span>启动时自动检查更新</span><span class="sw"><input type="checkbox" id="pop-def-autoupdate" ${g.defaults?.autoCheckUpdates !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
        </div>`;

      const ds = desktopStatus;
      const cn = d.cnToolkit || {};
      const cnOk = Boolean(cn.hasCn);
      const revOk = Boolean(cn.hasFileReveal);
      const kdOk = Boolean(ds ? ds.installed : cn.hasKupadeskDesktop);
      const allThreeOk = cnOk && revOk && kdOk;
      const clientVer = ds?.clientVersion || cn.clientVersion || 'unknown';
      const dsText =
        ds?.detectError || cn.detectError
          ? `检测异常：${ds?.detectError || cn.detectError}`
          : cn.updateCovered
          ? `客户端 v${clientVer} 更新后部分增强已失效，可一键恢复`
          : `客户端 v${clientVer} · 中文汉化${cnOk ? '√' : '×'} · 右键打开位置${revOk ? '√' : '×'} · 红框${kdOk ? '√' : '×'}`;

      const desktopCard = `
        <div class="card">
          <div class="card-head">
            <h3 class="card-title">客户端中文增强与红框入口</h3>
            <span class="pill-badge ${allThreeOk && !cn.updateCovered ? 'ok' : 'warn'}">${allThreeOk && !cn.updateCovered ? '全套生效' : cn.updateCovered ? '待恢复' : '部分未装'}</span>
          </div>
          <div class="chips">
            <span class="pill-badge ${cnOk ? 'ok' : ''}">汉化+监控 ${cnOk ? '已装' : '未装'}</span>
            <span class="pill-badge ${revOk ? 'ok' : ''}">右键打开位置 ${revOk ? '已装' : '未装'}</span>
            <span class="pill-badge ${kdOk ? 'ok' : ''}">红框入口 ${kdOk ? '已装' : '未装'}</span>
          </div>
          <p class="hint">${esc(dsText)}</p>
          <label class="opt-row"><span>新对话自动中文标题</span><span class="sw"><input type="checkbox" id="pop-cn-autotitle" ${cn.state?.autoChineseTitle !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
          <label class="opt-row"><span>强制简体中文思考规则</span><span class="sw"><input type="checkbox" id="pop-cn-rule" ${cn.hasCnLanguageRule !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
          <div class="row" style="flex-wrap:wrap;">
            ${
              confirmCnInstallAll
                ? `<button type="button" class="primary-btn" data-act="cn-install-all-confirm">确认全套恢复并重启</button><button type="button" class="ghost-btn" data-act="cn-install-all-cancel">取消</button>`
                : `<button type="button" class="primary-btn" data-act="cn-install-all">一键全套安装 / 升级恢复</button>`
            }
            <button type="button" class="ghost-btn" data-act="desktop-install">仅重挂红框</button>
            ${
              kdOk
                ? confirmDesktopUninstall
                  ? `<button type="button" class="danger-btn" data-act="desktop-uninstall-confirm">确认移除红框</button><button type="button" class="ghost-btn" data-act="desktop-uninstall-cancel">取消</button>`
                  : `<button type="button" class="ghost-btn" data-act="desktop-uninstall">移除红框</button>`
                : ''
            }
          </div>
        </div>`;

      const channelCard = `
        <div class="card">
          <h3 class="card-title">注入层级与策略</h3>
          <div class="seg">
            <button type="button" class="seg-btn${activeChannel === 'system-instruction' ? ' on' : ''}" data-act="set-channel" data-val="system-instruction">systemInstruction（顶层）</button>
            <button type="button" class="seg-btn${activeChannel === 'hook' ? ' on' : ''}" data-act="set-channel" data-val="hook">Hook 轨迹（兼容）</button>
          </div>
          <p class="hint">${esc(CHANNEL_META[activeChannel]?.desc || '')}</p>
          ${
            activeChannel === 'system-instruction'
              ? `
                <label class="opt-row">
                  <div>
                    <div>防误切覆盖保护</div>
                    <div class="hint">浏览其他对话时不冲掉运行中对话规则</div>
                  </div>
                  <span class="sw"><input type="checkbox" id="pop-def-protect" ${g.defaults?.protectRunningFocus !== false ? 'checked' : ''}><span class="sw-track"></span></span>
                </label>
              `
              : `
                <div class="seg">
                  ${['every-turn', 'on-change', 'every-invocation']
                    .map((m) => `<button type="button" class="seg-btn${cfg.mode === m ? ' on' : ''}" data-act="set-mode" data-val="${m}">${MODE_META[m].label}</button>`)
                    .join('')}
                </div>
                <label class="opt-row"><span>高权重系统协议包装</span><span class="sw"><input type="checkbox" id="pop-opt-wrap" ${cfg.wrapAsHighestPriority !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
                <label class="opt-row"><span>关闭时自动发送撤销指令</span><span class="sw"><input type="checkbox" id="pop-opt-deact" ${cfg.sendDeactivationNotice !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
              `
          }
        </div>`;

      const cloudCard = `
        <div class="card">
          <div class="card-head">
            <h3 class="card-title">KupaDesk 云端授权</h3>
            <span class="pill-badge ${cloud.activated ? (cloud.lease?.ok ? 'ok' : 'warn') : ''}">${cloud.activated ? (cloud.lease?.ok ? '租约有效' : '续期中') : '未激活'}</span>
          </div>
          ${
            cloud.activated
              ? `<div class="hint mono">尾号 ****${esc(cloud.cardSuffix || '-')} · 到期 ${esc(fmtDateTime(cloud.expiresAt))}</div>`
              : ''
          }
          ${cloud.error?.message ? `<div class="alert">${esc(cloud.error.message)}</div>` : ''}
          <div class="row">
            <input type="url" id="pop-origin-input" class="input mono" value="${esc(cloud.origin || 'https://kupakupa.vip')}" placeholder="https://kupakupa.vip">
            <button type="button" class="ghost-btn" data-act="save-origin">保存地址</button>
          </div>
          <div class="row">
            <input type="password" id="pop-card-input" class="input mono" placeholder="KUPA-xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx" autocomplete="off">
            <button type="button" class="primary-btn" data-act="activate-card">${cloud.activated ? '更换' : '激活'}</button>
          </div>
          ${
            cloud.activated
              ? `<div class="row-between"><button type="button" class="ghost-btn" data-act="refresh-cloud">刷新目录</button>${
                  confirmDeactivate
                    ? `<button type="button" class="danger-btn" data-act="confirm-deactivate">确认清除授权</button>`
                    : `<button type="button" class="ghost-btn" data-act="ask-deactivate">退出授权</button>`
                }</div>`
              : ''
          }
        </div>`;

      let filterCard = '';
      if (cloud.activated && (cloud.prompts || []).length) {
        const visSet = new Set(g.cloud?.visibleCloudIds || []);
        const defSet = new Set(g.defaults?.defaultCloudIds || []);
        const fq = filterQuery.trim().toLowerCase();
        const filtered = cloud.prompts.filter((p) => {
          if (filterTab === 'kept' && !visSet.has(p.id)) return false;
          if (filterTab === 'default' && !defSet.has(p.id)) return false;
          return !fq || String(p.title || '').toLowerCase().includes(fq);
        });
        filterCard = `
          <div class="card">
            <div class="card-head">
              <h3 class="card-title">云核心筛选与默认</h3>
              <label class="sw"><span>仅已选</span><input type="checkbox" id="pop-filter-en" ${g.cloud?.filterEnabled ? 'checked' : ''}><span class="sw-track"></span></label>
            </div>
            <input type="search" id="pop-filter-search" class="input" placeholder="筛选云核心…" value="${esc(filterQuery)}">
            <div class="seg">
              <button type="button" class="seg-btn${filterTab === 'all' ? ' on' : ''}" data-act="set-ftab" data-val="all">全部</button>
              <button type="button" class="seg-btn${filterTab === 'kept' ? ' on' : ''}" data-act="set-ftab" data-val="kept">已保留</button>
              <button type="button" class="seg-btn${filterTab === 'default' ? ' on' : ''}" data-act="set-ftab" data-val="default">默认</button>
            </div>
            <div class="filter-list">
              ${filtered
                .map((p) => {
                  const kept = visSet.has(p.id);
                  const isDef = defSet.has(p.id);
                  return `
                    <div class="row-between">
                      <label class="row" style="min-width:0;flex:1;cursor:pointer;">
                        <input type="checkbox" data-act="toggle-vis-cloud" data-id="${esc(p.id)}" ${kept ? 'checked' : ''}>
                        <span class="combo-name">${esc(p.title)}</span>
                      </label>
                      <button type="button" class="ghost-btn" data-act="star-cloud" data-id="${esc(p.id)}">${isDef ? '★ 默认' : '设默认'}</button>
                    </div>`;
                })
                .join('')}
            </div>
          </div>`;
      }

      const def = g.defaults || {};
      const autoCard = `
        <div class="card">
          <h3 class="card-title">开新对话自动化</h3>
          <label class="opt-row"><span>新对话顶部自动显示唤起胶囊</span><span class="sw"><input type="checkbox" id="pop-def-pill" ${def.showSessionStartPill !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
          <label class="opt-row"><span>空白新对话自动认领预选核心</span><span class="sw"><input type="checkbox" id="pop-def-claim" ${def.autoClaimStaging !== false ? 'checked' : ''}><span class="sw-track"></span></span></label>
          <label class="opt-row"><span>新对话默认开启注入</span><span class="sw"><input type="checkbox" id="pop-def-new" ${def.enabledForNew ? 'checked' : ''}><span class="sw-track"></span></span></label>
        </div>`;

      const customOpen = Boolean(customDirty || (cfg.customPrompt || '').trim());
      const customCard = `
        <details class="card" ${customOpen ? 'open' : ''}>
          <summary class="row-between" style="cursor:pointer;list-style:none;">
            <span class="card-title">当前对话补充指令</span>
            <span class="hint">${customDirty ? '未保存…' : (cfg.customPrompt || '').trim() ? `${cfg.customPrompt.length} 字符` : '可选'}</span>
          </summary>
          <div style="display:flex;flex-direction:column;gap:6px;margin-top:6px;">
            <label class="opt-row">
              <span class="hint">纳入注入内容</span>
              <span class="sw"><input type="checkbox" id="pop-custom-en" ${cfg.customEnabled !== false ? 'checked' : ''}><span class="sw-track"></span></span>
            </label>
            <textarea id="pop-custom-input" class="textarea" placeholder="仅针对当前对话的补充指令（Ctrl+S 保存）…"></textarea>
            <div class="row-between">
              <button type="button" class="ghost-btn" data-act="clear-custom">清空</button>
              <button type="button" class="primary-btn" data-act="save-custom">保存</button>
            </div>
          </div>
        </details>`;

      const presets = g.presets || [];
      const selPresets = cfg.selectedPresetIds || [];
      const presetsCard = `
        <div class="card">
          <div class="card-head">
            <h3 class="card-title">本机预设（选用与管理）</h3>
            <button type="button" class="primary-btn" data-act="new-preset">+ 新建</button>
          </div>
          <div class="chips">
            ${
              presets.length
                ? presets
                    .map((p) => {
                      const idx = selPresets.indexOf(p.id);
                      const on = idx >= 0;
                      return `<button type="button" class="chip${on ? ' on' : ''}" data-act="toggle-preset" data-id="${esc(p.id)}">${on ? `${idx + 1}. ` : ''}${esc(p.name)}</button>`;
                    })
                    .join('')
                : '<span class="hint">暂无本机预设</span>'
            }
          </div>
          ${
            presetFormState
              ? `
                <div style="display:flex;flex-direction:column;gap:6px;padding:6px;border:1px solid var(--kd-border);border-radius:6px;">
                  <input type="text" id="pop-pf-name" class="input" placeholder="预设名称" value="${esc(presetFormState.name)}">
                  <input type="text" id="pop-pf-desc" class="input" placeholder="简介（可选）" value="${esc(presetFormState.description)}">
                  <textarea id="pop-pf-content" class="textarea" placeholder="提示词内容…">${esc(presetFormState.content)}</textarea>
                  <div class="row-between">
                    <button type="button" class="ghost-btn" data-act="cancel-preset">取消</button>
                    <button type="button" class="primary-btn" data-act="save-preset">保存预设</button>
                  </div>
                </div>
              `
              : ''
          }
          ${
            presets.length
              ? presets
                  .map(
                    (p) => `
                <div class="preset-card">
                  <div class="row-between">
                    <strong>${esc(p.name)}</strong>
                    <div class="row">
                      <button type="button" class="ghost-btn" data-act="edit-preset" data-id="${esc(p.id)}">编辑</button>
                      ${
                        confirmDeletePresetId === p.id
                          ? `<button type="button" class="danger-btn" data-act="confirm-del-preset" data-id="${esc(p.id)}">确认</button>`
                          : `<button type="button" class="ghost-btn" data-act="del-preset" data-id="${esc(p.id)}">删除</button>`
                      }
                    </div>
                  </div>
                  <div class="hint">${esc(p.description || p.content.slice(0, 60))}</div>
                </div>`
                  )
                  .join('')
              : ''
          }
        </div>`;

      return `${customCard}${presetsCard}${channelCard}${cloudCard}${filterCard}${autoCard}${updateCard}${desktopCard}`;
    }

    function renderDiagBody(d, cfg, preview, activeChannel) {
      const metaText = preview?.finalMessage
        ? activeChannel === 'system-instruction'
          ? `${preview.charCount} 字符 · ${preview.byteLength} / ${preview.ruleByteLimit} B${preview.exceedsRuleLimit ? ' · ⚠ 超出上限' : ''}${preview.containsCloud ? '（已脱敏）' : ''}`
          : `${preview.charCount} 字符 · 约 ${preview.estimatedTokens} tokens`
        : '无待同步/注入内容';

      const history = [...(cfg.runtime?.history || [])].reverse();
      return `
        <div class="card">
          <div class="card-head">
            <h3 class="card-title">安全预览</h3>
            <button type="button" class="ghost-btn" data-act="copy-preview" ${preview?.finalMessage ? '' : 'disabled'}>复制</button>
          </div>
          <p class="hint">${esc(preview?.statusReason || '')}</p>
          <div class="hint">${esc(metaText)}</div>
          <pre class="pre">${esc(preview?.finalMessage || '（未开启或无内容，零残留）')}</pre>
        </div>
        <div class="card">
          <div class="card-head">
            <h3 class="card-title">同步与 Hook 轨迹</h3>
            ${
              !d.isStaging && history.length
                ? `<button type="button" class="${confirmClearLogs ? 'danger-btn' : 'ghost-btn'}" data-act="clear-logs">${confirmClearLogs ? '确认清空' : '清空'}</button>`
                : ''
            }
          </div>
          ${
            d.isStaging
              ? '<p class="hint">空白新对话待命模式，发出首句后开始记录。</p>'
              : history.length
              ? history
                  .map(
                    (h) => `
                  <details class="log-item">
                    <summary>
                      <span class="pill-badge">${esc(ACTION_LABEL[h.action] || h.action)}</span>
                      <span>${esc(h.event)}</span>
                      <span class="hint">${esc(REASON_LABEL[h.reason] || h.reason || '')}</span>
                      <span style="flex:1"></span>
                      <span class="hint">${esc(h.bytes ? `${h.bytes} B` : h.chars ? `${h.chars} 字` : '')} · ${esc(fmtRelTime(h.time))}</span>
                    </summary>
                    <pre class="pre" style="margin-top:5px;">${esc(h.messageFull || h.messagePreview || '')}</pre>
                  </details>`
                  )
                  .join('')
              : '<p class="hint">暂无轨迹记录</p>'
          }
        </div>`;
    }

    async function loadState({ force = false, claimFocus = false } = {}) {
      if (pollInFlight && !force) return;
      pollInFlight = true;
      lastFetchAt = Date.now();
      try {
        const convId = activeConvId;
        const data = await bridgeCall('state', {
          conversationId: convId,
          etag: force ? '' : stateEtag,
          claimFocus: Boolean(claimFocus),
        });
        pluginDisabled = false;
        offlineState = false;
        if (!data.unchanged) {
          stateEtag = data.etag || '';
          stateData = data;
          renderAllBars();
          if (popoverOpen) renderPopover({ skipIfEditing: !force });
        }
      } catch (err) {
        if (err.disabled) {
          pluginDisabled = true;
          popoverOpen = false;
          renderAllBars();
          renderPopover();
        } else if (err.offline) {
          offlineState = true;
          renderAllBars();
          if (popoverOpen && !stateData) renderPopover();
        }
      } finally {
        pollInFlight = false;
      }
    }

    async function refreshDesktopStatus() {
      const now = Date.now();
      if (desktopStatus && now - desktopStatusFetchedAt < 4000) return;
      try {
        desktopStatus = await bridgeCall('desktop.status', {});
        desktopStatusFetchedAt = Date.now();
        if (popoverOpen && currentView === 'settings') renderPopover({ skipIfEditing: true });
      } catch (_e) {}
    }

    async function saveConfig(patch, toastMsg = '') {
      const targetConvId = activeConvId;
      const isStaging = stateData ? stateData.isStaging : !targetConvId;
      const action = isStaging ? 'staging' : 'conversation';
      const payload = { ...patch };
      if (!isStaging && targetConvId) payload.conversationId = targetConvId;
      if (customDirty && payload.customPrompt === undefined) {
        payload.customPrompt = customDraft;
      }
      try {
        const next = await bridgeCall(action, payload);
        customDirty = false;
        stateEtag = next.etag || '';
        stateData = next;
        offlineState = false;
        renderAllBars();
        if (popoverOpen) renderPopover({ skipIfEditing: true });
        if (toastMsg) showToast(toastMsg);
      } catch (err) {
        showToast(err.message || '保存失败');
        await loadState({ force: true });
      }
    }

    function toggleMasterFromPill() {
      if (!stateData?.conversation) return;
      const nextEnabled = !stateData.conversation.enabled;
      // 乐观更新胶囊状态并同步后端
      stateData = {
        ...stateData,
        conversation: { ...stateData.conversation, enabled: nextEnabled },
        preview: stateData.preview
          ? {
              ...stateData.preview,
              status: nextEnabled ? (stateData.preview.hasContent ? 'active' : 'empty') : 'disabled',
            }
          : stateData.preview,
      };
      renderAllBars();
      void saveConfig(
        { enabled: nextEnabled },
        nextEnabled ? '已开启 KupaDesk 同步' : '已关闭并清除规则'
      );
    }

    function extractReactFiber(el) {
      if (!el) return null;
      for (const k of Object.keys(el)) {
        if (k.startsWith('__reactFiber$') || k.startsWith('__reactContainer$')) {
          return el[k];
        }
      }
      return null;
    }

    function openHostSidecarPanel(targetView = 'settings', focusTarget = '') {
      try {
        const notifyIframes = () => {
          const curFrames = Array.from(document.querySelectorAll('iframe[data-testid="sidecar-iframe"]'));
          for (const frame of curFrames) {
            try {
              frame.contentWindow?.postMessage?.({ type: 'kupadesk:switch-view', view: targetView, focusTarget }, '*');
              frame.contentWindow?.dispatchEvent?.(new Event('focus'));
            } catch (_e) {}
          }
          return curFrames;
        };

        // 1. 若右侧已经打开了 KupaDesk 的 iframe，直接发 postMessage 切换视图并唤醒其 focus
        const iframes = notifyIframes();

        // 2. 从当前对话 DOM 节点向上遍历 React Fiber 祖先链，提取宿主原生 Context 与 Redux Store
        const startNodes = [
          activeBox,
          document.querySelector('[data-testid="conversation-view"]'),
          document.querySelector('[data-testid="agent-input-box"]'),
          document.getElementById('root'),
          document.body?.firstElementChild,
        ].filter(Boolean);

        let store = null;
        let featureMap = null;
        let iframeCtx = null;
        let router = null;
        let sidecarLinkClick = null;

        const inspectProps = (props) => {
          if (!props || typeof props !== 'object') return;
          if (typeof props.onSidecarLinkClick === 'function' && !sidecarLinkClick) {
            sidecarLinkClick = props.onSidecarLinkClick;
          }
          const val = props.value;
          if (!val || typeof val !== 'object') return;
          if (!store) {
            if (val.store && typeof val.store.dispatch === 'function' && typeof val.store.getState === 'function') {
              store = val.store;
            } else if (typeof val.dispatch === 'function' && typeof val.getState === 'function') {
              store = val;
            }
          }
          if (
            !featureMap &&
            typeof val.get === 'function' &&
            (typeof val.getBaseline === 'function' || val instanceof Map)
          ) {
            try {
              if (val.get('extensibility')) featureMap = val;
            } catch (_e) {}
          }
          if (!iframeCtx && typeof val.setIframeSrc === 'function' && typeof val.navigateIframe === 'function') {
            iframeCtx = val;
          }
          if (!router && val.state?.location && typeof val.navigate === 'function') {
            router = val;
          }
        };

        const inspectFiber = (f) => {
          if (!f) return;
          if (f.memoizedProps) inspectProps(f.memoizedProps);
          if (f.pendingProps && f.pendingProps !== f.memoizedProps) inspectProps(f.pendingProps);
        };

        for (const node of startNodes) {
          let cur = extractReactFiber(node);
          let guard = 0;
          while (cur && guard++ < 160) {
            inspectFiber(cur);
            cur = cur.return;
          }
          if (store && featureMap && iframeCtx && router) break;
        }

        // 若祖先链未完全命中，从根容器做一次轻量 BFS
        if (!store || !featureMap || !iframeCtx || !router) {
          const rootFiber = extractReactFiber(document.getElementById('root') || document.body?.firstElementChild);
          if (rootFiber) {
            const queue = [rootFiber];
            let visited = 0;
            while (queue.length && visited++ < 3500) {
              const cur = queue.shift();
              inspectFiber(cur);
              if (store && featureMap && iframeCtx && router) break;
              if (cur.child) queue.push(cur.child);
              if (cur.sibling) queue.push(cur.sibling);
            }
          }
        }

        if (store && featureMap) {
          const ext = featureMap.get('extensibility');
          const redesignEnabled = featureMap.get('auxPaneComponent')?.redesignEnabled === true;
          const rawList =
            (typeof ext?.provider?.getState === 'function' ? ext.provider.getState() : null) ||
            ext?.provider?.value ||
            ext?.provider?.current ||
            [];
          const sidecars = Array.isArray(rawList) ? rawList : [];
          const hit =
            sidecars.find((d) => d?.sidecarId === 'kupadesk/prompt_panel') ||
            sidecars.find((d) => String(d?.sidecarId || '').endsWith('/prompt_panel'));

          if (hit && hit.baseUrl) {
            const views = hit.config?.uiConfig?.views || [{ path: '/', title: 'KupaDesk' }];
            const v = views[0] || { path: '/', title: 'KupaDesk' };
            const viewPath = v.path || '/';
            const resolvedUrl =
              typeof ext?.resolveSidecarUrl === 'function'
                ? ext.resolveSidecarUrl(hit.baseUrl, viewPath)
                : hit.baseUrl;
            const title = v.title || hit.config?.uiConfig?.displayName || 'KupaDesk';
            const tabId = `sidecar__${hit.sidecarId}__${viewPath}`;
            const content = {
              type: 'sidecarView',
              sidecarView: {
                sidecarId: hit.sidecarId,
                path: viewPath,
                url: resolvedUrl,
                title,
              },
            };

            if (iframeCtx && resolvedUrl && iframes.length === 0) {
              try {
                const baseU = new URL(resolvedUrl);
                if (activeConvId) baseU.searchParams.set('conversationId', activeConvId);
                const baseHref = baseU.toString();
                iframeCtx.setIframeSrc(baseHref, baseHref);
              } catch (_e) {}
            }

            const scopes = [];
            if (activeConvId) {
              scopes.push({ kind: 'cascadeId', cascadeId: activeConvId });
            } else {
              const searchParams = new URLSearchParams(location.search);
              const proj = router?.state?.location?.search?.project || searchParams.get('project');
              if (proj) scopes.push({ kind: 'newConversation', projectId: proj });
              scopes.push({ kind: 'home' });
            }

            for (const panelScope of scopes) {
              if (redesignEnabled) {
                store.dispatch({ type: 'sidePanelV2/setContent', payload: { panelScope, content, tabId } });
              } else {
                store.dispatch({ type: 'sidePanel/setContent', payload: { panelScope, content, tabId } });
              }
              store.dispatch({ type: 'sidePanel/setSidePanelOpen', payload: { panelScope, isOpen: true } });
            }

            if (router && typeof router.navigate === 'function') {
              try {
                router.navigate({
                  search: (prev) => ({ ...(prev || {}), tab: tabId }),
                  replace: true,
                });
              } catch (_e) {}
            }

            notifyIframes();
            setTimeout(() => void notifyIframes(), 200);
            setTimeout(() => void notifyIframes(), 650);
            return true;
          }
        }

        if (sidecarLinkClick) {
          sidecarLinkClick('kupadesk/prompt_panel/');
          notifyIframes();
          setTimeout(() => void notifyIframes(), 200);
          setTimeout(() => void notifyIframes(), 650);
          return true;
        }
      } catch (_err) {}

      // 3. DOM 兜底：若页面上存在扩展菜单项则直接点击
      const directItem = document.querySelector('[data-testid="plugins-submenu-item"][data-sidecar-id*="prompt_panel"]');
      if (directItem) {
        directItem.click();
        setTimeout(() => {
          for (const frame of document.querySelectorAll('iframe[data-testid="sidecar-iframe"]')) {
            try {
              frame.contentWindow?.postMessage?.({ type: 'kupadesk:switch-view', view: targetView, focusTarget }, '*');
              frame.contentWindow?.dispatchEvent?.(new Event('focus'));
            } catch (_e) {}
          }
        }, 250);
        return true;
      }
      return false;
    }

    async function openFullSidePanel(targetView = 'settings', focusTarget = '') {
      cloudDropdownOpen = false;
      popoverOpen = false;
      renderAllBars();
      renderPopover();
      try {
        await bridgeCall('defaults', {
          conversationId: activeConvId,
          requestedView: targetView,
          requestedFocus: focusTarget,
        });
      } catch (_e) {}
      const opened = openHostSidecarPanel(targetView, focusTarget);
      if (!opened) {
        showToast('请在对话右上角 + 菜单中打开 KupaDesk 面板');
      }
    }

    function bindBarEvents(inst) {
      inst.barRoot.addEventListener('click', (e) => {
        if (e.target.closest('#kd-pill-sw') || e.target.closest('.toggle-wrap')) {
          e.preventDefault();
          e.stopPropagation();
          toggleMasterFromPill();
          return;
        }
        if (e.target.closest('#kd-pill-btn')) {
          e.preventDefault();
          e.stopPropagation();
          if (popoverOpen && activeBox === inst.box) {
            popoverOpen = false;
          } else {
            activeBox = inst.box;
            activeConvId = inst.convId;
            popoverOpen = true;
            void loadState({ force: true, claimFocus: true });
          }
          renderAllBars();
          renderPopover();
        }
      });
    }

    function bindPortalEvents(wrap) {
      wrap.addEventListener('click', async (e) => {
        e.stopPropagation();
        const rawTarget = e.target;
        const inMenu = Boolean(rawTarget && typeof rawTarget.closest === 'function' && rawTarget.closest('#kd-cloud-menu'));
        const onTrigger = Boolean(rawTarget && typeof rawTarget.closest === 'function' && rawTarget.closest('#kd-cloud-trigger'));

        if (cloudDropdownOpen && !inMenu && !onTrigger) {
          cloudDropdownOpen = false;
          renderCloudDropdown();
        }

        const actEl = rawTarget && typeof rawTarget.closest === 'function' ? rawTarget.closest('[data-act]') : null;
        if (!actEl) return;
        const act = actEl.dataset.act;
        const id = actEl.dataset.id || '';

        if (act === 'close-pop') {
          popoverOpen = false;
          renderAllBars();
          renderPopover();
          return;
        }
        if (act === 'nav-main') {
          currentView = 'main';
          renderPopover();
          return;
        }
        if (act === 'nav-settings' || act === 'goto-activate') {
          await openFullSidePanel('settings', act === 'goto-activate' ? 'activate' : '');
          return;
        }
        if (act === 'nav-diag') {
          await openFullSidePanel('diag', '');
          return;
        }
        if (act === 'toggle-cloud-dd') {
          cloudDropdownOpen = !cloudDropdownOpen;
          renderCloudDropdown({ focusSearch: cloudDropdownOpen });
          return;
        }
        if (act === 'toggle-cloud-all') {
          cloudDropdownShowAll = !cloudDropdownShowAll;
          updateCloudDropdownListOnly();
          return;
        }
        if (act === 'clear-clouds') {
          await saveConfig({ selectedCloudIds: [] }, '已清空已选云核心');
          return;
        }
        if (act === 'rm-cloud') {
          const next = (stateData?.conversation?.selectedCloudIds || []).filter((x) => x !== id);
          await saveConfig({ selectedCloudIds: next });
          return;
        }
        if (act === 'toggle-cloud') {
          const cur = stateData?.conversation?.selectedCloudIds || [];
          const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
          await saveConfig({ selectedCloudIds: next });
          return;
        }
        if (act === 'star-cloud') {
          const curDefs = stateData?.global?.defaults?.defaultCloudIds || [];
          const adding = !curDefs.includes(id);
          const nextDefs = adding ? [...curDefs, id] : curDefs.filter((x) => x !== id);
          try {
            const res = await bridgeCall('cloud.preferences', {
              conversationId: activeConvId,
              defaultCloudIds: nextDefs,
              ...(adding && stateData?.global?.cloud?.filterEnabled
                ? { visibleCloudIds: [...new Set([...(stateData.global.cloud.visibleCloudIds || []), id])] }
                : {}),
            });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
            showToast(adding ? '已设为新对话默认' : '已取消默认');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'toggle-preset') {
          const cur = stateData?.conversation?.selectedPresetIds || [];
          const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
          await saveConfig({ selectedPresetIds: next });
          return;
        }
        if (act === 'save-custom') {
          const ta = portalRoot.getElementById('pop-custom-input');
          await saveConfig({ customPrompt: ta ? ta.value : customDraft }, '已保存补充指令');
          return;
        }
        if (act === 'clear-custom') {
          customDraft = '';
          customDirty = false;
          await saveConfig({ customPrompt: '' }, '已清空补充指令');
          return;
        }
        if (act === 'refresh-cloud') {
          try {
            const res = await bridgeCall('cloud.refresh', { conversationId: activeConvId });
            stateEtag = res.etag || '';
            stateData = res;
            renderAllBars();
            renderPopover({ skipIfEditing: true });
            showToast('云核心目录已刷新');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'sync-rule-now') {
          try {
            const res = await bridgeCall('rule.syncNow', { conversationId: activeConvId });
            stateEtag = res.etag || '';
            stateData = res;
            renderAllBars();
            renderPopover({ skipIfEditing: true });
            showToast('已接管并同步到当前对话');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'set-anchor-interval') {
          const val = Number(actEl.dataset.val);
          if (Number.isFinite(val) && val > 0) {
            await saveConfig({ anchorIntervalTurns: val }, `防遗忘锚点间隔已设为每 ${val} 轮`);
          }
          return;
        }
        if (act === 'set-channel') {
          const val = actEl.dataset.val;
          if (val && val !== (stateData?.conversation?.channel || 'system-instruction')) {
            await saveConfig({ channel: val }, val === 'system-instruction' ? '已切换为顶层 systemInstruction' : '已切换为 Hook 兼容模式');
          }
          return;
        }
        if (act === 'set-mode') {
          await saveConfig({ mode: actEl.dataset.val });
          return;
        }
        if (act === 'save-origin') {
          const inp = portalRoot.getElementById('pop-origin-input');
          try {
            const res = await bridgeCall('cloud.origin', { conversationId: activeConvId, origin: inp?.value?.trim() || '' });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover();
            showToast('云端地址已保存');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'activate-card') {
          const cardInp = portalRoot.getElementById('pop-card-input');
          const origInp = portalRoot.getElementById('pop-origin-input');
          const card = cardInp?.value?.trim() || '';
          if (!card) return showToast('请输入 KupaDesk 卡密');
          try {
            const res = await bridgeCall('cloud.activate', {
              conversationId: activeConvId,
              card,
              origin: origInp?.value?.trim() || undefined,
            });
            if (cardInp) cardInp.value = '';
            stateEtag = res.etag || '';
            stateData = res;
            renderAllBars();
            renderPopover();
            showToast('卡密已激活');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'ask-deactivate') {
          confirmDeactivate = true;
          renderPopover();
          return;
        }
        if (act === 'confirm-deactivate') {
          try {
            const res = await bridgeCall('cloud.deactivate', { conversationId: activeConvId });
            confirmDeactivate = false;
            stateEtag = res.etag || '';
            stateData = res;
            renderAllBars();
            renderPopover();
            showToast('已清除本机云端授权');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'set-ftab') {
          filterTab = actEl.dataset.val || 'all';
          renderPopover();
          return;
        }
        if (act === 'new-preset') {
          presetFormState = { id: '', name: '', description: '', content: '', title: '新建预设' };
          renderPopover();
          return;
        }
        if (act === 'edit-preset') {
          const p = (stateData?.global?.presets || []).find((x) => x.id === id);
          if (p) {
            presetFormState = { id: p.id, name: p.name, description: p.description || '', content: p.content || '', title: '编辑预设' };
            renderPopover();
          }
          return;
        }
        if (act === 'cancel-preset') {
          presetFormState = null;
          renderPopover();
          return;
        }
        if (act === 'save-preset') {
          const name = portalRoot.getElementById('pop-pf-name')?.value?.trim() || '';
          const description = portalRoot.getElementById('pop-pf-desc')?.value?.trim() || '';
          const content = portalRoot.getElementById('pop-pf-content')?.value || '';
          if (!name) return showToast('请输入预设名称');
          try {
            const res = await bridgeCall('presets.upsert', {
              conversationId: activeConvId,
              id: presetFormState?.id || undefined,
              name,
              description,
              content,
            });
            presetFormState = null;
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover();
            showToast('预设已保存');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'del-preset') {
          confirmDeletePresetId = id;
          renderPopover();
          return;
        }
        if (act === 'confirm-del-preset') {
          try {
            const res = await bridgeCall('presets.delete', { conversationId: activeConvId, id });
            confirmDeletePresetId = '';
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover();
            showToast('已删除预设');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'copy-preview') {
          const txt = stateData?.preview?.finalMessage || '';
          if (txt && navigator.clipboard) {
            navigator.clipboard.writeText(txt).then(() => showToast('已复制预览')).catch(() => showToast('复制失败'));
          }
          return;
        }
        if (act === 'clear-logs') {
          if (!confirmClearLogs) {
            confirmClearLogs = true;
            renderPopover();
            return;
          }
          try {
            const res = await bridgeCall('conversation.clearHistory', { conversationId: activeConvId });
            confirmClearLogs = false;
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover();
            showToast('已清空轨迹');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'update-check') {
          try {
            const res = await bridgeCall('update.check', { conversationId: activeConvId });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
            const up = res.update;
            if (up?.available && up?.latest) {
              showToast(`发现新版本 v${up.latest.version}`);
            } else if (up?.status === 'up_to_date') {
              showToast('当前已是最新版本');
            } else if (up?.status === 'not_published') {
              showToast('云端暂未发布更新清单');
            } else if (up?.error?.message) {
              showToast(up.error.message);
            }
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'update-install') {
          updateBusy = true;
          renderPopover({ skipIfEditing: true });
          try {
            const res = await bridgeCall('update.install', { conversationId: activeConvId });
            updateBusy = false;
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
            const ir = res.installResult;
            if (ir?.updated) {
              showToast(`已更新至 v${ir.toVersion}，后台正在热重启服务，请稍候按 Ctrl+R 刷新界面`);
              setTimeout(() => void loadState({ force: true }), 2600);
            } else {
              showToast('当前已是最新版本');
            }
          } catch (err) {
            updateBusy = false;
            renderPopover({ skipIfEditing: true });
            showToast(err.message);
          }
          return;
        }
        if (act === 'cn-install-all') {
          confirmCnInstallAll = true;
          renderPopover();
          return;
        }
        if (act === 'cn-install-all-cancel') {
          confirmCnInstallAll = false;
          renderPopover();
          return;
        }
        if (act === 'cn-install-all-confirm') {
          try {
            const r = await bridgeCall('cn.action', { action: 'install-all' });
            confirmCnInstallAll = false;
            renderPopover();
            showToast(r?.message || '已调度全套安装并重启');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'desktop-install') {
          try {
            const r = await bridgeCall('desktop.install', {});
            showToast(r?.message || '已调度重启挂载');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'desktop-uninstall') {
          confirmDesktopUninstall = true;
          renderPopover();
          return;
        }
        if (act === 'desktop-uninstall-cancel') {
          confirmDesktopUninstall = false;
          renderPopover();
          return;
        }
        if (act === 'desktop-uninstall-confirm') {
          try {
            const r = await bridgeCall('desktop.uninstall', {});
            confirmDesktopUninstall = false;
            showToast(r?.message || '已调度移除并重启');
          } catch (err) {
            showToast(err.message);
          }
        }
      });

      wrap.addEventListener('change', async (e) => {
        const t = e.target;
        if (!t) return;
        if (t.id === 'pop-def-autoupdate') {
          try {
            const res = await bridgeCall('defaults', {
              conversationId: activeConvId,
              autoCheckUpdates: t.checked,
            });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (t.id === 'pop-cn-autotitle' || t.id === 'pop-cn-rule') {
          const patch = t.id === 'pop-cn-autotitle' ? { autoChineseTitle: t.checked } : { cnLanguageRule: t.checked };
          try {
            const res = await bridgeCall('cn.settings', { conversationId: activeConvId, ...patch });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
            showToast('中文增强设置已更新');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (t.id === 'pop-master-sw') {
          await saveConfig({ enabled: t.checked }, t.checked ? '已开启 KupaDesk 同步' : '已关闭并清除规则');
          return;
        }
        if (t.id === 'pop-custom-en') {
          await saveConfig({ customEnabled: t.checked });
          return;
        }
        if (t.id === 'pop-opt-fallback') {
          await saveConfig({ firstTurnFallback: t.checked });
          return;
        }
        if (t.id === 'pop-opt-anchor') {
          await saveConfig({ anchorEnabled: t.checked });
          return;
        }
        if (t.id === 'pop-def-protect') {
          try {
            const res = await bridgeCall('defaults', {
              conversationId: activeConvId,
              protectRunningFocus: t.checked,
            });
            stateEtag = res.etag || '';
            stateData = res;
            renderAllBars();
            renderPopover({ skipIfEditing: true });
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (t.id === 'pop-opt-wrap') {
          await saveConfig({ wrapAsHighestPriority: t.checked });
          return;
        }
        if (t.id === 'pop-opt-deact') {
          await saveConfig({ sendDeactivationNotice: t.checked });
          return;
        }
        if (t.id === 'pop-def-pill' || t.id === 'pop-def-claim' || t.id === 'pop-def-new') {
          const patch =
            t.id === 'pop-def-pill'
              ? { showSessionStartPill: t.checked }
              : t.id === 'pop-def-claim'
              ? { autoClaimStaging: t.checked }
              : { enabledForNew: t.checked };
          try {
            const res = await bridgeCall('defaults', { conversationId: activeConvId, ...patch });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (t.id === 'pop-filter-en') {
          try {
            const res = await bridgeCall('cloud.preferences', { conversationId: activeConvId, filterEnabled: t.checked });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (t.dataset && t.dataset.act === 'toggle-vis-cloud') {
          const cid = t.dataset.id;
          const cur = stateData?.global?.cloud?.visibleCloudIds || [];
          const next = t.checked ? [...new Set([...cur, cid])] : cur.filter((x) => x !== cid);
          try {
            const res = await bridgeCall('cloud.preferences', { conversationId: activeConvId, visibleCloudIds: next });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
          } catch (err) {
            showToast(err.message);
          }
        }
      });

      wrap.addEventListener('input', (e) => {
        const t = e.target;
        if (!t) return;
        if (t.id === 'pop-cloud-search') {
          mainCloudQuery = t.value;
          updateCloudDropdownListOnly();
          return;
        }
        if (t.id === 'pop-filter-search') {
          filterQuery = t.value;
          renderPopover({ skipIfEditing: false });
          const inp = portalRoot.getElementById('pop-filter-search');
          if (inp) {
            inp.focus();
            inp.setSelectionRange(filterQuery.length, filterQuery.length);
          }
          return;
        }
        if (t.id === 'pop-custom-input') {
          customDirty = true;
          customDraft = t.value;
          clearTimeout(saveTimer);
          saveTimer = setTimeout(() => {
            void saveConfig({ customPrompt: customDraft });
          }, 500);
        }
      });

      wrap.addEventListener('keydown', (e) => {
        if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 's' && e.target?.id === 'pop-custom-input') {
          e.preventDefault();
          clearTimeout(saveTimer);
          void saveConfig({ customPrompt: e.target.value }, '已保存补充指令');
        }
      });
    }

    const INLINE_BAR_STYLE =
      'display:flex;justify-content:flex-end;align-items:center;width:100%;align-self:stretch;flex-shrink:0;margin:0 0 6px 0;padding:0;box-sizing:border-box;pointer-events:none;position:relative;top:auto;left:auto;z-index:auto;';

    function mountBarHost(box, barHost) {
      let anchor = box;
      let parent = box.parentElement;
      for (let i = 0; i < 2 && parent && !isVerticalContainer(parent); i++) {
        anchor = parent;
        parent = parent.parentElement;
      }
      if (parent && isVerticalContainer(parent)) {
        barHost.style.cssText = INLINE_BAR_STYLE;
        parent.insertBefore(barHost, anchor);
        return { fixedMode: false, anchor };
      }
      barHost.style.cssText = INLINE_BAR_STYLE;
      (document.body || document.documentElement).appendChild(barHost);
      return { fixedMode: true, anchor: box };
    }

    function switchToFixedFallback(inst) {
      inst.fixedMode = true;
      const body = document.body || document.documentElement;
      if (inst.barHost.parentElement !== body) {
        body.appendChild(inst.barHost);
      }
    }

    function alignBarHostToBox(inst) {
      const { box, barHost, barRoot } = inst;
      if (!box.isConnected || !barHost.isConnected) return;
      const boxRect = box.getBoundingClientRect();
      const wrap = barRoot.getElementById('kd-bar-wrap');

      if (!inst.fixedMode) {
        barHost.style.width = '100%';
        barHost.style.alignSelf = 'stretch';
        barHost.style.flexShrink = '0';
        barHost.style.margin = '0 0 6px 0';
        if (wrap) wrap.style.marginRight = '0px';
        const barRect = barHost.getBoundingClientRect();
        if (barRect.height < 16 || barRect.bottom > boxRect.top + 6) {
          switchToFixedFallback(inst);
        } else if (wrap) {
          const rightInset = Math.max(0, Math.round(barRect.right - boxRect.right));
          wrap.style.marginRight = `${rightInset}px`;
          return;
        } else {
          return;
        }
      }

      if (wrap) wrap.style.marginRight = '0px';
      const barH = Math.max(24, Math.round(barHost.getBoundingClientRect().height || 24));
      barHost.style.position = 'fixed';
      barHost.style.margin = '0';
      barHost.style.top = `${Math.max(4, Math.round(boxRect.top - barH - 6))}px`;
      barHost.style.left = `${Math.max(8, Math.round(boxRect.left))}px`;
      barHost.style.width = `${Math.round(boxRect.width)}px`;
      barHost.style.zIndex = '2147482000';
    }

    function syncComposers() {
      detectTheme();
      const boxes = findPrimaryComposers();
      const boxSet = new Set(boxes);

      for (const [box, inst] of instances.entries()) {
        if (!boxSet.has(box)) {
          inst.barHost.remove();
          instances.delete(box);
          if (activeBox === box) {
            activeBox = null;
            popoverOpen = false;
            renderPopover();
          }
        }
      }

      let focusConvChanged = false;
      for (const box of boxes) {
        let inst = instances.get(box);
        const nextConvId = resolveConversationId(box);
        if (!inst) {
          const barHost = document.createElement('div');
          barHost.setAttribute(BAR_HOST_ATTR, '1');
          barHost.dataset.theme = currentTheme;
          barHost.style.cssText = INLINE_BAR_STYLE;
          const barRoot = barHost.attachShadow({ mode: 'open' });
          const st = document.createElement('style');
          st.textContent = BAR_CSS;
          const wrap = document.createElement('div');
          wrap.id = 'kd-bar-wrap';
          barRoot.appendChild(st);
          barRoot.appendChild(wrap);

          const mounted = mountBarHost(box, barHost);
          inst = { box, barHost, barRoot, convId: nextConvId, fixedMode: mounted.fixedMode, anchor: mounted.anchor };
          instances.set(box, inst);
          bindBarEvents(inst);
          renderBar(inst);
        } else {
          if (!inst.barHost.isConnected) {
            const mounted = mountBarHost(box, inst.barHost);
            inst.fixedMode = mounted.fixedMode;
            inst.anchor = mounted.anchor;
          } else if (
            !inst.fixedMode &&
            inst.anchor &&
            inst.anchor.parentElement === inst.barHost.parentElement &&
            inst.barHost.nextElementSibling !== inst.anchor
          ) {
            inst.anchor.parentElement.insertBefore(inst.barHost, inst.anchor);
          }
          if (inst.convId !== nextConvId) {
            inst.convId = nextConvId;
          }
        }
        alignBarHostToBox(inst);
      }

      if (boxes.length > 0) {
        const targetBox = activeBox && boxSet.has(activeBox) ? activeBox : boxes[0];
        const targetInst = instances.get(targetBox);
        if (targetBox !== activeBox || (targetInst && targetInst.convId !== activeConvId)) {
          activeBox = targetBox;
          activeConvId = targetInst ? targetInst.convId : '';
          stateEtag = '';
          customDirty = false;
          focusConvChanged = true;
        }
      }

      if (focusConvChanged || (!stateData && boxes.length > 0)) {
        void loadState({ force: true });
      }
      if (popoverOpen) positionPopover();
    }

    function scheduleSync() {
      if (syncScheduled) return;
      syncScheduled = true;
      requestAnimationFrame(() => {
        syncScheduled = false;
        syncComposers();
      });
    }

    function isOwnNode(target) {
      if (!target) return false;
      if (portalHost && (target === portalHost || portalHost.contains(target))) return true;
      for (const inst of instances.values()) {
        if (target === inst.barHost || inst.barHost.contains(target)) return true;
      }
      return false;
    }

    const domObserver = new MutationObserver((records) => {
      if (records.some((r) => !isOwnNode(r.target))) {
        scheduleSync();
      }
    });
    domObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'data-cascade-id', 'data-testid'],
    });

    function isInsideInteractiveUi(e) {
      const path = typeof e.composedPath === 'function' ? e.composedPath() : [e.target];
      for (const n of path) {
        if (!n || n === window || n === document) continue;
        if (n.id === 'kd-pop' || n.id === 'kd-cloud-menu') return true;
        if (n.classList && n.classList.contains('pill')) return true;
      }
      return false;
    }

    function handleOutsideDismiss(e) {
      if (!popoverOpen) return;
      if (isInsideInteractiveUi(e)) return;
      cloudDropdownOpen = false;
      popoverOpen = false;
      renderAllBars();
      renderPopover();
    }

    window.addEventListener('pointerdown', handleOutsideDismiss, true);
    window.addEventListener('mousedown', handleOutsideDismiss, true);
    window.addEventListener('blur', () => {
      if (!popoverOpen) return;
      cloudDropdownOpen = false;
      popoverOpen = false;
      renderAllBars();
      renderPopover();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && popoverOpen) {
        if (cloudDropdownOpen) {
          cloudDropdownOpen = false;
          renderCloudDropdown();
          return;
        }
        popoverOpen = false;
        renderAllBars();
        renderPopover();
      }
    });

    document.addEventListener('focusin', (e) => {
      const box = e.target && typeof e.target.closest === 'function' ? e.target.closest('[data-testid="agent-input-box"]') : null;
      if (box && instances.has(box)) {
        const inst = instances.get(box);
        const boxChanged = box !== activeBox;
        const convChanged = Boolean(inst && inst.convId !== activeConvId);
        const needsTakeover = Boolean(stateData?.focusGuard?.protected && !stateData.focusGuard.ownerRunning);
        if (boxChanged) activeBox = box;
        if (convChanged || boxChanged) {
          activeConvId = inst ? inst.convId : '';
          stateEtag = '';
          customDirty = false;
          void loadState({ force: true, claimFocus: true });
        } else if (needsTakeover) {
          void loadState({ force: true, claimFocus: true });
        }
      }
    });

    window.addEventListener('resize', () => {
      for (const inst of instances.values()) {
        alignBarHostToBox(inst);
      }
      if (popoverOpen) {
        positionPopover();
        if (cloudDropdownOpen) positionCloudDropdown();
      }
    });

    window.addEventListener(
      'scroll',
      () => {
        for (const inst of instances.values()) {
          if (inst.fixedMode) alignBarHostToBox(inst);
        }
        if (popoverOpen) {
          positionPopover();
          if (cloudDropdownOpen) positionCloudDropdown();
        }
      },
      true
    );

    setInterval(() => {
      syncComposers();
      const now = Date.now();
      const interval = document.hidden ? 10000 : 2500;
      if (now - lastFetchAt >= interval && instances.size > 0) {
        void loadState({ force: false });
      }
    }, 1000);

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', syncComposers, { once: true });
    } else {
      syncComposers();
    }
  } catch (_err) {}
})();

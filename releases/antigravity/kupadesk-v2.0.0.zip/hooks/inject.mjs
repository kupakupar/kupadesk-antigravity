import { evaluateHookEvent, readBridgeInfo } from '../lib/store.mjs';

async function readStdin() {
  const chunks = [];
  for await (const chunk of process.stdin) {
    chunks.push(typeof chunk === 'string' ? Buffer.from(chunk, 'utf-8') : chunk);
  }
  return Buffer.concat(chunks).toString('utf-8').trim();
}

async function trySidecarEval(payload) {
  const bridge = readBridgeInfo();
  if (!bridge) return null;
  try {
    const res = await fetch(`http://127.0.0.1:${bridge.port}/eval`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-Hook-Secret': bridge.secret,
      },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(6500),
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data && typeof data === 'object' ? data : null;
  } catch {
    return null;
  }
}

async function main() {
  try {
    const raw = await readStdin();
    const payload = raw ? JSON.parse(raw) : {};
    let remoteOutput = await trySidecarEval(payload);
    if (remoteOutput === null) {
      await new Promise((resolve) => setTimeout(resolve, 400));
      remoteOutput = await trySidecarEval(payload);
    }
    if (remoteOutput !== null) {
      process.stdout.write(JSON.stringify(remoteOutput) + '\n');
    } else {
      const { output } = evaluateHookEvent(payload);
      process.stdout.write(JSON.stringify(output ?? {}) + '\n');
    }
  } catch (err) {
    process.stderr.write(`[kupadesk hook error] ${err?.stack || err?.message || String(err)}\n`);
    process.stdout.write('{}\n');
  }
  process.exitCode = 0;
}

main();

process.noAsar = true;

import { createRequire } from 'node:module';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const require = createRequire(import.meta.url);
const { readState } = require('../lib/cn-core.cjs');
const {
  deriveChineseTitle,
  extractFirstUserRequest,
  shouldAutoRenameSummary,
} = require('../lib/title-utils.cjs');

async function readStdinSafe(timeoutMs = 800) {
  if (process.stdin.isTTY) return '';
  return new Promise((resolve) => {
    const chunks = [];
    let settled = false;
    const done = () => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      resolve(Buffer.concat(chunks).toString('utf8').trim());
    };
    const timer = setTimeout(done, timeoutMs);
    process.stdin.on('data', (chunk) => {
      chunks.push(typeof chunk === 'string' ? Buffer.from(chunk, 'utf8') : chunk);
    });
    process.stdin.on('end', done);
    process.stdin.on('error', done);
  });
}

function buildLsHeaders(csrfToken) {
  const headers = { 'Content-Type': 'application/json' };
  if (csrfToken) {
    headers['x-codeium-csrf-token'] = csrfToken;
  }
  return headers;
}

async function callLsRpc(addr, csrfToken, method, bodyObj, timeoutMs = 2000) {
  const url = `http://${addr}/exa.language_server_pb.LanguageServerService/${method}`;
  const res = await fetch(url, {
    method: 'POST',
    headers: buildLsHeaders(csrfToken),
    body: JSON.stringify(bodyObj || {}),
    signal: AbortSignal.timeout(timeoutMs),
  });
  if (!res.ok) {
    throw new Error(`HTTP ${res.status}`);
  }
  return res.json();
}

export async function runAutoTitle(payload = {}, options = {}) {
  const state = readState(options.dataDir);
  if (state.autoChineseTitle === false) {
    return { skipped: 'disabled' };
  }

  const conversationId = String(payload.conversationId || '').trim();
  const addr = String(options.lsAddress || process.env.ANTIGRAVITY_LS_ADDRESS || '').trim();
  const csrfToken = String(options.csrfToken ?? process.env.ANTIGRAVITY_CSRF_TOKEN ?? '').trim();

  if (!conversationId || !addr) {
    return { skipped: 'missing_context' };
  }

  const trajectories = await callLsRpc(addr, csrfToken, 'GetAllCascadeTrajectories', {
    excludeSubtrajectories: true,
  });
  const summaryObj = trajectories?.trajectorySummaries?.[conversationId];
  if (!shouldAutoRenameSummary(summaryObj)) {
    return { skipped: 'not_eligible' };
  }

  const firstPrompt = extractFirstUserRequest(payload.transcriptPath, payload.lastUserInput);
  const nextTitle = deriveChineseTitle(firstPrompt);
  if (!nextTitle) {
    return { skipped: 'no_suitable_chinese_title' };
  }

  await callLsRpc(addr, csrfToken, 'UpdateConversationAnnotations', {
    cascadeIds: [conversationId],
    annotations: { title: nextTitle },
    mergeAnnotations: true,
  });

  return { renamed: true, title: nextTitle };
}

async function main() {
  try {
    const raw = await readStdinSafe();
    const payload = raw ? JSON.parse(raw) : {};
    await runAutoTitle(payload);
  } catch {
    // 静默兜底，绝不阻塞或影响对话结束
  }
  process.stdout.write('{}\n');
  process.exitCode = 0;
}

const isEntry = process.argv[1] &&
  path.resolve(fileURLToPath(import.meta.url)).toLowerCase() === path.resolve(process.argv[1]).toLowerCase();

if (isEntry) {
  main();
}

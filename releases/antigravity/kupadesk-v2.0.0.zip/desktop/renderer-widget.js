(() => {
  'use strict';

  try {
    if (window.__kupadeskDesktopMounted) return;
    if (!window.__kupadeskDesktopBridge || typeof window.__kupadeskDesktopBridge.invoke !== 'function') return;
    window.__kupadeskDesktopMounted = true;

    const BAR_HOST_ATTR = 'data-kupadesk-bar';
    const PORTAL_HOST_ID = 'kupadesk-desktop-portal';
    const UUID_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
    const EXCLUDE_SUBPANE_SELECTOR = '[data-testid="side-question-tab-content"],[data-media-drop-scope="subpane"],aside';

    const MODE_META = {
      'every-turn': { label: '每轮置顶' },
      'on-change': { label: '变更注入' },
      'every-invocation': { label: '每次调用' },
    };

    const instances = new Map(); // box -> { barHost, barRoot, convId, fixedMode }
    let activeBox = null;
    let activeConvId = '';
    let popoverOpen = false;
    let stateData = null;
    let stateEtag = '';
    let offlineState = false;
    let pluginDisabled = false;
    let toastTimer = null;
    let mainCloudQuery = '';
    let cloudDropdownOpen = false;
    let cloudDropdownShowAll = false;
    let syncScheduled = false;
    let pollInFlight = false;
    let lastFetchAt = 0;
    let portalHost = null;
    let portalRoot = null;
    let currentTheme = 'dark';

    const esc = (s) =>
      String(s ?? '').replace(/[&<>"']/g, (c) => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;',
      }[c]));

    function shortId(id) {
      if (!id) return '';
      return id.length > 14 ? `${id.slice(0, 6)}…${id.slice(-4)}` : id;
    }

    function detectTheme() {
      try {
        const probe = document.createElement('span');
        probe.style.cssText = 'position:absolute;visibility:hidden;color:var(--background, #18181b)';
        (document.body || document.documentElement).appendChild(probe);
        const c = getComputedStyle(probe).color;
        probe.remove();
        const nums = (c.match(/[\d.]+/g) || []).map(Number);
        if (nums.length >= 3) {
          const scale = c.startsWith('color(') ? 1 : 255;
          const [r, g, b] = nums.slice(0, 3).map((v) => v / scale);
          const lum = 0.2126 * r + 0.7152 * g + 0.0722 * b;
          currentTheme = lum < 0.5 ? 'dark' : 'light';
        }
      } catch (_e) {}
      if (portalHost) portalHost.dataset.theme = currentTheme;
      for (const inst of instances.values()) {
        inst.barHost.dataset.theme = currentTheme;
      }
    }

    async function bridgeCall(action, payload) {
      const res = await window.__kupadeskDesktopBridge.invoke(action, payload || {});
      if (!res || res.ok === false) {
        const err = new Error(res?.error || '请求失败');
        err.offline = Boolean(res?.offline);
        err.disabled = Boolean(res?.disabled);
        err.code = res?.code || '';
        throw err;
      }
      return res.data;
    }

    function isVisible(el) {
      if (!el || !el.isConnected) return false;
      const st = getComputedStyle(el);
      if (st.display === 'none' || st.visibility === 'hidden') return false;
      const r = el.getBoundingClientRect();
      return r.width > 0 && r.height > 0;
    }

    function resolveConversationId(box) {
      if (!box || !box.isConnected) return '';
      const readId = (el) => {
        if (!el) return '';
        const val = el.getAttribute('data-cascade-id');
        return UUID_RE.test(val || '') ? val.toLowerCase() : '';
      };
      for (let el = box, hops = 0; el && el !== document.body && hops < 28; el = el.parentElement, hops++) {
        if (el.matches('[data-testid="conversation-view"]')) {
          return readId(el);
        }
        const direct = readId(el);
        if (direct) return direct;
        if (el.matches(EXCLUDE_SUBPANE_SELECTOR)) return '';
      }
      const m = location.pathname.match(/\/c\/([0-9a-f-]{36})/i);
      return m && UUID_RE.test(m[1]) ? m[1].toLowerCase() : '';
    }

    function findPrimaryComposers() {
      const boxes = Array.from(document.querySelectorAll('[data-testid="agent-input-box"]')).filter((box) => {
        if (!isVisible(box)) return false;
        if (box.closest(EXCLUDE_SUBPANE_SELECTOR) && !box.closest('[data-testid="conversation-view"]')) {
          return false;
        }
        return true;
      });
      return boxes;
    }

    function isVerticalContainer(el) {
      if (!el) return false;
      const st = getComputedStyle(el);
      if (st.display === 'block' || st.display === 'grid') return true;
      if (st.display.includes('flex') && st.flexDirection === 'column') return true;
      return false;
    }

    // ---------- 样式定义 ----------
    const BAR_CSS = `
      :host {
        --kd-bg: var(--background, #18181b);
        --kd-card: var(--card, #222327);
        --kd-fg: var(--foreground, #f4f4f5);
        --kd-muted: var(--muted-foreground, #a1a1aa);
        --kd-border: var(--card-border, rgba(255, 255, 255, 0.12));
        --kd-primary: var(--primary, #3b82f6);
        --kd-success: #7aae66;
        --kd-warn: #cab43e;
        --kd-font: var(--font-family, "Google Sans Flex", system-ui, -apple-system, "Segoe UI", "Microsoft YaHei UI", sans-serif);
        display: flex;
        justify-content: flex-end;
        align-items: center;
        box-sizing: border-box;
        font-family: var(--kd-font);
      }
      :host([data-theme="light"]) {
        --kd-bg: var(--background, #f7f7f8);
        --kd-card: var(--card, #ffffff);
        --kd-fg: var(--foreground, #1d1f21);
        --kd-muted: var(--muted-foreground, #5d676f);
        --kd-border: var(--card-border, rgba(0, 0, 0, 0.11));
        --kd-success: #568943;
        --kd-warn: #b09123;
      }
      .pill {
        pointer-events: auto;
        display: inline-flex;
        align-items: center;
        height: 24px;
        border-radius: 999px;
        border: 1px solid var(--kd-border);
        background: color-mix(in srgb, var(--kd-card) 86%, transparent);
        backdrop-filter: blur(8px);
        color: var(--kd-fg);
        box-shadow: 0 1px 4px rgba(0, 0, 0, 0.16);
        overflow: hidden;
        font-size: 11.5px;
        line-height: 1;
        user-select: none;
        transition: border-color 0.14s ease, background-color 0.14s ease;
      }
      .pill:hover {
        border-color: color-mix(in srgb, var(--kd-fg) 24%, transparent);
      }
      .pill-trigger {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        height: 100%;
        padding: 0 8px 0 9px;
        border: 0;
        background: transparent;
        color: inherit;
        font: inherit;
        cursor: pointer;
        max-width: 240px;
      }
      .pill-trigger:hover {
        background: color-mix(in srgb, var(--kd-fg) 6%, transparent);
      }
      .dot {
        width: 6px;
        height: 6px;
        border-radius: 50%;
        flex: none;
        background: color-mix(in srgb, var(--kd-muted) 60%, transparent);
      }
      .dot.ok {
        background: var(--kd-success);
        box-shadow: 0 0 0 2px color-mix(in srgb, var(--kd-success) 24%, transparent);
      }
      .dot.warn {
        background: var(--kd-warn);
        box-shadow: 0 0 0 2px color-mix(in srgb, var(--kd-warn) 24%, transparent);
      }
      .label {
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        font-weight: 500;
        color: var(--kd-fg);
      }
      .label.muted {
        color: var(--kd-muted);
      }
      .badge {
        display: inline-flex;
        align-items: center;
        padding: 1px 4px;
        border-radius: 999px;
        font-size: 10px;
        font-weight: 600;
        background: color-mix(in srgb, var(--kd-fg) 10%, transparent);
        color: var(--kd-muted);
        flex: none;
      }
      .badge.warn {
        color: var(--kd-warn);
        background: color-mix(in srgb, var(--kd-warn) 16%, transparent);
      }
      .badge.ok {
        color: var(--kd-primary);
        background: color-mix(in srgb, var(--kd-primary) 16%, transparent);
      }
      .chev {
        width: 11px;
        height: 11px;
        flex: none;
        color: var(--kd-muted);
        transition: transform 0.16s ease;
      }
      .pill.open .chev {
        transform: rotate(180deg);
      }
      .sep {
        width: 1px;
        height: 12px;
        background: var(--kd-border);
        flex: none;
      }
      .toggle-wrap {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        height: 100%;
        padding: 0 7px 0 6px;
        cursor: pointer;
      }
      .toggle-wrap:hover {
        background: color-mix(in srgb, var(--kd-fg) 6%, transparent);
      }
      .sw-btn {
        position: relative;
        display: inline-block;
        width: 26px;
        height: 14px;
        border: 0;
        padding: 0;
        border-radius: 999px;
        background: color-mix(in srgb, var(--kd-fg) 22%, transparent);
        cursor: pointer;
        transition: background-color 0.15s ease;
      }
      .sw-btn::after {
        content: "";
        position: absolute;
        left: 2px;
        top: 2px;
        width: 10px;
        height: 10px;
        border-radius: 50%;
        background: #ffffff;
        transition: transform 0.15s ease;
      }
      .sw-btn.on {
        background: var(--kd-primary);
      }
      .sw-btn.on::after {
        transform: translateX(12px);
      }
      .sw-btn:disabled {
        opacity: 0.45;
        cursor: default;
      }
    `;

    const POPOVER_CSS = `
      :host {
        --kd-bg: var(--background, #18181b);
        --kd-card: var(--card, #222327);
        --kd-surface: color-mix(in srgb, var(--kd-card) 92%, var(--kd-bg));
        --kd-fg: var(--foreground, #f4f4f5);
        --kd-muted: var(--muted-foreground, #a1a1aa);
        --kd-border: var(--card-border, rgba(255, 255, 255, 0.12));
        --kd-fill: color-mix(in srgb, var(--kd-fg) 7%, transparent);
        --kd-hover: color-mix(in srgb, var(--kd-fg) 10%, transparent);
        --kd-primary: var(--primary, #3b82f6);
        --kd-primary-fg: var(--primary-foreground, #ffffff);
        --kd-success: #7aae66;
        --kd-warn: #cab43e;
        --kd-error: #e05d5d;
        --kd-font: var(--font-family, "Google Sans Flex", system-ui, -apple-system, "Segoe UI", "Microsoft YaHei UI", sans-serif);
        --kd-mono: var(--editor-font-family, ui-monospace, SFMono-Regular, Menlo, Consolas, monospace);
        font-family: var(--kd-font);
      }
      :host([data-theme="light"]) {
        --kd-bg: var(--background, #f7f7f8);
        --kd-card: var(--card, #ffffff);
        --kd-surface: #ffffff;
        --kd-fg: var(--foreground, #1d1f21);
        --kd-muted: var(--muted-foreground, #5d676f);
        --kd-border: var(--card-border, rgba(0, 0, 0, 0.11));
        --kd-fill: rgba(0, 0, 0, 0.05);
        --kd-hover: rgba(0, 0, 0, 0.08);
        --kd-success: #568943;
        --kd-warn: #b09123;
        --kd-error: #cb3d3d;
      }
      * { box-sizing: border-box; }
      .hidden { display: none !important; }
      .pop {
        position: fixed;
        width: 356px;
        max-width: calc(100vw - 16px);
        max-height: min(540px, calc(100vh - 64px));
        display: flex;
        flex-direction: column;
        background: var(--kd-surface);
        color: var(--kd-fg);
        border: 1px solid var(--kd-border);
        border-radius: 10px;
        box-shadow: 0 12px 32px rgba(0, 0, 0, 0.34);
        overflow: hidden;
        font-size: 12.5px;
        line-height: 1.45;
      }
      .hdr {
        padding: 10px 12px 8px;
        border-bottom: 1px solid var(--kd-border);
        display: flex;
        flex-direction: column;
        gap: 4px;
        flex: none;
        background: color-mix(in srgb, var(--kd-card) 70%, transparent);
      }
      .hdr-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
      }
      .hdr-left {
        display: flex;
        align-items: center;
        gap: 7px;
        min-width: 0;
      }
      .hdr-tools {
        display: flex;
        align-items: center;
        gap: 4px;
        flex: none;
      }
      .title {
        margin: 0;
        font-size: 13px;
        font-weight: 600;
      }
      .meta {
        font-size: 11px;
        color: var(--kd-muted);
        white-space: nowrap;
        overflow: hidden;
        text-overflow: ellipsis;
      }
      .meta-row {
        display: flex;
        align-items: center;
        gap: 5px;
        font-size: 11px;
        color: var(--kd-muted);
        min-width: 0;
      }
      .meta-title {
        max-width: 195px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
      .meta-sep, .meta-size {
        flex: none;
        white-space: nowrap;
      }
      .dot {
        width: 7px;
        height: 7px;
        border-radius: 50%;
        background: color-mix(in srgb, var(--kd-muted) 55%, transparent);
        flex: none;
      }
      .dot.ok { background: var(--kd-success); }
      .dot.warn { background: var(--kd-warn); }
      .pill-badge {
        display: inline-flex;
        align-items: center;
        height: 18px;
        padding: 0 6px;
        border-radius: 999px;
        font-size: 10.5px;
        font-weight: 500;
        background: var(--kd-fill);
        color: var(--kd-muted);
        white-space: nowrap;
      }
      .pill-badge.ok { color: var(--kd-success); background: color-mix(in srgb, var(--kd-success) 15%, transparent); }
      .pill-badge.warn { color: var(--kd-warn); background: color-mix(in srgb, var(--kd-warn) 16%, transparent); }
      .pill-badge.err { color: var(--kd-error); background: color-mix(in srgb, var(--kd-error) 16%, transparent); }
      .icon-btn, .ghost-btn, .primary-btn, .danger-btn {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 4px;
        border: 0;
        border-radius: 6px;
        font: inherit;
        font-size: 11.5px;
        font-weight: 500;
        cursor: pointer;
        white-space: nowrap;
        color: var(--kd-muted);
        background: transparent;
      }
      .icon-btn { width: 26px; height: 26px; position: relative; }
      .btn-dot-update {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 6px;
        height: 6px;
        border-radius: 50%;
        background: var(--kd-primary);
      }
      .btn-dot-update.warn { background: var(--kd-warn); }
      .icon-btn:hover, .ghost-btn:hover { background: var(--kd-hover); color: var(--kd-fg); }
      .ghost-btn { height: 24px; padding: 0 8px; }
      .primary-btn { height: 26px; padding: 0 10px; background: var(--kd-primary); color: var(--kd-primary-fg); }
      .primary-btn:hover { filter: brightness(1.07); }
      .danger-btn { height: 24px; padding: 0 8px; background: color-mix(in srgb, var(--kd-error) 14%, transparent); color: var(--kd-error); }
      .danger-btn:hover { background: color-mix(in srgb, var(--kd-error) 22%, transparent); }
      button:disabled { opacity: 0.45; cursor: default; }
      .sw {
        position: relative;
        display: inline-flex;
        align-items: center;
        gap: 5px;
        cursor: pointer;
        font-size: 11.5px;
        color: var(--kd-muted);
        user-select: none;
      }
      .sw input { position: absolute; opacity: 0; width: 0; height: 0; }
      .sw-track {
        width: 30px;
        height: 17px;
        border-radius: 999px;
        background: color-mix(in srgb, var(--kd-fg) 22%, transparent);
        position: relative;
        transition: background-color 0.14s ease;
      }
      .sw-track::after {
        content: "";
        position: absolute;
        left: 2.5px;
        top: 2.5px;
        width: 12px;
        height: 12px;
        border-radius: 50%;
        background: #fff;
        transition: transform 0.14s ease;
      }
      .sw input:checked + .sw-track { background: var(--kd-primary); }
      .sw input:checked + .sw-track::after { transform: translateX(13px); }
      .body {
        flex: 1 1 auto;
        overflow-y: auto;
        padding: 10px 12px 12px;
        display: flex;
        flex-direction: column;
        gap: 9px;
      }
      .card {
        border: 1px solid var(--kd-border);
        border-radius: 8px;
        background: color-mix(in srgb, var(--kd-card) 82%, transparent);
        padding: 9px 10px;
        display: flex;
        flex-direction: column;
        gap: 7px;
      }
      .card-head {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
      }
      .card-title { font-size: 12px; font-weight: 600; margin: 0; }
      .hint { font-size: 11px; color: var(--kd-muted); margin: 0; }
      .alert {
        padding: 6px 8px;
        border-radius: 6px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-error) 14%, transparent);
        color: var(--kd-error);
      }
      .staging-bar {
        padding: 7px 9px;
        border-radius: 7px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-primary) 12%, transparent);
        border: 1px solid color-mix(in srgb, var(--kd-primary) 26%, transparent);
      }
      .guard-bar {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        padding: 7px 9px;
        border-radius: 7px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-warn) 12%, transparent);
        border: 1px solid color-mix(in srgb, var(--kd-warn) 32%, transparent);
        color: var(--kd-fg);
      }
      .guard-bar-text {
        min-width: 0;
        flex: 1 1 auto;
        line-height: 1.4;
      }
      .opt-sub {
        padding-left: 4px;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .tags { display: flex; flex-wrap: wrap; gap: 5px; }
      .tag {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        padding: 2px 6px;
        border-radius: 6px;
        font-size: 11px;
        background: color-mix(in srgb, var(--kd-primary) 14%, transparent);
        border: 1px solid color-mix(in srgb, var(--kd-primary) 26%, transparent);
      }
      .tag-x {
        border: 0;
        background: transparent;
        color: var(--kd-muted);
        cursor: pointer;
        padding: 0 2px;
        font-size: 12px;
        line-height: 1;
      }
      .tag-x:hover { color: var(--kd-fg); }
      .combo-btn {
        width: 100%;
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        height: 30px;
        padding: 0 9px;
        border-radius: 6px;
        border: 1px solid var(--kd-border);
        background: var(--kd-fill);
        color: var(--kd-fg);
        font: inherit;
        font-size: 12px;
        cursor: pointer;
      }
      .combo-panel {
        border: 1px solid var(--kd-border);
        border-radius: 7px;
        padding: 6px;
        background: var(--kd-bg);
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .cloud-float-menu {
        position: fixed;
        z-index: 2147483002;
        border-radius: 9px;
        border: 1px solid var(--kd-border);
        background: var(--kd-surface);
        color: var(--kd-fg);
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.42);
        padding: 8px;
        display: flex;
        flex-direction: column;
        gap: 6px;
        overflow: hidden;
      }
      .combo-list {
        max-height: 196px;
        overflow-y: auto;
        display: flex;
        flex-direction: column;
        gap: 3px;
      }
      .combo-item {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 6px;
        padding: 5px 7px;
        border-radius: 5px;
        cursor: pointer;
      }
      .combo-item:hover { background: var(--kd-hover); }
      .combo-item.on { background: color-mix(in srgb, var(--kd-primary) 15%, transparent); }
      .combo-item-left { display: flex; align-items: center; gap: 6px; min-width: 0; flex: 1; }
      .chk {
        width: 15px;
        height: 15px;
        border-radius: 4px;
        border: 1px solid var(--kd-border);
        display: inline-flex;
        align-items: center;
        justify-content: center;
        font-size: 10px;
        flex: none;
      }
      .combo-item.on .chk {
        background: var(--kd-primary);
        border-color: var(--kd-primary);
        color: var(--kd-primary-fg);
      }
      .combo-name { overflow: hidden; text-overflow: ellipsis; white-space: nowrap; font-size: 12px; }
      .star-btn {
        border: 0;
        background: transparent;
        color: var(--kd-muted);
        cursor: pointer;
        padding: 2px 4px;
        font-size: 13px;
      }
      .star-btn.on { color: var(--kd-warn); }
      .input, .textarea {
        width: 100%;
        border: 1px solid var(--kd-border);
        border-radius: 6px;
        background: var(--kd-bg);
        color: var(--kd-fg);
        font: inherit;
        font-size: 12px;
        padding: 5px 8px;
        outline: none;
      }
      .input:focus, .textarea:focus { border-color: var(--kd-primary); }
      .textarea { resize: vertical; min-height: 68px; font-family: var(--kd-mono); font-size: 11.5px; }
      .chips { display: flex; flex-wrap: wrap; gap: 5px; }
      .chip {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        height: 24px;
        padding: 0 8px;
        border-radius: 999px;
        border: 1px solid var(--kd-border);
        background: var(--kd-fill);
        color: var(--kd-fg);
        font: inherit;
        font-size: 11.5px;
        cursor: pointer;
      }
      .chip.on {
        border-color: var(--kd-primary);
        background: color-mix(in srgb, var(--kd-primary) 18%, transparent);
      }
      .seg {
        display: flex;
        padding: 2px;
        border-radius: 7px;
        background: var(--kd-fill);
        gap: 2px;
      }
      .seg-btn {
        flex: 1;
        height: 24px;
        border: 0;
        border-radius: 5px;
        background: transparent;
        color: var(--kd-muted);
        font: inherit;
        font-size: 11.5px;
        font-weight: 500;
        cursor: pointer;
      }
      .seg-btn.on {
        background: var(--kd-card);
        color: var(--kd-fg);
        box-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
      }
      .diag-strip {
        display: flex;
        align-items: center;
        gap: 7px;
        padding: 7px 9px;
        border: 1px solid var(--kd-border);
        border-radius: 7px;
        background: var(--kd-fill);
        color: var(--kd-fg);
        font: inherit;
        font-size: 11px;
        cursor: pointer;
        text-align: left;
      }
      .diag-strip:hover { background: var(--kd-hover); }
      .diag-strip-text { flex: 1; overflow: hidden; text-overflow: ellipsis; white-space: nowrap; color: var(--kd-muted); }
      .diag-strip-action { flex: none; font-size: 11px; color: var(--kd-muted); }
      .row { display: flex; align-items: center; gap: 6px; }
      .row-between { display: flex; align-items: center; justify-content: space-between; gap: 8px; }
      .toast {
        position: fixed;
        bottom: 24px;
        left: 50%;
        transform: translateX(-50%);
        padding: 5px 11px;
        border-radius: 999px;
        background: var(--kd-fg);
        color: var(--kd-bg);
        font-size: 11px;
        font-weight: 500;
        pointer-events: none;
        box-shadow: 0 4px 14px rgba(0, 0, 0, 0.28);
        z-index: 2147483001;
      }
    `;

    function ensurePortal() {
      if (!portalHost || !portalHost.isConnected) {
        portalHost = document.createElement('div');
        portalHost.id = PORTAL_HOST_ID;
        portalHost.dataset.theme = currentTheme;
        portalHost.style.cssText = 'position:fixed;inset:0;pointer-events:none;z-index:2147483000;';
        (document.body || document.documentElement).appendChild(portalHost);
        portalRoot = portalHost.attachShadow({ mode: 'open' });
        const styleEl = document.createElement('style');
        styleEl.textContent = POPOVER_CSS;
        const wrapEl = document.createElement('div');
        wrapEl.id = 'kd-pop-root';
        wrapEl.style.cssText = 'pointer-events:auto;';
        const ddEl = document.createElement('div');
        ddEl.id = 'kd-dropdown-root';
        ddEl.style.cssText = 'pointer-events:auto;';
        const toastEl = document.createElement('div');
        toastEl.id = 'kd-toast';
        toastEl.className = 'toast hidden';
        portalRoot.appendChild(styleEl);
        portalRoot.appendChild(wrapEl);
        portalRoot.appendChild(ddEl);
        portalRoot.appendChild(toastEl);
        bindPortalEvents(portalRoot);
      }
      return portalRoot.getElementById('kd-pop-root');
    }

    function showToast(msg) {
      ensurePortal();
      if (!portalRoot) return;
      const t = portalRoot.getElementById('kd-toast');
      if (!t) return;
      t.textContent = msg;
      t.classList.remove('hidden');
      clearTimeout(toastTimer);
      toastTimer = setTimeout(() => t.classList.add('hidden'), 2200);
    }

    function renderBar(inst) {
      const { barRoot, barHost } = inst;
      if (pluginDisabled) {
        barHost.style.display = 'none';
        return;
      }
      barHost.style.display = 'flex';
      barHost.dataset.theme = currentTheme;

      const d = stateData;
      const cfg = d?.conversation;
      const preview = d?.preview;
      const enabled = Boolean(cfg?.enabled);
      const isOpen = popoverOpen && activeBox === inst.box;

      let dotClass = 'dot';
      let labelText = 'KupaDesk';
      let labelMuted = !enabled;
      const badges = [];

      if (offlineState && !d) {
        labelText = 'KupaDesk 启动中…';
        labelMuted = true;
      } else if (cfg) {
        const cloudIds = cfg.selectedCloudIds || [];
        const presetIds = cfg.selectedPresetIds || [];
        const allPrompts = d?.cloud?.prompts || [];
        const presets = d?.global?.presets || [];
        const names = [];
        for (const id of cloudIds) {
          const hit = allPrompts.find((p) => p.id === id);
          names.push(hit?.title || shortId(id));
        }
        for (const id of presetIds) {
          const hit = presets.find((p) => p.id === id);
          if (hit) names.push(hit.name);
        }
        if (cfg.customEnabled !== false && String(cfg.customPrompt || '').trim()) {
          names.push('补充指令');
        }

        if (names.length > 0) {
          labelText = names[0];
          if (names.length > 1) badges.push({ text: `+${names.length - 1}`, cls: '' });
        }

        if (preview?.exceedsRuleLimit) {
          dotClass = 'dot warn';
          badges.push({ text: '>24K', cls: 'warn' });
        } else if (preview?.status === 'active') {
          dotClass = 'dot ok';
        } else if (preview?.status === 'empty' || preview?.status === 'cloud_pending' || preview?.status === 'pending_deactivation') {
          dotClass = 'dot warn';
        }

        if (d.isStaging) {
          badges.push({ text: '待命', cls: enabled ? 'ok' : '' });
        }
        if ((cfg.channel || 'system-instruction') === 'hook') {
          badges.push({ text: 'Hook', cls: '' });
        }
      }

      const badgesHtml = badges.map((b) => `<span class="badge ${b.cls}">${esc(b.text)}</span>`).join('');
      const wrap = barRoot.getElementById('kd-bar-wrap');
      if (!wrap) return;
      wrap.innerHTML = `
        <div class="pill${isOpen ? ' open' : ''}">
          <button type="button" class="pill-trigger" id="kd-pill-btn" title="展开 KupaDesk 云核心与系统指令面板">
            <span class="${dotClass}"></span>
            <span class="label${labelMuted ? ' muted' : ''}">${esc(labelText)}</span>
            ${badgesHtml}
            <svg class="chev" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <path d="M4 6l4 4 4-4"/>
            </svg>
          </button>
          <span class="sep" aria-hidden="true"></span>
          <label class="toggle-wrap" title="${enabled ? '关闭 KupaDesk 注入（立即删除规则）' : '开启 KupaDesk 注入'}">
            <button type="button" role="switch" aria-checked="${enabled}" class="sw-btn${enabled ? ' on' : ''}" id="kd-pill-sw" ${offlineState && !d ? 'disabled' : ''}></button>
          </label>
        </div>
      `;
    }

    function renderAllBars() {
      for (const inst of instances.values()) {
        renderBar(inst);
      }
    }

    function positionPopover() {
      if (!popoverOpen || !portalRoot) return;
      const pop = portalRoot.getElementById('kd-pop');
      const inst = activeBox ? instances.get(activeBox) : null;
      if (!pop || !inst) return;
      const pill = inst.barRoot.querySelector('.pill');
      const rect = (pill || inst.barHost).getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const popRect = pop.getBoundingClientRect();
      const popW = popRect.width || 356;
      const popH = popRect.height || 360;

      let left = rect.right - popW;
      left = Math.max(8, Math.min(left, vw - popW - 8));

      let top = rect.top - popH - 8;
      if (top < 8) {
        top = Math.min(vh - popH - 8, rect.bottom + 8);
        if (top < 8) top = 8;
      }
      pop.style.left = `${Math.round(left)}px`;
      pop.style.top = `${Math.round(top)}px`;
    }

    function isEditingInsidePopover() {
      if (!portalRoot) return false;
      const act = portalRoot.activeElement;
      const popRoot = portalRoot.getElementById('kd-pop-root');
      if (!act || !popRoot || !popRoot.contains(act)) return false;
      const tag = act.tagName;
      return tag === 'INPUT' || tag === 'TEXTAREA';
    }

    function renderPopover({ skipIfEditing = false } = {}) {
      const wrap = ensurePortal();
      if (!wrap) return;
      if (!popoverOpen) {
        cloudDropdownOpen = false;
        wrap.innerHTML = '';
        renderCloudDropdown();
        return;
      }
      if (skipIfEditing && isEditingInsidePopover() && portalRoot.getElementById('kd-pop')) {
        return;
      }

      const d = stateData;
      if (!d) {
        cloudDropdownOpen = false;
        wrap.innerHTML = `
          <div class="pop" id="kd-pop">
            <div class="hdr">
              <div class="hdr-row">
                <div class="hdr-left"><span class="dot"></span><h2 class="title">KupaDesk</h2></div>
                <button type="button" class="icon-btn" data-act="close-pop" title="关闭">✕</button>
              </div>
              <div class="meta">${offlineState ? '正在等待 KupaDesk 后台服务就绪…' : '正在加载配置…'}</div>
            </div>
          </div>`;
        positionPopover();
        renderCloudDropdown();
        return;
      }

      const cfg = d.conversation;
      const g = d.global;
      const cloud = d.cloud;
      const preview = d.preview;
      const activeChannel = cfg.channel || 'system-instruction';

      let statusCls = '';
      let statusLabel = '已关闭';
      if (preview?.status === 'active') {
        statusCls = 'ok';
        statusLabel = d.isStaging ? '待命生效' : '生效中';
      } else if (preview?.status === 'empty' || preview?.status === 'cloud_pending' || preview?.status === 'pending_deactivation') {
        statusCls = 'warn';
        statusLabel = preview.status === 'cloud_pending' ? '同步中' : preview.status === 'pending_deactivation' ? '下轮撤销' : '待选核心';
      }

      const bodyHtml = renderMainBody(d, cfg, g, cloud, preview, activeChannel);

      const fullTitle = d.isStaging
        ? '空白新对话待命'
        : d.conversationTitle
        ? d.conversationTitle
        : `对话 ${shortId(d.conversationId)}`;
      const rightMeta = d.isStaging
        ? activeChannel === 'system-instruction'
          ? '顶层 systemInstruction'
          : 'Hook 轨迹'
        : activeChannel === 'system-instruction'
        ? preview?.status === 'active'
          ? `${preview.byteLength} / ${preview.ruleByteLimit} B`
          : '未同步'
        : MODE_META[cfg.mode]?.label || cfg.mode;

      const SPARK_SVG = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="m8 2 1.35 3.15L12.5 6.5 9.35 7.85 8 11 6.65 7.85 3.5 6.5l3.15-1.35z"/><path d="M12.5 10.5 13.2 12l1.5.7-1.5.7-.7 1.5-.7-1.5-1.5-.7 1.5-.7z"/></svg>';
      const DIAG_SVG = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 8.5h2.5l1.75-4.5 2.5 8 1.75-3.5H14"/></svg>';
      const GEAR_SVG = '<svg width="15" height="15" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><circle cx="8" cy="8" r="2.25"/><path d="M8 2.25v1.3M8 12.45v1.3M2.25 8h1.3M12.45 8h1.3M3.93 3.93l.92.92M11.15 11.15l.92.92M12.07 3.93l-.92.92M4.85 11.15l-.92.92"/></svg>';
      const clientAlertDot = d.cnToolkit?.updateCovered
        ? '<span class="btn-dot-update warn"></span>'
        : d.update?.available
        ? '<span class="btn-dot-update"></span>'
        : '';

      wrap.innerHTML = `
        <div class="pop" id="kd-pop">
          <div class="hdr">
            <div class="hdr-row">
              <div class="hdr-left">
                <span class="dot ${statusCls}"></span>
                <h2 class="title">KupaDesk</h2>
                <span class="pill-badge ${statusCls}">${esc(statusLabel)}</span>
              </div>
              <div class="hdr-tools">
                <button type="button" class="icon-btn" data-act="nav-client" title="客户端增强与云更新">${SPARK_SVG}${clientAlertDot}</button>
                <button type="button" class="icon-btn" data-act="nav-diag" title="诊断与安全预览">${DIAG_SVG}</button>
                <button type="button" class="icon-btn" data-act="nav-settings" title="卡密授权、默认筛选与预设">${GEAR_SVG}</button>
                <label class="sw" title="当前对话注入总开关">
                  <input type="checkbox" id="pop-master-sw" ${cfg.enabled ? 'checked' : ''}>
                  <span class="sw-track"></span>
                </label>
              </div>
            </div>
            <div class="meta-row">
              <span class="meta-title" title="${esc(fullTitle)}">${esc(fullTitle)}</span>
              <span class="meta-sep">·</span>
              <span class="meta-size">${esc(rightMeta)}</span>
            </div>
          </div>
          <div class="body">${bodyHtml}</div>
        </div>`;

      positionPopover();
      renderCloudDropdown();
      requestAnimationFrame(() => {
        if (popoverOpen) {
          positionPopover();
          if (cloudDropdownOpen) positionCloudDropdown();
        }
      });
    }

    function buildCloudDropdownView(d) {
      const cfg = d?.conversation || {};
      const g = d?.global || {};
      const cloud = d?.cloud || {};
      const allPrompts = cloud.prompts || [];
      const selectedCloud = cfg.selectedCloudIds || [];
      const defCloudSet = new Set(g.defaults?.defaultCloudIds || []);
      const filterOn = Boolean(g.cloud?.filterEnabled);
      const visibleSet = new Set(g.cloud?.visibleCloudIds || []);
      const pool =
        !filterOn || cloudDropdownShowAll
          ? allPrompts
          : allPrompts.filter((p) => visibleSet.has(p.id) || selectedCloud.includes(p.id));
      const q = mainCloudQuery.trim().toLowerCase();
      const matched = q
        ? pool.filter((p) => String(p.title || '').toLowerCase().includes(q) || String(p.id).toLowerCase().includes(q))
        : pool;

      const listHtml = matched.length
        ? matched
            .map((p) => {
              const idx = selectedCloud.indexOf(p.id);
              const on = idx >= 0;
              const isDef = defCloudSet.has(p.id);
              return `
                <div class="combo-item${on ? ' on' : ''}" data-act="toggle-cloud" data-id="${esc(p.id)}">
                  <div class="combo-item-left">
                    <span class="chk">${on ? idx + 1 : ''}</span>
                    <span class="combo-name">${esc(p.title)}</span>
                  </div>
                  <button type="button" class="star-btn${isDef ? ' on' : ''}" data-act="star-cloud" data-id="${esc(p.id)}" title="${isDef ? '取消新对话默认' : '设为新对话默认'}">★</button>
                </div>`;
            })
            .join('')
        : '<div class="hint" style="padding:8px;text-align:center;">未找到匹配项</div>';

      return {
        filterOn,
        allCount: allPrompts.length,
        matchedCount: matched.length,
        hasSelected: selectedCloud.length > 0,
        countText: `匹配 ${matched.length} / ${allPrompts.length}`,
        listHtml,
      };
    }

    function positionCloudDropdown() {
      if (!portalRoot) return;
      const menu = portalRoot.getElementById('kd-cloud-menu');
      const trigger = portalRoot.getElementById('kd-cloud-trigger');
      const listEl = portalRoot.getElementById('kd-cloud-menu-list');
      if (!menu || !trigger) return;

      const btnRect = trigger.getBoundingClientRect();
      const vw = window.innerWidth;
      const vh = window.innerHeight;
      const menuW = Math.min(vw - 16, Math.max(260, Math.round(btnRect.width)));
      const left = Math.max(8, Math.min(Math.round(btnRect.left), vw - menuW - 8));
      menu.style.width = `${menuW}px`;
      menu.style.left = `${left}px`;

      if (listEl) listEl.style.maxHeight = '196px';
      const spaceBelow = vh - btnRect.bottom - 12;
      const spaceAbove = btnRect.top - 12;
      const openBelow = spaceBelow >= 210 || spaceBelow >= spaceAbove;
      const availH = Math.max(110, openBelow ? spaceBelow : spaceAbove);
      if (listEl) {
        const maxListH = Math.max(76, Math.min(196, availH - 76));
        listEl.style.maxHeight = `${maxListH}px`;
      }
      const menuH = menu.getBoundingClientRect().height || 180;
      let top = openBelow ? btnRect.bottom + 4 : btnRect.top - menuH - 4;
      top = Math.max(8, Math.min(top, vh - menuH - 8));
      menu.style.top = `${Math.round(top)}px`;
    }

    function updateCloudDropdownListOnly() {
      if (!portalRoot || !stateData) return;
      const view = buildCloudDropdownView(stateData);
      const countEl = portalRoot.getElementById('kd-cloud-menu-count');
      const listEl = portalRoot.getElementById('kd-cloud-menu-list');
      const clearBtn = portalRoot.getElementById('kd-cloud-menu-clear');
      const allBtn = portalRoot.getElementById('kd-cloud-menu-all');
      if (countEl) countEl.textContent = view.countText;
      if (listEl) listEl.innerHTML = view.listHtml;
      if (clearBtn) clearBtn.disabled = !view.hasSelected;
      if (allBtn) allBtn.textContent = cloudDropdownShowAll ? '仅常用' : '全部';
      positionCloudDropdown();
    }

    function syncTriggerCaret() {
      if (!portalRoot) return;
      const caret = portalRoot.getElementById('kd-cloud-trigger-caret');
      if (caret) caret.textContent = cloudDropdownOpen ? '收起 ▲' : '选择 ▾';
    }

    function renderCloudDropdown({ focusSearch = false } = {}) {
      ensurePortal();
      if (!portalRoot) return;
      const ddRoot = portalRoot.getElementById('kd-dropdown-root');
      if (!ddRoot) return;
      syncTriggerCaret();

      if (!(popoverOpen && cloudDropdownOpen && stateData?.cloud?.activated)) {
        ddRoot.innerHTML = '';
        return;
      }

      const view = buildCloudDropdownView(stateData);
      const existingMenu = portalRoot.getElementById('kd-cloud-menu');
      if (existingMenu) {
        updateCloudDropdownListOnly();
        if (focusSearch) {
          const inp = portalRoot.getElementById('pop-cloud-search');
          if (inp) inp.focus();
        }
        return;
      }

      ddRoot.innerHTML = `
        <div class="cloud-float-menu" id="kd-cloud-menu">
          <input type="search" id="pop-cloud-search" class="input" placeholder="搜索云核心…" value="${esc(mainCloudQuery)}">
          <div class="row-between">
            <span class="hint" id="kd-cloud-menu-count">${esc(view.countText)}</span>
            <div class="row">
              ${view.filterOn ? `<button type="button" class="ghost-btn" id="kd-cloud-menu-all" data-act="toggle-cloud-all">${cloudDropdownShowAll ? '仅常用' : '全部'}</button>` : ''}
              <button type="button" class="ghost-btn" id="kd-cloud-menu-clear" data-act="clear-clouds" ${view.hasSelected ? '' : 'disabled'}>清空</button>
            </div>
          </div>
          <div class="combo-list" id="kd-cloud-menu-list">${view.listHtml}</div>
        </div>`;

      positionCloudDropdown();
      if (focusSearch) {
        const inp = portalRoot.getElementById('pop-cloud-search');
        if (inp) {
          inp.focus();
          inp.setSelectionRange(mainCloudQuery.length, mainCloudQuery.length);
        }
      }
    }

    function renderMainBody(d, cfg, g, cloud, preview, activeChannel) {
      const stagingHtml = d.isStaging
        ? `<div class="staging-bar"><strong>新对话待命模式</strong>：发出第一句话时自动认领当前选中的核心与开关状态。</div>`
        : '';

      const allPrompts = cloud.prompts || [];
      const promptMap = new Map(allPrompts.map((p) => [p.id, p]));
      const selectedCloud = cfg.selectedCloudIds || [];

      let cloudSection = '';
      if (!cloud.activated) {
        cloudSection = `
          <div class="card">
            <div class="card-head">
              <h3 class="card-title">云核心</h3>
              <span class="pill-badge">未激活</span>
            </div>
            <p class="hint">激活 KupaDesk 卡密即可选用云核心，开启时自动同步至系统指令层。</p>
            <div><button type="button" class="primary-btn" data-act="goto-activate">去激活卡密</button></div>
          </div>`;
      } else {
        const leaseCls = cloud.lease?.ok ? 'ok' : cloud.error ? 'err' : 'warn';
        const leaseText = cloud.lease?.ok ? '租约有效' : cloud.error ? '授权异常' : '续期中';
        const tagsHtml = selectedCloud.length
          ? `<div class="tags">${selectedCloud
              .map((id, i) => {
                const title = promptMap.get(id)?.title || shortId(id);
                return `<span class="tag"><span>${i + 1}. ${esc(title)}</span><button type="button" class="tag-x" data-act="rm-cloud" data-id="${esc(id)}" title="移除">×</button></span>`;
              })
              .join('')}</div>`
          : '';

        const triggerLabel = !selectedCloud.length
          ? '选择云核心…'
          : selectedCloud.length === 1
          ? promptMap.get(selectedCloud[0])?.title || shortId(selectedCloud[0])
          : `已选 ${selectedCloud.length} 个核心`;

        cloudSection = `
          <div class="card">
            <div class="card-head">
              <div class="row"><h3 class="card-title">云核心</h3><span class="pill-badge ${leaseCls}">${leaseText}</span></div>
              <button type="button" class="ghost-btn" data-act="refresh-cloud">刷新</button>
            </div>
            ${cloud.error?.message ? `<div class="alert">${esc(cloud.error.message)}</div>` : ''}
            <button type="button" class="combo-btn" id="kd-cloud-trigger" data-act="toggle-cloud-dd">
              <span>${esc(triggerLabel)}</span>
              <span id="kd-cloud-trigger-caret" class="hint">${cloudDropdownOpen ? '收起 ▲' : '选择 ▾'}</span>
            </button>
            ${tagsHtml}
          </div>`;
      }

      let cnWarnHtml = '';
      if (d.cnToolkit?.updateCovered) {
        cnWarnHtml = `
          <div class="guard-bar">
            <span class="guard-bar-text">检测到客户端更新覆盖了中文增强或红框入口</span>
            <button type="button" class="primary-btn" style="flex:none;height:22px;padding:0 8px;font-size:11px;" data-act="nav-client">去一键恢复</button>
          </div>`;
      }

      const presetCount = (cfg.selectedPresetIds || []).length;
      const hasCustom = cfg.customEnabled !== false && Boolean(String(cfg.customPrompt || '').trim());
      const parts = [];
      if (presetCount) parts.push(`${presetCount} 项本机预设`);
      if (hasCustom) parts.push('含补充指令');
      const modeHint = activeChannel === 'system-instruction'
        ? (preview?.status === 'active' ? `${preview.byteLength} / ${preview.ruleByteLimit} B` : '顶层 systemInstruction')
        : 'Hook 兼容模式';
      const summaryText = parts.length ? `${modeHint} · ${parts.join(' · ')}` : `${modeHint} · 右侧可配预设与指令`;

      const footerStrip = `
        <button type="button" class="diag-strip" data-act="nav-main-full" title="展开右侧 KupaDesk 完整面板">
          <span class="diag-strip-text">${esc(summaryText)}</span>
          <span class="diag-strip-action">完整面板 ›</span>
        </button>`;

      return `${stagingHtml}${cnWarnHtml}${cloudSection}${footerStrip}`;
    }

    async function loadState({ force = false, claimFocus = false } = {}) {
      if (pollInFlight && !force) return;
      pollInFlight = true;
      lastFetchAt = Date.now();
      try {
        const convId = activeConvId;
        const data = await bridgeCall('state', {
          conversationId: convId,
          etag: force ? '' : stateEtag,
          claimFocus: Boolean(claimFocus),
        });
        pluginDisabled = false;
        offlineState = false;
        if (!data.unchanged) {
          stateEtag = data.etag || '';
          stateData = data;
          renderAllBars();
          if (popoverOpen) renderPopover({ skipIfEditing: !force });
        }
      } catch (err) {
        if (err.disabled) {
          pluginDisabled = true;
          popoverOpen = false;
          renderAllBars();
          renderPopover();
        } else if (err.offline) {
          offlineState = true;
          renderAllBars();
          if (popoverOpen && !stateData) renderPopover();
        }
      } finally {
        pollInFlight = false;
      }
    }

    async function saveConfig(patch, toastMsg = '') {
      const targetConvId = activeConvId;
      const isStaging = stateData ? stateData.isStaging : !targetConvId;
      const action = isStaging ? 'staging' : 'conversation';
      const payload = { ...patch };
      if (!isStaging && targetConvId) payload.conversationId = targetConvId;
      try {
        const next = await bridgeCall(action, payload);
        stateEtag = next.etag || '';
        stateData = next;
        offlineState = false;
        renderAllBars();
        if (popoverOpen) renderPopover({ skipIfEditing: true });
        if (toastMsg) showToast(toastMsg);
      } catch (err) {
        showToast(err.message || '保存失败');
        await loadState({ force: true });
      }
    }

    function toggleMasterFromPill() {
      if (!stateData?.conversation) return;
      const nextEnabled = !stateData.conversation.enabled;
      // 乐观更新胶囊状态并同步后端
      stateData = {
        ...stateData,
        conversation: { ...stateData.conversation, enabled: nextEnabled },
        preview: stateData.preview
          ? {
              ...stateData.preview,
              status: nextEnabled ? (stateData.preview.hasContent ? 'active' : 'empty') : 'disabled',
            }
          : stateData.preview,
      };
      renderAllBars();
      void saveConfig(
        { enabled: nextEnabled },
        nextEnabled ? '已开启 KupaDesk 同步' : '已关闭并清除规则'
      );
    }

    function extractReactFiber(el) {
      if (!el) return null;
      for (const k of Object.keys(el)) {
        if (k.startsWith('__reactFiber$') || k.startsWith('__reactContainer$')) {
          return el[k];
        }
      }
      return null;
    }

    function openHostSidecarPanel(targetView = 'settings', focusTarget = '') {
      try {
        const notifyIframes = () => {
          const curFrames = Array.from(document.querySelectorAll('iframe[data-testid="sidecar-iframe"]'));
          for (const frame of curFrames) {
            try {
              frame.contentWindow?.postMessage?.({ type: 'kupadesk:switch-view', view: targetView, focusTarget }, '*');
              frame.contentWindow?.dispatchEvent?.(new Event('focus'));
            } catch (_e) {}
          }
          return curFrames;
        };

        // 1. 若右侧已经打开了 KupaDesk 的 iframe，直接发 postMessage 切换视图并唤醒其 focus
        const iframes = notifyIframes();

        // 2. 从当前对话 DOM 节点向上遍历 React Fiber 祖先链，提取宿主原生 Context 与 Redux Store
        const startNodes = [
          activeBox,
          document.querySelector('[data-testid="conversation-view"]'),
          document.querySelector('[data-testid="agent-input-box"]'),
          document.getElementById('root'),
          document.body?.firstElementChild,
        ].filter(Boolean);

        let store = null;
        let featureMap = null;
        let iframeCtx = null;
        let router = null;
        let sidecarLinkClick = null;

        const inspectProps = (props) => {
          if (!props || typeof props !== 'object') return;
          if (typeof props.onSidecarLinkClick === 'function' && !sidecarLinkClick) {
            sidecarLinkClick = props.onSidecarLinkClick;
          }
          const val = props.value;
          if (!val || typeof val !== 'object') return;
          if (!store) {
            if (val.store && typeof val.store.dispatch === 'function' && typeof val.store.getState === 'function') {
              store = val.store;
            } else if (typeof val.dispatch === 'function' && typeof val.getState === 'function') {
              store = val;
            }
          }
          if (
            !featureMap &&
            typeof val.get === 'function' &&
            (typeof val.getBaseline === 'function' || val instanceof Map)
          ) {
            try {
              if (val.get('extensibility')) featureMap = val;
            } catch (_e) {}
          }
          if (!iframeCtx && typeof val.setIframeSrc === 'function' && typeof val.navigateIframe === 'function') {
            iframeCtx = val;
          }
          if (!router && val.state?.location && typeof val.navigate === 'function') {
            router = val;
          }
        };

        const inspectFiber = (f) => {
          if (!f) return;
          if (f.memoizedProps) inspectProps(f.memoizedProps);
          if (f.pendingProps && f.pendingProps !== f.memoizedProps) inspectProps(f.pendingProps);
        };

        for (const node of startNodes) {
          let cur = extractReactFiber(node);
          let guard = 0;
          while (cur && guard++ < 160) {
            inspectFiber(cur);
            cur = cur.return;
          }
          if (store && featureMap && iframeCtx && router) break;
        }

        // 若祖先链未完全命中，从根容器做一次轻量 BFS
        if (!store || !featureMap || !iframeCtx || !router) {
          const rootFiber = extractReactFiber(document.getElementById('root') || document.body?.firstElementChild);
          if (rootFiber) {
            const queue = [rootFiber];
            let visited = 0;
            while (queue.length && visited++ < 3500) {
              const cur = queue.shift();
              inspectFiber(cur);
              if (store && featureMap && iframeCtx && router) break;
              if (cur.child) queue.push(cur.child);
              if (cur.sibling) queue.push(cur.sibling);
            }
          }
        }

        if (store && featureMap) {
          const ext = featureMap.get('extensibility');
          const redesignEnabled = featureMap.get('auxPaneComponent')?.redesignEnabled === true;
          const rawList =
            (typeof ext?.provider?.getState === 'function' ? ext.provider.getState() : null) ||
            ext?.provider?.value ||
            ext?.provider?.current ||
            [];
          const sidecars = Array.isArray(rawList) ? rawList : [];
          const hit =
            sidecars.find((d) => d?.sidecarId === 'kupadesk/prompt_panel') ||
            sidecars.find((d) => String(d?.sidecarId || '').endsWith('/prompt_panel'));

          if (hit && hit.baseUrl) {
            const views = hit.config?.uiConfig?.views || [{ path: '/', title: 'KupaDesk' }];
            const v = views[0] || { path: '/', title: 'KupaDesk' };
            const viewPath = v.path || '/';
            const resolvedUrl =
              typeof ext?.resolveSidecarUrl === 'function'
                ? ext.resolveSidecarUrl(hit.baseUrl, viewPath)
                : hit.baseUrl;
            const title = v.title || hit.config?.uiConfig?.displayName || 'KupaDesk';
            const tabId = `sidecar__${hit.sidecarId}__${viewPath}`;
            const content = {
              type: 'sidecarView',
              sidecarView: {
                sidecarId: hit.sidecarId,
                path: viewPath,
                url: resolvedUrl,
                title,
              },
            };

            if (iframeCtx && resolvedUrl && iframes.length === 0) {
              try {
                const baseU = new URL(resolvedUrl);
                if (activeConvId) baseU.searchParams.set('conversationId', activeConvId);
                if (targetView && targetView !== 'main') baseU.searchParams.set('view', targetView);
                const baseHref = baseU.toString();
                iframeCtx.setIframeSrc(baseHref, baseHref);
              } catch (_e) {}
            }

            const scopes = [];
            if (activeConvId) {
              scopes.push({ kind: 'cascadeId', cascadeId: activeConvId });
            } else {
              const searchParams = new URLSearchParams(location.search);
              const proj = router?.state?.location?.search?.project || searchParams.get('project');
              if (proj) scopes.push({ kind: 'newConversation', projectId: proj });
              scopes.push({ kind: 'home' });
            }

            for (const panelScope of scopes) {
              if (redesignEnabled) {
                store.dispatch({ type: 'sidePanelV2/setContent', payload: { panelScope, content, tabId } });
              } else {
                store.dispatch({ type: 'sidePanel/setContent', payload: { panelScope, content, tabId } });
              }
              store.dispatch({ type: 'sidePanel/setSidePanelOpen', payload: { panelScope, isOpen: true } });
            }

            if (router && typeof router.navigate === 'function') {
              try {
                router.navigate({
                  search: (prev) => ({ ...(prev || {}), tab: tabId }),
                  replace: true,
                });
              } catch (_e) {}
            }

            notifyIframes();
            setTimeout(() => void notifyIframes(), 200);
            setTimeout(() => void notifyIframes(), 650);
            return true;
          }
        }

        if (sidecarLinkClick) {
          sidecarLinkClick('kupadesk/prompt_panel/');
          notifyIframes();
          setTimeout(() => void notifyIframes(), 200);
          setTimeout(() => void notifyIframes(), 650);
          return true;
        }
      } catch (_err) {}

      // 3. DOM 兜底：若页面上存在扩展菜单项则直接点击
      const directItem = document.querySelector('[data-testid="plugins-submenu-item"][data-sidecar-id*="prompt_panel"]');
      if (directItem) {
        directItem.click();
        setTimeout(() => {
          for (const frame of document.querySelectorAll('iframe[data-testid="sidecar-iframe"]')) {
            try {
              frame.contentWindow?.postMessage?.({ type: 'kupadesk:switch-view', view: targetView, focusTarget }, '*');
              frame.contentWindow?.dispatchEvent?.(new Event('focus'));
            } catch (_e) {}
          }
        }, 250);
        return true;
      }
      return false;
    }

    async function openFullSidePanel(targetView = 'settings', focusTarget = '') {
      cloudDropdownOpen = false;
      popoverOpen = false;
      renderAllBars();
      renderPopover();
      try {
        await bridgeCall('defaults', {
          conversationId: activeConvId,
          requestedView: targetView,
          requestedFocus: focusTarget,
        });
      } catch (_e) {}
      const opened = openHostSidecarPanel(targetView, focusTarget);
      if (!opened) {
        showToast('请在对话右上角 + 菜单中打开 KupaDesk 面板');
      }
    }

    function bindBarEvents(inst) {
      inst.barRoot.addEventListener('click', (e) => {
        if (e.target.closest('#kd-pill-sw') || e.target.closest('.toggle-wrap')) {
          e.preventDefault();
          e.stopPropagation();
          toggleMasterFromPill();
          return;
        }
        if (e.target.closest('#kd-pill-btn')) {
          e.preventDefault();
          e.stopPropagation();
          if (popoverOpen && activeBox === inst.box) {
            popoverOpen = false;
          } else {
            activeBox = inst.box;
            activeConvId = inst.convId;
            popoverOpen = true;
            void loadState({ force: true, claimFocus: true });
          }
          renderAllBars();
          renderPopover();
        }
      });
    }

    function bindPortalEvents(wrap) {
      wrap.addEventListener('click', async (e) => {
        e.stopPropagation();
        const rawTarget = e.target;
        const inMenu = Boolean(rawTarget && typeof rawTarget.closest === 'function' && rawTarget.closest('#kd-cloud-menu'));
        const onTrigger = Boolean(rawTarget && typeof rawTarget.closest === 'function' && rawTarget.closest('#kd-cloud-trigger'));

        if (cloudDropdownOpen && !inMenu && !onTrigger) {
          cloudDropdownOpen = false;
          renderCloudDropdown();
        }

        const actEl = rawTarget && typeof rawTarget.closest === 'function' ? rawTarget.closest('[data-act]') : null;
        if (!actEl) return;
        const act = actEl.dataset.act;
        const id = actEl.dataset.id || '';

        if (act === 'close-pop') {
          popoverOpen = false;
          renderAllBars();
          renderPopover();
          return;
        }
        if (act === 'nav-main-full') {
          await openFullSidePanel('main', '');
          return;
        }
        if (act === 'nav-client') {
          await openFullSidePanel('client', '');
          return;
        }
        if (act === 'nav-settings' || act === 'goto-activate') {
          await openFullSidePanel('settings', act === 'goto-activate' ? 'activate' : '');
          return;
        }
        if (act === 'nav-diag') {
          await openFullSidePanel('diag', '');
          return;
        }
        if (act === 'toggle-cloud-dd') {
          cloudDropdownOpen = !cloudDropdownOpen;
          renderCloudDropdown({ focusSearch: cloudDropdownOpen });
          return;
        }
        if (act === 'toggle-cloud-all') {
          cloudDropdownShowAll = !cloudDropdownShowAll;
          updateCloudDropdownListOnly();
          return;
        }
        if (act === 'clear-clouds') {
          await saveConfig({ selectedCloudIds: [] }, '已清空已选云核心');
          return;
        }
        if (act === 'rm-cloud') {
          const next = (stateData?.conversation?.selectedCloudIds || []).filter((x) => x !== id);
          await saveConfig({ selectedCloudIds: next });
          return;
        }
        if (act === 'toggle-cloud') {
          const cur = stateData?.conversation?.selectedCloudIds || [];
          const next = cur.includes(id) ? cur.filter((x) => x !== id) : [...cur, id];
          await saveConfig({ selectedCloudIds: next });
          return;
        }
        if (act === 'star-cloud') {
          const curDefs = stateData?.global?.defaults?.defaultCloudIds || [];
          const adding = !curDefs.includes(id);
          const nextDefs = adding ? [...curDefs, id] : curDefs.filter((x) => x !== id);
          try {
            const res = await bridgeCall('cloud.preferences', {
              conversationId: activeConvId,
              defaultCloudIds: nextDefs,
              ...(adding && stateData?.global?.cloud?.filterEnabled
                ? { visibleCloudIds: [...new Set([...(stateData.global.cloud.visibleCloudIds || []), id])] }
                : {}),
            });
            stateEtag = res.etag || '';
            stateData = res;
            renderPopover({ skipIfEditing: true });
            showToast(adding ? '已设为新对话默认' : '已取消默认');
          } catch (err) {
            showToast(err.message);
          }
          return;
        }
        if (act === 'refresh-cloud') {
          try {
            const res = await bridgeCall('cloud.refresh', { conversationId: activeConvId });
            stateEtag = res.etag || '';
            stateData = res;
            renderAllBars();
            renderPopover({ skipIfEditing: true });
            showToast('云核心目录已刷新');
          } catch (err) {
            showToast(err.message);
          }
        }
      });

      wrap.addEventListener('change', async (e) => {
        const t = e.target;
        if (!t) return;
        if (t.id === 'pop-master-sw') {
          await saveConfig({ enabled: t.checked }, t.checked ? '已开启 KupaDesk 同步' : '已关闭并清除规则');
        }
      });

      wrap.addEventListener('input', (e) => {
        const t = e.target;
        if (t && t.id === 'pop-cloud-search') {
          mainCloudQuery = t.value;
          updateCloudDropdownListOnly();
        }
      });
    }

    const INLINE_BAR_STYLE =
      'display:flex;justify-content:flex-end;align-items:center;width:100%;align-self:stretch;flex-shrink:0;margin:0 0 6px 0;padding:0;box-sizing:border-box;pointer-events:none;position:relative;top:auto;left:auto;z-index:auto;';

    function mountBarHost(box, barHost) {
      let anchor = box;
      let parent = box.parentElement;
      for (let i = 0; i < 2 && parent && !isVerticalContainer(parent); i++) {
        anchor = parent;
        parent = parent.parentElement;
      }
      if (parent && isVerticalContainer(parent)) {
        barHost.style.cssText = INLINE_BAR_STYLE;
        parent.insertBefore(barHost, anchor);
        return { fixedMode: false, anchor };
      }
      barHost.style.cssText = INLINE_BAR_STYLE;
      (document.body || document.documentElement).appendChild(barHost);
      return { fixedMode: true, anchor: box };
    }

    function switchToFixedFallback(inst) {
      inst.fixedMode = true;
      const body = document.body || document.documentElement;
      if (inst.barHost.parentElement !== body) {
        body.appendChild(inst.barHost);
      }
    }

    function alignBarHostToBox(inst) {
      const { box, barHost, barRoot } = inst;
      if (!box.isConnected || !barHost.isConnected) return;
      const boxRect = box.getBoundingClientRect();
      const wrap = barRoot.getElementById('kd-bar-wrap');

      if (!inst.fixedMode) {
        barHost.style.width = '100%';
        barHost.style.alignSelf = 'stretch';
        barHost.style.flexShrink = '0';
        barHost.style.margin = '0 0 6px 0';
        if (wrap) wrap.style.marginRight = '0px';
        const barRect = barHost.getBoundingClientRect();
        if (barRect.height < 16 || barRect.bottom > boxRect.top + 6) {
          switchToFixedFallback(inst);
        } else if (wrap) {
          const rightInset = Math.max(0, Math.round(barRect.right - boxRect.right));
          wrap.style.marginRight = `${rightInset}px`;
          return;
        } else {
          return;
        }
      }

      if (wrap) wrap.style.marginRight = '0px';
      const barH = Math.max(24, Math.round(barHost.getBoundingClientRect().height || 24));
      barHost.style.position = 'fixed';
      barHost.style.margin = '0';
      barHost.style.top = `${Math.max(4, Math.round(boxRect.top - barH - 6))}px`;
      barHost.style.left = `${Math.max(8, Math.round(boxRect.left))}px`;
      barHost.style.width = `${Math.round(boxRect.width)}px`;
      barHost.style.zIndex = '2147482000';
    }

    function syncComposers() {
      detectTheme();
      const boxes = findPrimaryComposers();
      const boxSet = new Set(boxes);

      for (const [box, inst] of instances.entries()) {
        if (!boxSet.has(box)) {
          inst.barHost.remove();
          instances.delete(box);
          if (activeBox === box) {
            activeBox = null;
            popoverOpen = false;
            renderPopover();
          }
        }
      }

      let focusConvChanged = false;
      for (const box of boxes) {
        let inst = instances.get(box);
        const nextConvId = resolveConversationId(box);
        if (!inst) {
          const barHost = document.createElement('div');
          barHost.setAttribute(BAR_HOST_ATTR, '1');
          barHost.dataset.theme = currentTheme;
          barHost.style.cssText = INLINE_BAR_STYLE;
          const barRoot = barHost.attachShadow({ mode: 'open' });
          const st = document.createElement('style');
          st.textContent = BAR_CSS;
          const wrap = document.createElement('div');
          wrap.id = 'kd-bar-wrap';
          barRoot.appendChild(st);
          barRoot.appendChild(wrap);

          const mounted = mountBarHost(box, barHost);
          inst = { box, barHost, barRoot, convId: nextConvId, fixedMode: mounted.fixedMode, anchor: mounted.anchor };
          instances.set(box, inst);
          bindBarEvents(inst);
          renderBar(inst);
        } else {
          if (!inst.barHost.isConnected) {
            const mounted = mountBarHost(box, inst.barHost);
            inst.fixedMode = mounted.fixedMode;
            inst.anchor = mounted.anchor;
          } else if (
            !inst.fixedMode &&
            inst.anchor &&
            inst.anchor.parentElement === inst.barHost.parentElement &&
            inst.barHost.nextElementSibling !== inst.anchor
          ) {
            inst.anchor.parentElement.insertBefore(inst.barHost, inst.anchor);
          }
          if (inst.convId !== nextConvId) {
            inst.convId = nextConvId;
          }
        }
        alignBarHostToBox(inst);
      }

      if (boxes.length > 0) {
        const targetBox = activeBox && boxSet.has(activeBox) ? activeBox : boxes[0];
        const targetInst = instances.get(targetBox);
        if (targetBox !== activeBox || (targetInst && targetInst.convId !== activeConvId)) {
          activeBox = targetBox;
          activeConvId = targetInst ? targetInst.convId : '';
          stateEtag = '';
          focusConvChanged = true;
        }
      }

      if (focusConvChanged || (!stateData && boxes.length > 0)) {
        void loadState({ force: true });
      }
      if (popoverOpen) positionPopover();
    }

    function scheduleSync() {
      if (syncScheduled) return;
      syncScheduled = true;
      requestAnimationFrame(() => {
        syncScheduled = false;
        syncComposers();
      });
    }

    function isOwnNode(target) {
      if (!target) return false;
      if (portalHost && (target === portalHost || portalHost.contains(target))) return true;
      for (const inst of instances.values()) {
        if (target === inst.barHost || inst.barHost.contains(target)) return true;
      }
      return false;
    }

    const domObserver = new MutationObserver((records) => {
      if (records.some((r) => !isOwnNode(r.target))) {
        scheduleSync();
      }
    });
    domObserver.observe(document.documentElement, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ['class', 'style', 'hidden', 'data-cascade-id', 'data-testid'],
    });

    function isInsideInteractiveUi(e) {
      const path = typeof e.composedPath === 'function' ? e.composedPath() : [e.target];
      for (const n of path) {
        if (!n || n === window || n === document) continue;
        if (n.id === 'kd-pop' || n.id === 'kd-cloud-menu') return true;
        if (n.classList && n.classList.contains('pill')) return true;
      }
      return false;
    }

    function handleOutsideDismiss(e) {
      if (!popoverOpen) return;
      if (isInsideInteractiveUi(e)) return;
      cloudDropdownOpen = false;
      popoverOpen = false;
      renderAllBars();
      renderPopover();
    }

    window.addEventListener('pointerdown', handleOutsideDismiss, true);
    window.addEventListener('mousedown', handleOutsideDismiss, true);
    window.addEventListener('blur', () => {
      if (!popoverOpen) return;
      cloudDropdownOpen = false;
      popoverOpen = false;
      renderAllBars();
      renderPopover();
    });

    document.addEventListener('keydown', (e) => {
      if (e.key === 'Escape' && popoverOpen) {
        if (cloudDropdownOpen) {
          cloudDropdownOpen = false;
          renderCloudDropdown();
          return;
        }
        popoverOpen = false;
        renderAllBars();
        renderPopover();
      }
    });

    document.addEventListener('focusin', (e) => {
      const box = e.target && typeof e.target.closest === 'function' ? e.target.closest('[data-testid="agent-input-box"]') : null;
      if (box && instances.has(box)) {
        const inst = instances.get(box);
        const boxChanged = box !== activeBox;
        const convChanged = Boolean(inst && inst.convId !== activeConvId);
        const needsTakeover = Boolean(stateData?.focusGuard?.protected && !stateData.focusGuard.ownerRunning);
        if (boxChanged) activeBox = box;
        if (convChanged || boxChanged) {
          activeConvId = inst ? inst.convId : '';
          stateEtag = '';
          void loadState({ force: true, claimFocus: true });
        } else if (needsTakeover) {
          void loadState({ force: true, claimFocus: true });
        }
      }
    });

    window.addEventListener('resize', () => {
      for (const inst of instances.values()) {
        alignBarHostToBox(inst);
      }
      if (popoverOpen) {
        positionPopover();
        if (cloudDropdownOpen) positionCloudDropdown();
      }
    });

    window.addEventListener(
      'scroll',
      () => {
        for (const inst of instances.values()) {
          if (inst.fixedMode) alignBarHostToBox(inst);
        }
        if (popoverOpen) {
          positionPopover();
          if (cloudDropdownOpen) positionCloudDropdown();
        }
      },
      true
    );

    setInterval(() => {
      syncComposers();
      const now = Date.now();
      const interval = document.hidden ? 10000 : 2500;
      if (now - lastFetchAt >= interval && instances.size > 0) {
        void loadState({ force: false });
      }
    }, 1000);

    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', syncComposers, { once: true });
    } else {
      syncComposers();
    }
  } catch (_err) {}
})();

'use strict';

const fs = require('fs');
const http = require('http');
const os = require('os');
const path = require('path');

const LOCAL_ORIGIN_RE = /^https?:\/\/(?:127\.0\.0\.1|localhost|\[::1\])(?::\d+)?(?:\/|$)/i;
const ALLOWED_BRIDGE_ACTIONS = new Set([
  'state',
  'rule.syncNow',
  'panel.openView',
  'conversation',
  'staging',
  'conversation.clearHistory',
  'presets.upsert',
  'presets.delete',
  'defaults',
  'cloud.activate',
  'cloud.refresh',
  'cloud.origin',
  'cloud.preferences',
  'cloud.deactivate',
  'update.check',
  'update.install',
  'cn.status',
  'cn.settings',
  'cn.action',
]);

function getDataDir() {
  const override = process.env.PROMPT_INJECTOR_DATA_DIR;
  if (override && String(override).trim()) {
    return path.resolve(String(override).trim());
  }
  return path.join(os.homedir(), '.gemini', 'config', 'plugin-data', 'prompt-injector');
}

function isPluginDisabled() {
  try {
    const configPath = path.join(os.homedir(), '.gemini', 'config', 'config.json');
    if (!fs.existsSync(configPath)) return false;
    const cfg = JSON.parse(fs.readFileSync(configPath, 'utf8'));
    const plugins = cfg && typeof cfg === 'object' ? cfg.plugins : null;
    if (!plugins || typeof plugins !== 'object') return false;
    if (plugins['prompt-injector'] && plugins['prompt-injector'].enabled === false) return true;
    if (plugins.kupadesk && plugins.kupadesk.enabled === false) return true;
    return false;
  } catch (_e) {
    return false;
  }
}

function readBridgeInfo() {
  try {
    const bridgePath = path.join(getDataDir(), 'runtime-bridge.json');
    if (!fs.existsSync(bridgePath)) return null;
    const data = JSON.parse(fs.readFileSync(bridgePath, 'utf8'));
    if (!data || !Number.isInteger(data.port) || data.port <= 0 || typeof data.secret !== 'string' || !data.secret) {
      return null;
    }
    return data;
  } catch (_e) {
    return null;
  }
}

function callSidecarBridge(action, data) {
  const bridge = readBridgeInfo();
  if (!bridge) {
    return Promise.resolve({ ok: false, offline: true, error: 'KupaDesk 服务正在启动，请稍候…' });
  }
  const bodyStr = JSON.stringify({ action, data: data || {} });

  return new Promise((resolve) => {
    const req = http.request(
      {
        hostname: '127.0.0.1',
        port: bridge.port,
        path: '/bridge',
        method: 'POST',
        headers: {
          'Content-Type': 'application/json; charset=utf-8',
          'Content-Length': Buffer.byteLength(bodyStr, 'utf8'),
          'X-Hook-Secret': bridge.secret,
        },
        timeout: 8000,
      },
      (res) => {
        const chunks = [];
        res.on('data', (c) => chunks.push(c));
        res.on('end', () => {
          const raw = Buffer.concat(chunks).toString('utf8');
          try {
            const parsed = JSON.parse(raw || '{}');
            if (res.statusCode >= 200 && res.statusCode < 300 && parsed && typeof parsed === 'object') {
              resolve(parsed);
            } else {
              resolve({
                ok: false,
                error: parsed?.error || `HTTP ${res.statusCode}`,
                code: parsed?.code || 'bridge_error',
              });
            }
          } catch (_e) {
            resolve({ ok: false, error: '无效的服务端响应', code: 'invalid_json' });
          }
        });
      }
    );

    req.on('timeout', () => {
      req.destroy(new Error('timeout'));
    });

    req.on('error', () => {
      resolve({ ok: false, offline: true, error: 'KupaDesk 服务正在启动，请稍候…' });
    });

    req.write(bodyStr);
    req.end();
  });
}

function initKupaDeskDesktop({ electron, hubUtils } = {}) {
  if (typeof process === 'undefined' || process.type !== 'browser') return;
  if (!electron || !electron.app || !electron.ipcMain) return;
  if (global.__kupadeskDesktopHostInstalled) return;
  global.__kupadeskDesktopHostInstalled = true;

  const { app, ipcMain, BrowserWindow, webContents } = electron;
  const rendererPath = path.join(__dirname, 'renderer-widget.js');
  const installerPath = path.join(__dirname, 'install-desktop.cjs');

  ipcMain.handle('kupadesk:desktop', async (event, action, payload) => {
    const senderUrl =
      (event && event.senderFrame && event.senderFrame.url) ||
      (event && event.sender && typeof event.sender.getURL === 'function' ? event.sender.getURL() : '');
    if (!LOCAL_ORIGIN_RE.test(senderUrl)) {
      return { ok: false, error: 'forbidden' };
    }
    if (isPluginDisabled()) {
      return { ok: false, disabled: true, error: 'KupaDesk 插件已被禁用' };
    }

    const act = String(action || '').trim();
    if (act === 'desktop.status') {
      try {
        const installer = require(installerPath);
        return { ok: true, data: installer.inspectDesktopStatus() };
      } catch (err) {
        return { ok: false, error: err?.message || '读取客户端状态失败' };
      }
    }
    if (act === 'desktop.install' || act === 'desktop.uninstall') {
      try {
        const installer = require(installerPath);
        const op = act.split('.')[1];
        return { ok: true, data: installer.dispatchDesktopAction(op, payload || {}) };
      } catch (err) {
        return { ok: false, error: err?.message || '调度客户端操作失败' };
      }
    }
    if (!ALLOWED_BRIDGE_ACTIONS.has(act)) {
      return { ok: false, error: `未知操作: ${act}`, code: 'unknown_action' };
    }

    return callSidecarBridge(act, payload || {});
  });

  function isTargetHubWebContents(wc) {
    if (!wc || wc.isDestroyed()) return false;
    const wcType = typeof wc.getType === 'function' ? wc.getType() : '';
    if (
      wcType === 'webview' ||
      wcType === 'devtools' ||
      wcType === 'remote' ||
      wcType === 'offscreen' ||
      wcType === 'backgroundPage'
    ) {
      return false;
    }
    if (hubUtils && typeof hubUtils.getLocalHubWindows === 'function' && typeof hubUtils.getHubWebContents === 'function') {
      try {
        const hubWins = hubUtils.getLocalHubWindows();
        if (Array.isArray(hubWins) && hubWins.length > 0) {
          return hubWins.some((w) => hubUtils.getHubWebContents(w) === wc);
        }
      } catch (_e) {}
    }
    return true;
  }

  function injectIntoWebContents(wc) {
    if (!isTargetHubWebContents(wc)) return;
    if (isPluginDisabled()) return;
    const url = typeof wc.getURL === 'function' ? wc.getURL() : '';
    if (!LOCAL_ORIGIN_RE.test(url)) return;
    let source = '';
    try {
      if (!fs.existsSync(rendererPath)) return;
      source = fs.readFileSync(rendererPath, 'utf8');
    } catch (_e) {
      return;
    }
    if (!source) return;
    Promise.resolve(wc.executeJavaScript(source, false)).catch(() => {});
  }

  app.on('web-contents-created', (_event, wc) => {
    wc.on('dom-ready', () => injectIntoWebContents(wc));
    wc.on('did-finish-load', () => injectIntoWebContents(wc));
  });

  try {
    const list =
      typeof webContents?.getAllWebContents === 'function'
        ? webContents.getAllWebContents()
        : BrowserWindow.getAllWindows()
            .map((w) => !w.isDestroyed() && w.webContents)
            .filter(Boolean);
    for (const wc of list) {
      injectIntoWebContents(wc);
    }
  } catch (_e) {}
}

module.exports = {
  initKupaDeskDesktop,
};

'use strict';

process.noAsar = true;

const child_process = require('child_process');
const fs = require('fs');
const os = require('os');
const path = require('path');
const vm = require('vm');

const MAIN_START = "'__KUPADESK_DESKTOP_LOADER_START__';";
const MAIN_END = "'__KUPADESK_DESKTOP_LOADER_END__';";
const PRELOAD_START = "'__KUPADESK_DESKTOP_BRIDGE_START__';";
const PRELOAD_END = "'__KUPADESK_DESKTOP_BRIDGE_END__';";

const CN_MARKER = '__ANTIGRAVITY_CHINESE_LOCALIZATION_START__';
const CTX_MARKER = '__AG_CTX_BRIDGE_START__';
const REVEAL_MARKER = '__AG_FILE_REVEAL_PLUGIN_START__';

function getDataDir(overrideDir) {
  if (overrideDir && String(overrideDir).trim()) {
    return path.resolve(String(overrideDir).trim());
  }
  const envDir = process.env.PROMPT_INJECTOR_DATA_DIR;
  if (envDir && String(envDir).trim()) {
    return path.resolve(String(envDir).trim());
  }
  return path.join(os.homedir(), '.gemini', 'config', 'plugin-data', 'prompt-injector');
}

class AsarArchive {
  static align4(n) {
    return (n + 3) & ~3;
  }

  static readHeader(asarPath) {
    const fd = fs.openSync(asarPath, 'r');
    try {
      const sizeBuf = Buffer.alloc(8);
      fs.readSync(fd, sizeBuf, 0, 8, 0);
      const headerSize = sizeBuf.readUInt32LE(4);
      const headerBuf = Buffer.alloc(headerSize);
      fs.readSync(fd, headerBuf, 0, headerSize, 8);
      const jsonLen = headerBuf.readUInt32LE(4);
      const jsonStr = headerBuf.slice(8, 8 + jsonLen).toString('utf8');
      const header = JSON.parse(jsonStr);
      const baseOffset = 8 + headerSize;
      return { header, baseOffset };
    } finally {
      fs.closeSync(fd);
    }
  }

  static createHeaderBuffer(headerJson) {
    const jsonBuf = Buffer.from(headerJson, 'utf8');
    const jsonLen = jsonBuf.length;
    const alignedJsonLen = this.align4(jsonLen);
    const headerPayloadSize = 4 + alignedJsonLen;
    const headerBuf = Buffer.alloc(4 + headerPayloadSize);
    headerBuf.writeUInt32LE(headerPayloadSize, 0);
    headerBuf.writeUInt32LE(jsonLen, 4);
    jsonBuf.copy(headerBuf, 8);

    const sizeBuf = Buffer.alloc(8);
    sizeBuf.writeUInt32LE(4, 0);
    sizeBuf.writeUInt32LE(headerBuf.length, 4);
    return Buffer.concat([sizeBuf, headerBuf]);
  }

  static readFile(sourceAsar, relPath) {
    const { header, baseOffset } = this.readHeader(sourceAsar);
    const parts = relPath.replace(/\\/g, '/').split('/');
    let cur = header.files;
    for (const p of parts) {
      if (!cur || !cur[p]) return null;
      cur = cur[p].files ? cur[p].files : cur[p];
    }
    if (cur.unpacked) {
      const unpackedPath = path.join(`${sourceAsar}.unpacked`, ...parts);
      return fs.existsSync(unpackedPath) ? fs.readFileSync(unpackedPath) : null;
    }
    if (cur.offset === undefined || cur.size === undefined) return null;
    const fd = fs.openSync(sourceAsar, 'r');
    try {
      const buf = Buffer.alloc(Number(cur.size));
      fs.readSync(fd, buf, 0, buf.length, baseOffset + parseInt(cur.offset, 10));
      return buf;
    } finally {
      fs.closeSync(fd);
    }
  }

  static patchArchive(sourceAsar, targetAsar, filePatches) {
    const { header, baseOffset } = this.readHeader(sourceAsar);
    const srcFd = fs.openSync(sourceAsar, 'r');
    let destFd = null;
    try {
      const fileEntries = [];
      const walk = (dir, prefix) => {
        for (const [name, entry] of Object.entries(dir)) {
          const fullPath = prefix ? `${prefix}/${name}` : name;
          if (entry.files) walk(entry.files, fullPath);
          else fileEntries.push({ path: fullPath, entry });
        }
      };
      walk(header.files, '');

      const packedFiles = fileEntries.filter((f) => !f.entry.unpacked && f.entry.offset !== undefined);
      packedFiles.sort((a, b) => parseInt(a.entry.offset, 10) - parseInt(b.entry.offset, 10));

      for (const item of packedFiles) {
        item.oldOffset = parseInt(item.entry.offset, 10);
        item.oldSize = Number(item.entry.size);
        const patch = filePatches[item.path];
        if (patch !== undefined && patch !== null) {
          const patchBuf = Buffer.isBuffer(patch) ? patch : Buffer.from(patch, 'utf8');
          item.patchBuffer = patchBuf;
          item.entry.size = patchBuf.length;
        }
      }

      let currentOffset = BigInt(0);
      for (const item of packedFiles) {
        item.entry.offset = currentOffset.toString();
        currentOffset += BigInt(item.entry.size);
      }

      const newHeaderBuf = this.createHeaderBuffer(JSON.stringify(header));
      destFd = fs.openSync(targetAsar, 'w');
      fs.writeSync(destFd, newHeaderBuf, 0, newHeaderBuf.length, 0);

      let writePos = newHeaderBuf.length;
      const copyBufSize = 256 * 1024;
      const copyBuf = Buffer.alloc(copyBufSize);

      for (const item of packedFiles) {
        if (item.patchBuffer) {
          fs.writeSync(destFd, item.patchBuffer, 0, item.patchBuffer.length, writePos);
          writePos += item.patchBuffer.length;
        } else {
          let remaining = item.oldSize;
          let readPos = baseOffset + item.oldOffset;
          while (remaining > 0) {
            const toRead = Math.min(remaining, copyBufSize);
            fs.readSync(srcFd, copyBuf, 0, toRead, readPos);
            fs.writeSync(destFd, copyBuf, 0, toRead, writePos);
            readPos += toRead;
            writePos += toRead;
            remaining -= toRead;
          }
        }
      }
    } finally {
      if (srcFd) fs.closeSync(srcFd);
      if (destFd) fs.closeSync(destFd);
    }
  }
}

function removeMarkedBlocks(content, startMarker, endMarker) {
  let result = content;
  while (true) {
    const startIdx = result.indexOf(startMarker);
    if (startIdx === -1) break;
    const endIdx = result.indexOf(endMarker, startIdx + startMarker.length);
    if (endIdx === -1) break;
    const cutStart = startIdx > 0 && result[startIdx - 1] === '\n' ? startIdx - 1 : startIdx;
    let cutEnd = endIdx + endMarker.length;
    if (result[cutEnd] === '\r') cutEnd++;
    if (result[cutEnd] === '\n') cutEnd++;
    result = result.slice(0, cutStart) + result.slice(cutEnd);
  }
  return result;
}

function buildMainLoaderBlock() {
  return [
    MAIN_START,
    '(() => {',
    '  try {',
    "    if (typeof process === 'undefined' || process.type !== 'browser') return;",
    "    const pathMod = require('path');",
    "    const osMod = require('os');",
    "    const fsMod = require('fs');",
    "    const hostFile = pathMod.join(osMod.homedir(), '.gemini', 'config', 'plugins', 'prompt-injector', 'desktop', 'main-host.cjs');",
    '    if (!fsMod.existsSync(hostFile)) return;',
    '    const hostMod = require(hostFile);',
    "    if (hostMod && typeof hostMod.initKupaDeskDesktop === 'function') {",
    '      let hubUtils = null;',
    "      try { hubUtils = require('./utils'); } catch (_e) {}",
    "      hostMod.initKupaDeskDesktop({ electron: require('electron'), hubUtils });",
    '    }',
    '  } catch (_kdErr) {}',
    '})();',
    MAIN_END,
  ].join('\n');
}

function buildPreloadBridgeBlock(hasElectron1) {
  const electronExpr = hasElectron1 ? 'electron_1' : "require('electron')";
  return [
    PRELOAD_START,
    '(() => {',
    '  try {',
    `    const __kdEl = ${electronExpr};`,
    "    if (__kdEl && __kdEl.contextBridge && __kdEl.ipcRenderer) {",
    "      __kdEl.contextBridge.exposeInMainWorld('__kupadeskDesktopBridge', {",
    "        invoke: (action, payload) => __kdEl.ipcRenderer.invoke('kupadesk:desktop', action, payload),",
    '      });',
    '    }',
    '  } catch (_kdErr) {}',
    '})();',
    PRELOAD_END,
  ].join('\n');
}

function unpatchMainContent(raw) {
  return removeMarkedBlocks(String(raw || ''), MAIN_START, MAIN_END);
}

function patchMainContent(raw) {
  const clean = unpatchMainContent(raw);
  const trimmed = clean.endsWith('\n') ? clean : `${clean}\n`;
  const next = `${trimmed}${buildMainLoaderBlock()}\n`;
  new vm.Script(next, { filename: 'dist/main.js' });
  return next;
}

function unpatchPreloadContent(raw) {
  return removeMarkedBlocks(String(raw || ''), PRELOAD_START, PRELOAD_END);
}

function patchPreloadContent(raw) {
  const clean = unpatchPreloadContent(raw);
  const hasElectron1 = /\belectron_1\b/.test(clean);
  const trimmed = clean.endsWith('\n') ? clean : `${clean}\n`;
  const next = `${trimmed}${buildPreloadBridgeBlock(hasElectron1)}\n`;
  new vm.Script(next, { filename: 'dist/preload.js' });
  return next;
}

function detectInstallationDir(manualDir) {
  const hasAsar = (dir) =>
    fs.existsSync(path.join(dir, 'resources', 'app.asar')) ||
    fs.existsSync(path.join(dir, 'Contents', 'Resources', 'app.asar')) ||
    fs.existsSync(path.join(dir, 'app.asar'));

  if (manualDir) {
    const resolved = path.resolve(manualDir);
    if (fs.existsSync(resolved)) {
      if (fs.statSync(resolved).isFile() && resolved.endsWith('app.asar')) {
        return path.dirname(resolved);
      }
      return resolved;
    }
    throw new Error(`手动指定的目录不存在: ${manualDir}`);
  }

  const candidates = [];
  const addCandidate = (p) => {
    if (p) candidates.push(path.resolve(p));
  };
  addCandidate(process.env.ANTIGRAVITY_INSTALL_DIR);
  addCandidate(process.env.ANTIGRAVITY_HOME);

  if (process.platform === 'win32') {
    const localAppData = process.env.LOCALAPPDATA;
    if (localAppData) {
      addCandidate(path.join(localAppData, 'Programs', 'antigravity'));
      addCandidate(path.join(localAppData, 'antigravity'));
    }
    addCandidate('C:\\Program Files\\Antigravity');
    addCandidate('C:\\Program Files (x86)\\Antigravity');
    const roots = [
      'HKCU\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
      'HKLM\\Software\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
      'HKLM\\Software\\WOW6432Node\\Microsoft\\Windows\\CurrentVersion\\Uninstall',
    ];
    for (const root of roots) {
      try {
        const out = child_process.execSync(`reg query "${root}" /s /f Antigravity /d`, {
          encoding: 'utf8',
          stdio: ['ignore', 'pipe', 'ignore'],
        });
        for (const line of out.split(/\r?\n/)) {
          const m = line.match(/^\s*(InstallLocation|DisplayIcon)\s+REG_\w+\s+(.+)$/i);
          if (!m) continue;
          let val = m[2].trim().replace(/^"|"$/g, '');
          if (/Antigravity\.exe/i.test(val)) val = path.dirname(val);
          addCandidate(val);
        }
      } catch (_e) {}
    }
  } else if (process.platform === 'darwin') {
    addCandidate('/Applications/Antigravity.app');
    if (process.env.HOME) addCandidate(path.join(process.env.HOME, 'Applications', 'Antigravity.app'));
  } else {
    if (process.env.HOME) addCandidate(path.join(process.env.HOME, '.local', 'share', 'antigravity'));
    addCandidate('/opt/Antigravity');
    addCandidate('/usr/lib/antigravity');
  }

  for (const c of candidates) {
    if (fs.existsSync(c) && hasAsar(c)) return c;
  }
  throw new Error('未能自动检测到 Antigravity 安装目录，请使用 --install-dir 指定路径');
}

function resolveResourcesDir(installDir) {
  const tries = [path.join(installDir, 'resources'), path.join(installDir, 'Contents', 'Resources'), installDir];
  for (const dir of tries) {
    if (fs.existsSync(path.join(dir, 'app.asar'))) return dir;
  }
  throw new Error(`未能在 ${installDir} 下找到 resources/app.asar`);
}

function readAsarPackageVersion(asarPath) {
  try {
    const buf = AsarArchive.readFile(asarPath, 'package.json');
    if (!buf) return '';
    const pkg = JSON.parse(buf.toString('utf8'));
    return typeof pkg.version === 'string' ? pkg.version : '';
  } catch (_e) {
    return '';
  }
}

function canWriteTarget(resourcesDir, asarPath) {
  try {
    fs.accessSync(resourcesDir, fs.constants.W_OK | fs.constants.X_OK);
    if (fs.existsSync(asarPath)) {
      fs.accessSync(asarPath, fs.constants.R_OK | fs.constants.W_OK);
    }
    return true;
  } catch (_e) {
    return false;
  }
}

function isValidStandaloneNodeExe(candidatePath) {
  if (!candidatePath || typeof candidatePath !== 'string') return false;
  const trimmed = candidatePath.trim().replace(/^"|"$/g, '');
  if (!trimmed) return false;
  const lower = trimmed.toLowerCase();
  if (path.basename(lower) !== 'node.exe') return false;
  if (lower.includes('antigravity')) return false;
  try {
    return fs.existsSync(trimmed) && fs.statSync(trimmed).isFile();
  } catch (_e) {
    return false;
  }
}

function resolveRealNodeExecutable() {
  if (!process.versions?.electron && isValidStandaloneNodeExe(process.execPath)) {
    return process.execPath;
  }
  if (process.platform !== 'win32') {
    return process.versions?.electron ? '' : process.execPath;
  }

  try {
    const res = child_process.spawnSync('where.exe', ['node'], {
      encoding: 'utf8',
      windowsHide: true,
      timeout: 3000,
    });
    if (res.status === 0 && res.stdout) {
      for (const line of res.stdout.split(/\r?\n/)) {
        const candidate = line.trim();
        if (isValidStandaloneNodeExe(candidate)) return candidate;
      }
    }
  } catch (_e) {}

  const fixedCandidates = [
    process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Microsoft', 'WinGet', 'Links', 'node.exe') : '',
    'C:\\Program Files\\nodejs\\node.exe',
    'C:\\Program Files (x86)\\nodejs\\node.exe',
    process.env.LOCALAPPDATA ? path.join(process.env.LOCALAPPDATA, 'Programs', 'node', 'node.exe') : '',
    process.env.NVM_SYMLINK ? path.join(process.env.NVM_SYMLINK, 'node.exe') : '',
    process.env.USERPROFILE ? path.join(process.env.USERPROFILE, 'scoop', 'shims', 'node.exe') : '',
  ];
  for (const candidate of fixedCandidates) {
    if (isValidStandaloneNodeExe(candidate)) return candidate;
  }
  return '';
}

function sleepSync(ms) {
  Atomics.wait(new Int32Array(new SharedArrayBuffer(4)), 0, 0, ms);
}

function isFileUnlocked(filePath) {
  try {
    const fd = fs.openSync(filePath, 'r+');
    fs.closeSync(fd);
    return true;
  } catch (_e) {
    return false;
  }
}

function isAppRunning() {
  try {
    if (process.platform === 'win32') {
      const out = child_process.execSync('tasklist /fi "imagename eq Antigravity.exe" /nh', {
        encoding: 'utf8',
        stdio: ['ignore', 'pipe', 'ignore'],
      });
      return out.toLowerCase().includes('antigravity.exe');
    }
    const out = child_process.execSync('pgrep -fi antigravity', {
      encoding: 'utf8',
      stdio: ['ignore', 'pipe', 'ignore'],
    });
    return out.trim().length > 0;
  } catch (_e) {
    return false;
  }
}

function closeAppProcesses(asarPath, log = console.log) {
  log('[1/3] 检测到 Antigravity 正在运行，正在关闭以释放 app.asar 文件锁...');
  if (process.platform === 'win32') {
    try {
      child_process.execSync('taskkill /f /im Antigravity.exe /t >nul 2>nul', { stdio: 'ignore' });
    } catch (_e) {}
    const deadline = Date.now() + 12000;
    while (Date.now() < deadline) {
      if (!isAppRunning() && (!asarPath || isFileUnlocked(asarPath))) {
        return;
      }
      sleepSync(250);
    }
    return;
  }
  try {
    child_process.execSync('pkill -TERM -fi Antigravity', { stdio: 'ignore' });
    sleepSync(2000);
  } catch (_e) {}
}

function relaunchApp(installDir, log = console.log) {
  log('[3/3] 正在重新启动 Antigravity...');
  if (process.platform === 'win32') {
    const exePath = path.join(installDir, 'Antigravity.exe');
    if (fs.existsSync(exePath)) {
      child_process.spawn('cmd.exe', ['/c', 'start', '', exePath], {
        detached: true,
        stdio: 'ignore',
        windowsHide: true,
      }).unref();
      return true;
    }
  } else if (process.platform === 'darwin') {
    const appPath = installDir.endsWith('.app') ? installDir : path.resolve(installDir, '..', '..');
    child_process.spawn('open', [appPath], { detached: true, stdio: 'ignore' }).unref();
    return true;
  }
  return false;
}

function applyPatchToAsar(asarPath, mode) {
  const mainBuf = AsarArchive.readFile(asarPath, 'dist/main.js');
  const preloadBuf = AsarArchive.readFile(asarPath, 'dist/preload.js');
  if (!mainBuf || !preloadBuf) {
    throw new Error(`未能从 ${asarPath} 读取 dist/main.js 或 dist/preload.js`);
  }

  const rawMain = mainBuf.toString('utf8');
  const rawPreload = preloadBuf.toString('utf8');

  let nextMain;
  let nextPreload;
  if (mode === 'install') {
    nextMain = patchMainContent(rawMain);
    nextPreload = patchPreloadContent(rawPreload);
  } else if (mode === 'uninstall') {
    nextMain = unpatchMainContent(rawMain);
    nextPreload = unpatchPreloadContent(rawPreload);
    new vm.Script(nextMain, { filename: 'dist/main.js' });
    new vm.Script(nextPreload, { filename: 'dist/preload.js' });
  } else {
    throw new Error(`不支持的补丁模式: ${mode}`);
  }

  const tmpAsar = `${asarPath}.kupadesk.${process.pid}.${Date.now()}.tmp`;
  try {
    AsarArchive.patchArchive(asarPath, tmpAsar, {
      'dist/main.js': nextMain,
      'dist/preload.js': nextPreload,
    });

    const verifyMainBuf = AsarArchive.readFile(tmpAsar, 'dist/main.js');
    const verifyPreloadBuf = AsarArchive.readFile(tmpAsar, 'dist/preload.js');
    if (!verifyMainBuf || !verifyPreloadBuf) {
      throw new Error('生成临时 app.asar 后回读校验失败');
    }
    const verifyMain = verifyMainBuf.toString('utf8');
    const verifyPreload = verifyPreloadBuf.toString('utf8');
    new vm.Script(verifyMain, { filename: 'dist/main.js' });
    new vm.Script(verifyPreload, { filename: 'dist/preload.js' });

    if (mode === 'install') {
      if (!verifyMain.includes(MAIN_START) || !verifyMain.includes(MAIN_END)) {
        throw new Error('临时 app.asar 缺少 dist/main.js loader 标记');
      }
      if (!verifyPreload.includes(PRELOAD_START) || !verifyPreload.includes(PRELOAD_END)) {
        throw new Error('临时 app.asar 缺少 dist/preload.js bridge 标记');
      }
    } else {
      if (verifyMain.includes(MAIN_START) || verifyPreload.includes(PRELOAD_START)) {
        throw new Error('临时 app.asar 卸载后仍检测到 KupaDesk 标记');
      }
    }

    let replaced = false;
    for (let attempt = 0; attempt < 5; attempt++) {
      try {
        fs.renameSync(tmpAsar, asarPath);
        replaced = true;
        break;
      } catch (err) {
        if ((err?.code === 'EPERM' || err?.code === 'EACCES' || err?.code === 'EBUSY') && attempt < 4) {
          sleepSync(200 * (attempt + 1));
          continue;
        }
        throw err;
      }
    }
    if (!replaced) {
      throw new Error('无法替换目标 app.asar');
    }

    return {
      hadCn: rawPreload.includes(CN_MARKER),
      hadContextMonitor: rawPreload.includes(CTX_MARKER),
      hadFileReveal: rawPreload.includes(REVEAL_MARKER),
      keptCn: verifyPreload.includes(CN_MARKER),
      keptContextMonitor: verifyPreload.includes(CTX_MARKER),
      keptFileReveal: verifyPreload.includes(REVEAL_MARKER),
      hasMainLoader: verifyMain.includes(MAIN_START),
      hasPreloadBridge: verifyPreload.includes(PRELOAD_START),
    };
  } finally {
    try {
      if (fs.existsSync(tmpAsar)) fs.unlinkSync(tmpAsar);
    } catch (_e) {}
  }
}

function readRecentDesktopLog(maxLines = 60, overrideDir) {
  const logFile = path.join(getDataDir(overrideDir), 'last-desktop-action.log');
  try {
    if (!fs.existsSync(logFile)) return '';
    const raw = fs.readFileSync(logFile, 'utf8');
    const lines = raw.split(/\r?\n/);
    return (lines.length <= maxLines ? raw : lines.slice(-maxLines).join('\n')).trimEnd();
  } catch (_e) {
    return '';
  }
}

function inspectDesktopStatus(options = {}) {
  process.noAsar = true;
  const dataDir = getDataDir(options.dataDir);
  const nodeExecutable = resolveRealNodeExecutable();
  const log = options.skipLog ? '' : readRecentDesktopLog(60, dataDir);

  let installDir = '';
  let resourcesDir = '';
  let asarPath = '';
  let clientVersion = '';
  let writable = false;
  let detectError = '';
  let hasMainLoader = false;
  let hasPreloadBridge = false;
  let hasCnToolkit = false;
  let hasContextMonitor = false;
  let hasFileReveal = false;

  try {
    installDir = detectInstallationDir(options.manualDir || '');
    resourcesDir = resolveResourcesDir(installDir);
    asarPath = path.join(resourcesDir, 'app.asar');
    if (!fs.existsSync(asarPath)) {
      throw new Error(`未找到核心包文件: ${asarPath}`);
    }
    clientVersion = readAsarPackageVersion(asarPath);
    writable = canWriteTarget(resourcesDir, asarPath);

    const mainBuf = AsarArchive.readFile(asarPath, 'dist/main.js');
    const preloadBuf = AsarArchive.readFile(asarPath, 'dist/preload.js');
    if (!mainBuf || !preloadBuf) {
      throw new Error('无法从 app.asar 读取 dist/main.js 或 dist/preload.js');
    }
    const mainText = mainBuf.toString('utf8');
    const preloadText = preloadBuf.toString('utf8');
    hasMainLoader = mainText.includes(MAIN_START) && mainText.includes(MAIN_END);
    hasPreloadBridge = preloadText.includes(PRELOAD_START) && preloadText.includes(PRELOAD_END);
    hasCnToolkit = preloadText.includes(CN_MARKER);
    hasContextMonitor = preloadText.includes(CTX_MARKER);
    hasFileReveal = preloadText.includes(REVEAL_MARKER);
  } catch (err) {
    detectError = err && err.message ? err.message : String(err);
  }

  return {
    platform: process.platform,
    supportedAutoRestart: process.platform === 'win32',
    hasSystemNode: Boolean(nodeExecutable),
    nodeExecutable,
    installDir,
    resourcesDir,
    asarPath,
    writable,
    detectError,
    clientVersion,
    installed: Boolean(!detectError && hasMainLoader && hasPreloadBridge),
    hasMainLoader,
    hasPreloadBridge,
    hasCnToolkit,
    hasContextMonitor,
    hasFileReveal,
    dataDir,
    log,
  };
}

function spawnDetachedNodeScript(nodeExe, scriptPath, childArgs) {
  if (process.platform !== 'win32') {
    throw new Error('一键脱离进程树重启仅支持 Windows');
  }
  const quoteCmdArg = (arg) => `"${String(arg).replace(/"/g, '\\"')}"`;
  const allArgs = [scriptPath, ...childArgs];
  const commandLine = `${quoteCmdArg(nodeExe)} ${allArgs.map(quoteCmdArg).join(' ')}`;
  const psScript = [
    "$ProgressPreference = 'SilentlyContinue'",
    '$si = New-CimInstance -ClassName Win32_ProcessStartup -Namespace root\\cimv2 -Property @{ ShowWindow = [uint16]0 } -ClientOnly',
    `$cmd = @'\n${commandLine}\n'@`,
    '$res = Invoke-CimMethod -ClassName Win32_Process -MethodName Create -Arguments @{ CommandLine = $cmd; ProcessStartupInformation = $si }',
    'if ($res.ReturnValue -ne 0) { throw ("Win32_Process.Create failed with code " + $res.ReturnValue) }',
    'Write-Output $res.ProcessId',
  ].join('\n');
  const encoded = Buffer.from(psScript, 'utf16le').toString('base64');

  return child_process
    .execFileSync('powershell.exe', ['-NoProfile', '-NonInteractive', '-EncodedCommand', encoded], {
      encoding: 'utf8',
      windowsHide: true,
    })
    .trim();
}

function dispatchDesktopAction(action, options = {}) {
  const act = String(action || '').trim();
  if (act !== 'install' && act !== 'uninstall') {
    throw new Error(`不支持的操作类型: ${act || '(空)'}`);
  }
  if (process.platform !== 'win32') {
    throw new Error('一键脱离进程树自动重启仅支持 Windows，请手动在终端执行 install-desktop.cjs');
  }
  const nodeExe = resolveRealNodeExecutable();
  if (!nodeExe) {
    throw new Error('未检测到系统独立 Node.js (node.exe)，无法脱离客户端进程树执行重启安装');
  }

  const status = inspectDesktopStatus({
    dataDir: options.dataDir,
    manualDir: options.installDir,
    skipLog: true,
  });
  if (status.detectError) {
    throw new Error(status.detectError);
  }
  if (!status.writable) {
    throw new Error(`没有写入权限，无法修改: ${status.asarPath}`);
  }

  const dataDir = status.dataDir;
  const logFile = path.join(dataDir, 'last-desktop-action.log');
  const delayMs =
    Number.isFinite(Number(options.delayMs)) && Number(options.delayMs) > 0 ? Math.round(Number(options.delayMs)) : 2500;

  const childArgs = [`--${act}`, '--delay', String(delayMs), '--log', logFile, '--data-dir', dataDir];
  if (options.installDir) {
    childArgs.push('--install-dir', String(options.installDir));
  }

  const pid = spawnDetachedNodeScript(nodeExe, __filename, childArgs);
  return {
    ok: true,
    action: act,
    pid,
    delayMs,
    logFile,
    nodeExecutable: nodeExe,
    message: `已调度后台任务（PID: ${pid}），约 ${(delayMs / 1000).toFixed(1)} 秒后将自动关闭并重启 Antigravity。`,
  };
}

function runDryRun(manualDir) {
  const installDir = detectInstallationDir(manualDir);
  const resourcesDir = resolveResourcesDir(installDir);
  const realAsar = path.join(resourcesDir, 'app.asar');
  const ver = readAsarPackageVersion(realAsar);
  const tempDir = fs.mkdtempSync(path.join(os.tmpdir(), 'kupadesk-asar-dry-'));
  const copyAsar = path.join(tempDir, 'app.asar');

  try {
    fs.copyFileSync(realAsar, copyAsar);
    const installVerify = applyPatchToAsar(copyAsar, 'install');
    if (!installVerify.hasMainLoader || !installVerify.hasPreloadBridge) {
      throw new Error('Dry-Run 安装校验失败：未检测到 KupaDesk 标记');
    }
    if (
      (installVerify.hadCn && !installVerify.keptCn) ||
      (installVerify.hadContextMonitor && !installVerify.keptContextMonitor) ||
      (installVerify.hadFileReveal && !installVerify.keptFileReveal)
    ) {
      throw new Error('Dry-Run 校验失败：安装过程破坏了既有插件标记');
    }

    const uninstallVerify = applyPatchToAsar(copyAsar, 'uninstall');
    if (uninstallVerify.hasMainLoader || uninstallVerify.hasPreloadBridge) {
      throw new Error('Dry-Run 卸载校验失败：仍残留 KupaDesk 标记');
    }
    if (
      (installVerify.hadCn && !uninstallVerify.keptCn) ||
      (installVerify.hadContextMonitor && !uninstallVerify.keptContextMonitor) ||
      (installVerify.hadFileReveal && !uninstallVerify.keptFileReveal)
    ) {
      throw new Error('Dry-Run 卸载校验失败：卸载过程破坏了既有插件标记');
    }

    console.log(
      JSON.stringify(
        {
          ok: true,
          clientVersion: ver,
          installDir,
          realAsar,
          installVerify,
          uninstallVerify,
        },
        null,
        2
      )
    );
  } finally {
    try {
      fs.rmSync(tempDir, { recursive: true, force: true });
    } catch (_e) {}
  }
}

function createActionLogger(logFile) {
  if (!logFile) return (msg) => console.log(msg);
  const abs = path.resolve(logFile);
  fs.mkdirSync(path.dirname(abs), { recursive: true });
  fs.writeFileSync(abs, `[${new Date().toISOString()}] 启动 KupaDesk 桌面挂载任务\n`, 'utf8');
  return (msg) => {
    const line = `[${new Date().toISOString()}] ${msg}`;
    console.log(line);
    try {
      fs.appendFileSync(abs, `${line}\n`, 'utf8');
    } catch (_e) {}
  };
}

function parseCliArgs(argv) {
  const opts = {
    mode: '',
    noKill: false,
    autoRestart: false,
    delayMs: 0,
    logFile: '',
    dataDir: '',
    installDir: '',
  };
  for (let i = 0; i < argv.length; i++) {
    const a = argv[i];
    if (a === '--status') opts.mode = 'status';
    else if (a === '--dry-run') opts.mode = 'dry-run';
    else if (a === '--install') opts.mode = 'install';
    else if (a === '--uninstall') opts.mode = 'uninstall';
    else if (a === '--no-kill') opts.noKill = true;
    else if (a === '--auto-restart') opts.autoRestart = true;
    else if (a === '--delay') opts.delayMs = Math.max(0, Number(argv[++i]) || 0);
    else if (a === '--log') opts.logFile = argv[++i] || '';
    else if (a === '--data-dir') opts.dataDir = argv[++i] || '';
    else if (a === '--install-dir') opts.installDir = argv[++i] || '';
  }
  return opts;
}

if (require.main === module) {
  try {
    const opts = parseCliArgs(process.argv.slice(2));
    if (opts.mode === 'status') {
      console.log(JSON.stringify(inspectDesktopStatus({ dataDir: opts.dataDir, manualDir: opts.installDir }), null, 2));
      process.exit(0);
    }
    if (opts.mode === 'dry-run') {
      runDryRun(opts.installDir);
      process.exit(0);
    }
    if (opts.mode !== 'install' && opts.mode !== 'uninstall') {
      console.error('用法: node install-desktop.cjs --status | --dry-run | --install | --uninstall [--no-kill] [--auto-restart] [--delay <ms>]');
      process.exit(1);
    }

    if (opts.autoRestart) {
      const dispatched = dispatchDesktopAction(opts.mode, {
        dataDir: opts.dataDir,
        installDir: opts.installDir,
        delayMs: opts.delayMs > 0 ? opts.delayMs : 2500,
      });
      console.log(JSON.stringify(dispatched, null, 2));
      process.exit(0);
    }

    const logFile = opts.logFile || path.join(getDataDir(opts.dataDir), 'last-desktop-action.log');
    const log = createActionLogger(logFile);

    if (opts.delayMs > 0) {
      log(`[等待] 延迟 ${opts.delayMs}ms 后执行 ${opts.mode}...`);
      sleepSync(opts.delayMs);
    }

    const installDir = detectInstallationDir(opts.installDir);
    const resourcesDir = resolveResourcesDir(installDir);
    const asarPath = path.join(resourcesDir, 'app.asar');
    fs.accessSync(resourcesDir, fs.constants.W_OK | fs.constants.X_OK);
    fs.accessSync(asarPath, fs.constants.R_OK | fs.constants.W_OK);

    const wasRunning = isAppRunning();
    if (!opts.noKill && wasRunning) {
      closeAppProcesses(asarPath, log);
    }

    log(`[2/3] 正在执行 app.asar ${opts.mode === 'install' ? '注入' : '卸载'}（保留原备份与全部既有插件）...`);
    const verify = applyPatchToAsar(asarPath, opts.mode);
    log(`[√] 完成并校验通过: ${JSON.stringify(verify)}`);

    if (!opts.noKill && wasRunning) {
      relaunchApp(installDir, log);
    }
  } catch (err) {
    console.error('[错误]', err && err.message ? err.message : String(err));
    process.exit(1);
  }
}

module.exports = {
  MAIN_START,
  MAIN_END,
  PRELOAD_START,
  PRELOAD_END,
  AsarArchive,
  removeMarkedBlocks,
  patchMainContent,
  unpatchMainContent,
  patchPreloadContent,
  unpatchPreloadContent,
  detectInstallationDir,
  resolveResourcesDir,
  resolveRealNodeExecutable,
  inspectDesktopStatus,
  dispatchDesktopAction,
  applyPatchToAsar,
};

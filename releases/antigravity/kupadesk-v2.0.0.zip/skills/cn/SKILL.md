---
name: cn
description: 打开 KupaDesk 中文增强控制面板，查看 Antigravity 中文汉化、上下文监控、红框入口与右键「打开存放位置」状态，或一键安装、升级后恢复与还原官方英文。当用户输入 /cn 或询问汉化/右键插件状态与恢复时激活。
---

# `/cn` — 中文增强工具箱（已合并入 KupaDesk）

当用户输入 `/cn` 或询问 Antigravity 中文汉化、上下文监控、右键「打开存放位置」状态及升级后恢复时：

1. 直接在回复中提供右侧辅助面板的一键展开胶囊链接与插件管理链接：

   [KupaDesk · 中文增强与客户端设置](sidecar://kupadesk/prompt_panel/?view=client)

   插件管理页：[KupaDesk](customization://prompt-injector)

2. 简短说明可通过对话右上角 `+` 菜单或输入 `/core` 打开 **KupaDesk 面板的「增强」标签页**（Antigravity 客户端增强卡片），查看实时状态、切换「新对话自动中文标题」或「全局简体中文思考规则」开关，以及点击一键全套安装/恢复（汉化 + 右键 + 红框入口）；修改 `app.asar` 的操作会自动关闭并重启一次 Antigravity 生效。
3. 若用户在对话中说“帮我把左侧历史英文标题翻译成中文”（或类似批量重命名左侧对话请求），可直接通过本地 Language Server RPC 实施（无需外接第三方 API）：
   - 调用 `POST http://${ANTIGRAVITY_LS_ADDRESS}/exa.language_server_pb.LanguageServerService/GetAllCascadeTrajectories`（请求体 `{"excludeSubtrajectories":true}`，附带 `x-codeium-csrf-token: ${ANTIGRAVITY_CSRF_TOKEN}`）获取所有会话摘要与自定义标题；
   - 仅筛选 `annotations.title` 为空且 `summary` 不含中文的对话，由模型直接翻译为简洁自然的中文标题；
   - 调用 `UpdateConversationAnnotations`（请求体 `{"cascadeIds":["<id>"],"annotations":{"title":"<中文标题>"},"mergeAnnotations":true}`）逐条写回（**绝不覆盖用户已手动重命名的标题**）。
4. 若用户在对话中明确要求直接查询环境状态，或明确授权立即执行后台安装/恢复/还原，可调用内置脚本（在插件根目录 `PLUGIN_ROOT` 下执行）：
   - 查询状态：`node lib/cn-runner.cjs --action status`
   - 预检校验：`node lib/cn-runner.cjs --action install-all --dry-run`
   - 经用户明确确认重启后才可执行：`node lib/cn-runner.cjs --action install-all --auto-restart`（或按需替换为 `install-cn` / `install-reveal` / `uninstall-reveal` / `install-kupadesk` / `uninstall-kupadesk` / `restore-official`）。
5. 保持回复简洁，未经用户要求不主动重启客户端或改动其他文件。
